from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_data_view_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    try:
        t_1 = environment.filters['cpp_data_view_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_data_view_type' found.")
    try:
        t_2 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_3 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_4 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    for l_1_pf in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_kind = l_1_name = missing
        _loop_vars = {}
        pass
        l_1_kind = environment.getattr(environment.getattr(l_1_pf, 'field'), 'kind')
        _loop_vars['kind'] = l_1_kind
        l_1_name = environment.getattr(environment.getattr(l_1_pf, 'field'), 'name')
        _loop_vars['name'] = l_1_name
        if t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
            yield 'DataView::Get'
            yield str(t_4((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n  auto pointer = data_->header_.version >= '
                yield str(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                 ? &data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' : nullptr;'
            else:
                pass
                yield '\n  auto pointer = &data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ';'
            yield '\n  *output = '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(pointer, message_);\n}'
        elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
            yield 'DataView::Get'
            yield str(t_4((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) {'
            if (environment.getattr(l_1_pf, 'min_version') != 0):
                pass
                yield '\n  auto pointer = data_->header_.version >= '
                yield str(environment.getattr(l_1_pf, 'min_version'))
                yield '\n                 ? data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get() : nullptr;'
            else:
                pass
                yield '\n  auto pointer = data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '.Get();'
            yield '\n  *output = '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(pointer, message_);\n}'
    l_1_pf = l_1_kind = l_1_name = missing
    yield '\n'

blocks = {}
debug_info = '1=36&2=40&3=42&5=44&6=47&7=51&8=53&9=56&10=58&12=63&14=66&17=68&18=71&19=75&20=77&21=80&22=82&24=87&26=90'