from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-shared.cc.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_all_enums = resolve('all_enums')
    l_0_features = resolve('features')
    l_0_extra_traits_headers = resolve('extra_traits_headers')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_unions = resolve('unions')
    l_0_structs = resolve('structs')
    l_0_interfaces = resolve('interfaces')
    l_0_enum_stream = l_0_enum_to_string = l_0_enum_trace_format_traits = missing
    try:
        t_1 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_2 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    pass
    yield '// Copyright 2016 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared.h"\n\n// Used to support stream output operator for enums.\n// TODO(dcheng): Consider omitting this somehow if not needed.\n#include <ostream>\n#include <utility>'
    if (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        pass
        yield '\n#include "base/strings/stringprintf.h"'
    yield '\n#include "mojo/public/cpp/bindings/lib/validate_params.h"\n#include "mojo/public/cpp/bindings/lib/validation_errors.h"\n#include "mojo/public/cpp/bindings/lib/validation_util.h"\n#include "third_party/perfetto/include/perfetto/tracing/traced_value.h"\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-params-data.h"'
    if (undefined(name='features') if l_0_features is missing else l_0_features):
        pass
        yield '\n#include "'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
        yield '-features.h"'
    for l_1_header in (undefined(name='extra_traits_headers') if l_0_extra_traits_headers is missing else l_0_extra_traits_headers):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(l_1_header)
        yield '"'
    l_1_header = missing
    for l_1_namespace in (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array):
        _loop_vars = {}
        pass
        yield '\nnamespace '
        yield str(l_1_namespace)
        yield ' {'
    l_1_namespace = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.cc.tmpl')._get_default_module(context)
    l_0_enum_stream = getattr(included_template, 'enum_stream', missing)
    if l_0_enum_stream is missing:
        l_0_enum_stream = undefined(f"the template {included_template.__name__!r} (imported on line 35 in 'module-shared.cc.tmpl') does not export the requested name 'enum_stream'", name='enum_stream')
    l_0_enum_to_string = getattr(included_template, 'enum_to_string', missing)
    if l_0_enum_to_string is missing:
        l_0_enum_to_string = undefined(f"the template {included_template.__name__!r} (imported on line 35 in 'module-shared.cc.tmpl') does not export the requested name 'enum_to_string'", name='enum_to_string')
    context.vars.update({'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string})
    context.exported_vars.difference_update(('enum_stream', 'enum_to_string'))
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        _loop_vars = {}
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_to_string') if l_0_enum_to_string is missing else l_0_enum_to_string), l_1_enum, _loop_vars=_loop_vars))
            yield '\n'
            yield str(context.call((undefined(name='enum_stream') if l_0_enum_stream is missing else l_0_enum_stream), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\nnamespace internal {'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('union_definition.tmpl', 'module-shared.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_1(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits})):
                yield event
    l_1_struct = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            _loop_vars = {}
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            _loop_vars['struct'] = l_2_struct
            yield '\n'
            template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                _loop_vars['struct'] = l_2_struct
                yield '\n'
                template = environment.get_template('struct_definition.tmpl', 'module-shared.cc.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    yield '\n\n}  // namespace internal'
    for l_1_feature in (undefined(name='features') if l_0_features is missing else l_0_features):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('feature_definition.tmpl', 'module-shared.cc.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'feature': l_1_feature, 'enum_stream': l_0_enum_stream, 'enum_to_string': l_0_enum_to_string, 'enum_trace_format_traits': l_0_enum_trace_format_traits})):
            yield event
    l_1_feature = missing
    for l_1_namespace in t_2((undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)):
        _loop_vars = {}
        pass
        yield '\n}  // namespace '
        yield str(l_1_namespace)
    l_1_namespace = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared.cc.tmpl')._get_default_module(context)
    l_0_enum_trace_format_traits = getattr(included_template, 'enum_trace_format_traits', missing)
    if l_0_enum_trace_format_traits is missing:
        l_0_enum_trace_format_traits = undefined(f"the template {included_template.__name__!r} (imported on line 81 in 'module-shared.cc.tmpl') does not export the requested name 'enum_trace_format_traits'", name='enum_trace_format_traits')
    context.vars['enum_trace_format_traits'] = l_0_enum_trace_format_traits
    context.exported_vars.discard('enum_trace_format_traits')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        _loop_vars = {}
        pass
        if (not t_1(l_1_enum)):
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_trace_format_traits') if l_0_enum_trace_format_traits is missing else l_0_enum_trace_format_traits), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing

blocks = {}
debug_info = '5=33&12=35&20=39&22=41&23=44&26=46&27=50&30=53&31=57&35=60&36=69&37=72&38=75&39=77&46=80&47=84&51=88&52=91&53=94&58=98&59=101&60=105&61=108&62=111&63=113&64=116&72=122&73=126&76=130&77=134&81=136&82=142&83=145&84=148'