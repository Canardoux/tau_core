from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-shared-message-ids.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_include_guard = l_0_namespace_begin = l_0_namespace_end = l_0_header_guard = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    pass
    yield '// Copyright 2018 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-shared-message-ids.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-message-ids.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-message-ids.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-message-ids.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    context.vars.update({'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    context.exported_vars.difference_update(('include_guard', 'namespace_begin', 'namespace_end'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'SHARED_MESSAGE_IDS', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\nnamespace messages {\n\n'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\nenum class '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ' : uint32_t {'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_name = missing
            _loop_vars = {}
            pass
            l_2_method_name = t_1('k%s', environment.getattr(l_2_method, 'name'))
            _loop_vars['method_name'] = l_2_method_name
            if environment.getattr(l_2_method, 'ordinal_comment'):
                pass
                yield '\n// '
                yield str(environment.getattr(l_2_method, 'ordinal_comment'))
            yield '\n  '
            yield str((undefined(name='method_name') if l_2_method_name is missing else l_2_method_name))
            yield ' = '
            yield str(environment.getattr(l_2_method, 'ordinal'))
            yield ','
        l_2_method = l_2_method_name = missing
        yield '\n};'
    l_1_interface = missing
    yield '\n\n}  // namespace messages\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=22&8=34&10=38&11=40&15=42&18=44&19=48&20=50&21=54&22=56&23=59&25=61&31=69&33=71'