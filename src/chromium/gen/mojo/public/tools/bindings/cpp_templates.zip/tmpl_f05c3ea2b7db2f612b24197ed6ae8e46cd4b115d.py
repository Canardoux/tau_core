from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-import-headers.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_imports = resolve('imports')
    l_0_include_guard = l_0_variant_path = l_0_header_guard = missing
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-import-headers.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-import-headers.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_variant_path = getattr(included_template, 'variant_path', missing)
    if l_0_variant_path is missing:
        l_0_variant_path = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-import-headers.h.tmpl') does not export the requested name 'variant_path'", name='variant_path')
    context.vars.update({'include_guard': l_0_include_guard, 'variant_path': l_0_variant_path})
    context.exported_vars.difference_update(('include_guard', 'variant_path'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'IMPORT_HEADERS', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant), _loop_vars=_loop_vars))
        yield '.h"\n#include "'
        yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant), _loop_vars=_loop_vars))
        yield '-import-headers.h"'
    l_1_import = missing
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=16&7=25&9=29&10=31&12=32&13=36&14=38&17=42'