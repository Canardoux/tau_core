from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_data_view_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = missing
    try:
        t_1 = environment.filters['cpp_data_view_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_data_view_type' found.")
    try:
        t_2 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_3 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_4 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_5 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_6 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_7 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_8 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_9 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_10 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_11 = environment.filters['requires_context_for_data_view']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'requires_context_for_data_view' found.")
    try:
        t_12 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_13 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_data_view_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView {\n public:\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView() = default;\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'DataView(\n      internal::'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data* data,\n      mojo::Message* message)'
    if t_11((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n      : data_(data), message_(message) {}'
    else:
        pass
        yield '\n      : data_(data) {}'
    yield '\n\n  bool is_null() const { return !data_; }'
    for l_1_pf in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_original_field = resolve('original_field')
        l_1_has_value_pf = resolve('has_value_pf')
        l_1_value_pf = resolve('value_pf')
        l_1_kind = resolve('kind')
        l_1_name = resolve('name')
        _loop_vars = {}
        pass
        if t_6(l_1_pf):
            pass
            if t_8(l_1_pf):
                pass
                l_1_original_field = environment.getattr(l_1_pf, 'original_field')
                _loop_vars['original_field'] = l_1_original_field
                l_1_has_value_pf = l_1_pf
                _loop_vars['has_value_pf'] = l_1_has_value_pf
                l_1_value_pf = environment.getattr(l_1_pf, 'linked_value_packed_field')
                _loop_vars['value_pf'] = l_1_value_pf
                l_1_kind = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'kind')
                _loop_vars['kind'] = l_1_kind
                l_1_name = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'name')
                _loop_vars['name'] = l_1_name
                if t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                    pass
                    yield '\n  template <typename UserType>\n  [[nodiscard]] bool Read'
                    yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                    yield '(UserType* output) const {'
                    if (environment.getattr(l_1_pf, 'min_version') != 0):
                        pass
                        yield '\n    if (data_->header_.version < '
                        yield str(environment.getattr(l_1_pf, 'min_version'))
                        yield ') {\n      *output = std::nullopt;\n      return true;\n    }'
                    yield '\n    if (!data_->'
                    yield str(environment.getattr(environment.getattr((undefined(name='has_value_pf') if l_1_has_value_pf is missing else l_1_has_value_pf), 'field'), 'name'))
                    yield ') {\n      *output = std::nullopt;\n      return true;\n    }\n\n    return mojo::internal::Deserialize<'
                    yield str(t_13(environment.getattr(environment.getattr((undefined(name='value_pf') if l_1_value_pf is missing else l_1_value_pf), 'field'), 'kind')))
                    yield '>(\n        data_->'
                    yield str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_1_value_pf is missing else l_1_value_pf), 'field'), 'name'))
                    yield ', &output->emplace());\n  }'
                    if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                        pass
                        yield '\n  '
                        yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                        yield ' '
                        yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                        yield '() const {'
                        if (environment.getattr(l_1_pf, 'min_version') != 0):
                            pass
                            yield '\n    if (data_->header_.version < '
                            yield str(environment.getattr(l_1_pf, 'min_version'))
                            yield ') {\n      return std::nullopt;\n    }'
                        yield '\n    if (!data_->'
                        yield str(environment.getattr(environment.getattr((undefined(name='has_value_pf') if l_1_has_value_pf is missing else l_1_has_value_pf), 'field'), 'name'))
                        yield ') {\n      return std::nullopt;\n    }\n    return ::mojo::internal::ToKnownEnumValueHelper(\n          static_cast<'
                        yield str(t_13(environment.getattr(environment.getattr((undefined(name='value_pf') if l_1_value_pf is missing else l_1_value_pf), 'field'), 'kind')))
                        yield '>(data_->'
                        yield str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_1_value_pf is missing else l_1_value_pf), 'field'), 'name'))
                        yield '));\n  }'
                else:
                    pass
                    yield '\n  '
                    yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                    yield ' '
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '() const {'
                    if (environment.getattr(l_1_pf, 'min_version') != 0):
                        pass
                        yield '\n    if (data_->header_.version < '
                        yield str(environment.getattr(l_1_pf, 'min_version'))
                        yield ') {\n      return std::nullopt;\n    }'
                    yield '\n\n    return data_->'
                    yield str(environment.getattr(environment.getattr((undefined(name='has_value_pf') if l_1_has_value_pf is missing else l_1_has_value_pf), 'field'), 'name'))
                    yield '\n        ? std::make_optional('
                    yield str(('!!' if t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)) else cond_expr_undefined("the inline if-expression on line 69 in 'struct_data_view_declaration.tmpl' evaluated to false and no else section was defined.")))
                    yield 'data_->'
                    yield str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_1_value_pf is missing else l_1_value_pf), 'field'), 'name'))
                    yield ')\n        : std::nullopt;\n  }'
        else:
            pass
            l_1_kind = environment.getattr(environment.getattr(l_1_pf, 'field'), 'kind')
            _loop_vars['kind'] = l_1_kind
            l_1_name = environment.getattr(environment.getattr(l_1_pf, 'field'), 'name')
            _loop_vars['name'] = l_1_name
            if t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n  inline void Get'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield 'DataView(\n      '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '* output);\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield '(UserType* output) {\n    '
                yield str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name), _loop_vars=_loop_vars))
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    auto* pointer = data_->header_.version >= '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield ' && !data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '.is_null()\n                    ? &data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield ' : nullptr;'
                else:
                    pass
                    yield '\n    auto* pointer = !data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '.is_null() ? &data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield ' : nullptr;'
                yield '\n    return mojo::internal::Deserialize<'
                yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(\n        pointer, output, message_);\n  }'
            elif t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n  inline void Get'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield 'DataView(\n      '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '* output);\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield '(UserType* output) {\n    '
                yield str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name), _loop_vars=_loop_vars))
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    auto* pointer = data_->header_.version >= '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield '\n                    ? data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '.Get() : nullptr;'
                else:
                    pass
                    yield '\n    auto* pointer = data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '.Get();'
                yield '\n    return mojo::internal::Deserialize<'
                yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(\n        pointer, output, message_);\n  }'
            elif t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n  template <typename UserType>\n  [[nodiscard]] bool Read'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield '(UserType* output) const {'
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    auto data_value = data_->header_.version >= '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield '\n                      ? data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield ' : 0;'
                else:
                    pass
                    yield '\n    auto data_value = data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield ';'
                yield '\n    return mojo::internal::Deserialize<'
                yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(\n        data_value, output);\n  }'
                if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                    pass
                    yield '\n  '
                    yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                    yield ' '
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '() const {'
                    if (environment.getattr(l_1_pf, 'min_version') != 0):
                        pass
                        yield '\n    if (data_->header_.version < '
                        yield str(environment.getattr(l_1_pf, 'min_version'))
                        yield ')\n      return '
                        yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                        yield '{};'
                    yield '\n    return ::mojo::internal::ToKnownEnumValueHelper(\n          static_cast<'
                    yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                    yield '>(data_->'
                    yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                    yield '));\n  }'
            elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n  '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' Take'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield '() {\n    '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' result;'
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    if (data_->header_.version < '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield ')\n      return result;'
                yield '\n    bool ret =\n        mojo::internal::Deserialize<'
                yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(\n            &data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', &result, message_);\n    DCHECK(ret);\n    return result;\n  }'
            elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n  template <typename UserType>\n  UserType Take'
                yield str(t_12((undefined(name='name') if l_1_name is missing else l_1_name)))
                yield '() {\n    UserType result;'
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    if (data_->header_.version < '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield ')\n      return result;'
                yield '\n    bool ret =\n        mojo::internal::Deserialize<'
                yield str(t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(\n            &data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', &result, message_);\n    DCHECK(ret);\n    return result;\n  }'
            else:
                pass
                yield '\n  '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '() const {'
                if (environment.getattr(l_1_pf, 'min_version') != 0):
                    pass
                    yield '\n    if (data_->header_.version < '
                    yield str(environment.getattr(l_1_pf, 'min_version'))
                    yield ')\n      return '
                    yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                    yield '{};'
                yield '\n    return data_->'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ';\n  }'
    l_1_pf = l_1_original_field = l_1_has_value_pf = l_1_value_pf = l_1_kind = l_1_name = missing
    yield '\n private:\n  internal::'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data* data_ = nullptr;'
    if t_11((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\n  mojo::Message* message_ = nullptr;'
    yield '\n};'

blocks = {}
debug_info = '1=91&3=94&5=96&7=98&8=100&10=102&18=109&19=117&20=119&21=121&22=123&23=125&24=127&25=129&27=131&29=134&30=136&31=139&36=142&41=144&42=146&45=148&46=151&47=155&48=158&52=161&56=163&61=170&62=174&63=177&68=180&69=182&77=188&78=190&79=192&80=195&81=197&84=199&85=201&86=202&87=205&88=209&90=214&92=219&96=221&97=224&98=226&101=228&102=230&103=231&104=234&105=236&107=241&109=244&113=246&115=249&116=251&117=254&118=256&120=261&122=264&126=266&127=269&128=273&129=276&130=278&133=281&137=285&138=288&139=292&140=294&141=297&145=300&146=302&151=304&153=307&155=309&156=312&160=315&161=317&167=322&168=326&169=329&170=331&172=334&179=338&180=340'