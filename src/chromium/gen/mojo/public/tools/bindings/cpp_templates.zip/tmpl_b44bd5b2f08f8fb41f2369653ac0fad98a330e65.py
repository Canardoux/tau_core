from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_export_attribute = resolve('export_attribute')
    l_0_last_field = resolve('last_field')
    l_0_offset = resolve('offset')
    l_0_pad = resolve('pad')
    l_0_class_name = l_0_num_packed_fields = missing
    try:
        t_1 = environment.filters['cpp_field_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_field_type' found.")
    try:
        t_2 = environment.filters['get_pad']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_pad' found.")
    pass
    l_0_class_name = str_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    yield 'class '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ' {\n public:\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context);\n\n  mojo::internal::StructHeader header_;'
    l_1_loop = missing
    for l_1_packed_field, l_1_loop in LoopContext(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), undefined):
        l_1_next_pf = resolve('next_pf')
        l_1_pad = l_0_pad
        l_1_name = l_1_kind = missing
        _loop_vars = {}
        pass
        l_1_name = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name')
        _loop_vars['name'] = l_1_name
        l_1_kind = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')
        _loop_vars['kind'] = l_1_kind
        if (environment.getattr((undefined(name='kind') if l_1_kind is missing else l_1_kind), 'spec') == 'b'):
            pass
            yield '\n  uint8_t '
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ' : 1;'
        else:
            pass
            yield '\n  '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' '
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            l_1_next_pf = environment.getitem(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), (environment.getattr(l_1_loop, 'index0') + 1))
            _loop_vars['next_pf'] = l_1_next_pf
            l_1_pad = (environment.getattr((undefined(name='next_pf') if l_1_next_pf is missing else l_1_next_pf), 'offset') - (environment.getattr(l_1_packed_field, 'offset') + environment.getattr(l_1_packed_field, 'size')))
            _loop_vars['pad'] = l_1_pad
            if ((undefined(name='pad') if l_1_pad is missing else l_1_pad) > 0):
                pass
                yield '\n  uint8_t pad'
                yield str(environment.getattr(l_1_loop, 'index0'))
                yield '_['
                yield str((undefined(name='pad') if l_1_pad is missing else l_1_pad))
                yield '];'
    l_1_loop = l_1_packed_field = l_1_name = l_1_kind = l_1_next_pf = l_1_pad = missing
    l_0_num_packed_fields = environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'num_packed_fields')
    context.vars['num_packed_fields'] = l_0_num_packed_fields
    context.exported_vars.add('num_packed_fields')
    if ((undefined(name='num_packed_fields') if l_0_num_packed_fields is missing else l_0_num_packed_fields) > 0):
        pass
        l_0_last_field = environment.getitem(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'), ((undefined(name='num_packed_fields') if l_0_num_packed_fields is missing else l_0_num_packed_fields) - 1))
        context.vars['last_field'] = l_0_last_field
        context.exported_vars.add('last_field')
        l_0_offset = (environment.getattr((undefined(name='last_field') if l_0_last_field is missing else l_0_last_field), 'offset') + environment.getattr((undefined(name='last_field') if l_0_last_field is missing else l_0_last_field), 'size'))
        context.vars['offset'] = l_0_offset
        context.exported_vars.add('offset')
        l_0_pad = t_2((undefined(name='offset') if l_0_offset is missing else l_0_offset), 8)
        context.vars['pad'] = l_0_pad
        context.exported_vars.add('pad')
        if ((undefined(name='pad') if l_0_pad is missing else l_0_pad) > 0):
            pass
            yield '\n  uint8_t padfinal_['
            yield str((undefined(name='pad') if l_0_pad is missing else l_0_pad))
            yield '];'
    yield '\n\n private:\n  friend class mojo::internal::MessageFragment<'
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '>;\n\n  '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '();\n  ~'
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '() = delete;\n};\nstatic_assert(sizeof('
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ') == '
    yield str(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'num_bytes'))
    yield ',\n              "Bad sizeof('
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ')");'

blocks = {}
debug_info = '1=29&3=33&9=38&10=44&11=46&12=48&13=51&15=56&17=60&18=62&19=64&20=66&21=69&26=74&27=77&28=79&29=82&30=85&31=88&32=91&37=94&39=96&40=98&42=100&43=104'