from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_class_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    try:
        t_1 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type_new']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type_new' found.")
    try:
        t_3 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_4 = environment.filters['is_hashable']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_hashable' found.")
    try:
        t_5 = environment.filters['struct_constructors']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'struct_constructors' found.")
    pass
    l_1_loop = missing
    for l_1_constructor, l_1_loop in LoopContext(t_5((undefined(name='struct') if l_0_struct is missing else l_0_struct)), undefined):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '::'
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '('
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_constructor, 'params'), undefined):
            l_2_type = l_2_name = missing
            _loop_vars = {}
            pass
            l_2_type = t_2(environment.getattr(l_2_field, 'kind'))
            _loop_vars['type'] = l_2_type
            l_2_name = environment.getattr(l_2_field, 'name')
            _loop_vars['name'] = l_2_name
            yield '\n    '
            yield str((undefined(name='type') if l_2_type is missing else l_2_type))
            yield ' '
            yield str((undefined(name='name') if l_2_name is missing else l_2_name))
            yield '_in'
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_field = l_2_type = l_2_name = missing
        yield ')'
        l_2_loop = missing
        for (l_2_field, l_2_is_parameter), l_2_loop in LoopContext(environment.getattr(l_1_constructor, 'fields'), undefined):
            l_2_name = missing
            _loop_vars = {}
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            _loop_vars['name'] = l_2_name
            yield '\n    '
            if environment.getattr(l_2_loop, 'first'):
                pass
                yield ':'
            else:
                pass
                yield ' '
            yield ' '
            yield str((undefined(name='name') if l_2_name is missing else l_2_name))
            yield '('
            if l_2_is_parameter:
                pass
                yield 'std::move('
                yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                yield '_in)'
            else:
                pass
                yield str(t_3(l_2_field))
            yield ')'
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_field = l_2_is_parameter = l_2_name = missing
        yield ' {}\n'
    l_1_loop = l_1_constructor = missing
    yield '\n'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::~'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '() = default;'
    if t_4((undefined(name='struct') if l_0_struct is missing else l_0_struct)):
        pass
        yield '\nsize_t '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '::Hash(size_t seed) const {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            l_1_for_blink = resolve('for_blink')
            _loop_vars = {}
            pass
            if (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink):
                pass
                yield '\n  seed = mojo::internal::WTFHash(seed, this->'
                yield str(environment.getattr(l_1_field, 'name'))
                yield ');'
            else:
                pass
                yield '\n  seed = mojo::internal::Hash(seed, this->'
                yield str(environment.getattr(l_1_field, 'name'))
                yield ');'
        l_1_field = l_1_for_blink = missing
        yield '\n  return seed;\n}'
    yield '\n\nvoid '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::WriteIntoTrace(\n    perfetto::TracedValue traced_context) const {\n  [[maybe_unused]] auto dict = std::move(traced_context).WriteDictionary();'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  perfetto::WriteIntoTracedValueWithFallback(\n    dict.AddItem(\n      "'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '"), '
        yield str(('this->' + environment.getattr(l_1_field, 'name')))
        yield ',\n#if BUILDFLAG(MOJO_TRACE_ENABLED)\n      "<value of type '
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield '>"\n#else\n      "<value>"\n#endif  // BUILDFLAG(MOJO_TRACE_ENABLED)\n    );'
    l_1_field = missing
    yield '\n}\n\nbool '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  return Data_::Validate(data, validation_context);\n}'

blocks = {}
debug_info = '1=43&2=47&3=52&4=56&5=58&6=61&7=65&9=71&10=75&11=78&12=87&13=90&15=94&17=96&20=103&22=107&23=110&24=112&25=116&26=119&28=124&35=129&38=131&41=135&43=139&51=143'