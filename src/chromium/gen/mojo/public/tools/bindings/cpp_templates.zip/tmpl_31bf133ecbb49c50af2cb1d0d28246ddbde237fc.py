from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_traits_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_export_attribute = resolve('export_attribute')
    l_0_mojom_type = missing
    try:
        t_1 = environment.filters['contains_handles_or_interfaces']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'contains_handles_or_interfaces' found.")
    try:
        t_2 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_3 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_4 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    pass
    l_0_mojom_type = t_2((undefined(name='struct') if l_0_struct is missing else l_0_struct))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\ntemplate <>\nstruct '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' StructTraits<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView,\n                                         '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr> {\n  static bool IsNull(const '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) { return !input; }\n  static void SetToNull('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) { output->reset(); }'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        l_1_return_ref = l_1_maybe_const = missing
        _loop_vars = {}
        pass
        l_1_return_ref = (t_4(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind')))
        _loop_vars['return_ref'] = l_1_return_ref
        yield '\n'
        l_1_maybe_const = ('' if t_1(environment.getattr(l_1_field, 'kind')) else 'const')
        _loop_vars['maybe_const'] = l_1_maybe_const
        if (undefined(name='return_ref') if l_1_return_ref is missing else l_1_return_ref):
            pass
            yield '\n  static '
            yield str((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const))
            yield ' decltype('
            yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield '::'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ')& '
            yield str(environment.getattr(l_1_field, 'name'))
            yield '(\n      '
            yield str((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const))
            yield ' '
            yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield 'Ptr& input) {\n    return input->'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
        else:
            pass
            yield '\n  static decltype('
            yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield '::'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ') '
            yield str(environment.getattr(l_1_field, 'name'))
            yield '(\n      const '
            yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
            yield 'Ptr& input) {\n    return input->'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';\n  }'
    l_1_field = l_1_return_ref = l_1_maybe_const = missing
    yield '\n\n  static bool Read('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input, '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output);\n};'

blocks = {}
debug_info = '1=38&4=42&5=46&6=48&7=50&9=52&10=56&17=59&18=61&19=64&20=72&21=76&24=81&25=87&26=89&31=93'