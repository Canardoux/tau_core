from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'feature_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_feature = resolve('feature')
    l_0_export_attribute = resolve('export_attribute')
    try:
        t_1 = environment.filters['get_full_mojom_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_full_mojom_name_for_kind' found.")
    pass
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '\n// @generated_from: '
        yield str(t_1((undefined(name='feature') if l_0_feature is missing else l_0_feature)))
    yield '\n'
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield '  BASE_DECLARE_FEATURE('
    yield str(environment.getattr((undefined(name='feature') if l_0_feature is missing else l_0_feature), 'name'))
    yield ');'

blocks = {}
debug_info = '1=20&2=23&4=25'