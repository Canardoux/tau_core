from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_class_template_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    pass
    yield 'template <typename StructPtrType>\n'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield 'Ptr '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Clone() const {\n  return New('
    l_1_loop = missing
    for l_1_field, l_1_loop in LoopContext(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'), undefined):
        _loop_vars = {}
        pass
        yield '\n      mojo::Clone('
        yield str(environment.getattr(l_1_field, 'name'))
        yield ')'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            yield ','
    l_1_loop = l_1_field = missing
    yield '\n  );\n}\n\ntemplate <typename T, '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>*>\nbool '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::Equals(const T& other_struct) const {'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  if (!mojo::Equals(this->'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ', other_struct.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '))\n    return false;'
    l_1_field = missing
    yield '\n  return true;\n}\n\ntemplate <typename T, '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::EnableIfSame<T>*>\nbool operator<(const T& lhs, const T& rhs) {'
    for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
        _loop_vars = {}
        pass
        yield '\n  if (lhs.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ' < rhs.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ')\n    return true;\n  if (rhs.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ' < lhs.'
        yield str(environment.getattr(l_1_field, 'name'))
        yield ')\n    return false;'
    l_1_field = missing
    yield '\n  return false;\n}'

blocks = {}
debug_info = '2=13&4=18&5=22&6=24&11=29&12=31&13=33&14=37&20=43&22=45&23=49&25=53'