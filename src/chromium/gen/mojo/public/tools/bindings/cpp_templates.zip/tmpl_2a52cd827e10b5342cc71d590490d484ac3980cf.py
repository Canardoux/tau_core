from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-shared-internal.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_imports = resolve('imports')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_all_enums = resolve('all_enums')
    l_0_include_guard = l_0_namespace_begin = l_0_namespace_end = l_0_header_guard = l_0_enum_data_decl = missing
    try:
        t_1 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_2 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    pass
    yield '// Copyright 2016 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-shared-internal.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-internal.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-internal.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-shared-internal.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    context.vars.update({'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    context.exported_vars.difference_update(('include_guard', 'namespace_begin', 'namespace_end'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'SHARED_INTERNAL', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    if (not (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/array_internal.h"\n#include "mojo/public/cpp/bindings/lib/bindings_internal.h"\n#include "mojo/public/cpp/bindings/lib/map_data_internal.h"\n#include "mojo/public/cpp/bindings/lib/buffer.h"'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '-shared-internal.h"'
    l_1_import = missing
    if (not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/native_enum_data.h"\n#include "mojo/public/interfaces/bindings/native_struct.mojom-shared-internal.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\nnamespace mojo {\nnamespace internal {\nclass ValidationContext;\n}\n}\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\nnamespace internal {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if t_2(l_1_struct):
            pass
            yield '\nusing '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield '_Data = mojo::native::internal::NativeStruct_Data;'
        else:
            pass
            yield '\nclass '
            yield str(environment.getattr(l_1_struct, 'name'))
            yield '_Data;'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str(environment.getattr(l_1_union, 'name'))
        yield '_Data;'
    l_1_union = missing
    included_template = environment.get_template('enum_macros.tmpl', 'module-shared-internal.h.tmpl')._get_default_module(context)
    l_0_enum_data_decl = getattr(included_template, 'enum_data_decl', missing)
    if l_0_enum_data_decl is missing:
        l_0_enum_data_decl = undefined(f"the template {included_template.__name__!r} (imported on line 62 in 'module-shared-internal.h.tmpl') does not export the requested name 'enum_data_decl'", name='enum_data_decl')
    context.vars['enum_data_decl'] = l_0_enum_data_decl
    context.exported_vars.discard('enum_data_decl')
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        _loop_vars = {}
        pass
        if t_2(l_1_enum):
            pass
            yield '\nusing '
            yield str(t_1(l_1_enum, flatten_nested_kind=True))
            yield '_Data =\n    mojo::internal::NativeEnum_Data;'
        else:
            pass
            yield '\n'
            yield str(context.call((undefined(name='enum_data_decl') if l_0_enum_data_decl is missing else l_0_enum_data_decl), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\n#pragma pack(push, 1)'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('union_declaration.tmpl', 'module-shared-internal.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_2(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_declaration.tmpl', 'module-shared-internal.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
            yield '\n'
            template = environment.get_template('struct_unserialized_message_context.tmpl', 'module-shared-internal.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_data_decl': l_0_enum_data_decl, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
    l_1_struct = missing
    yield '\n\n#pragma pack(pop)\n\n}  // namespace internal\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=35&8=47&10=51&11=53&13=54&20=57&21=61&24=64&29=67&30=70&33=73&45=77&49=79&50=82&51=85&53=90&57=93&58=97&62=100&63=106&64=109&65=112&68=117&76=120&77=124&81=128&82=131&83=134&84=138&91=143&93=145'