from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module_namespace = resolve('module_namespace')
    l_0_variant = resolve('variant')
    l_0_range = resolve('range')
    l_0_interface_macros = l_0_struct_macros = l_0_class_name = l_0_proxy_name = l_0_namespace_as_string = l_0_namespace_as_string_with_variant = l_0_qualified_class_name = l_0_alloc_params = l_0_pass_params = l_0_feature_enabled_helper = l_0_check_feature_for_method = l_0_define_validate_with_runtime_feature = l_0_request_validator = missing
    try:
        t_1 = environment.filters['constant_length']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_length' found.")
    try:
        t_2 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_3 = environment.filters['cpp_pod_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_pod_type' found.")
    try:
        t_4 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_5 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_6 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_7 = environment.filters['get_qualified_name_for_feature']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_feature' found.")
    try:
        t_8 = environment.filters['has_callbacks']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'has_callbacks' found.")
    try:
        t_9 = environment.filters['has_estimate_size_methods']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'has_estimate_size_methods' found.")
    try:
        t_10 = environment.filters['has_packed_method_ordinals']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'has_packed_method_ordinals' found.")
    try:
        t_11 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_12 = environment.filters['is_non_const_ref_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_non_const_ref_kind' found.")
    try:
        t_13 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_14 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_15 = environment.filters['is_string_kind']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_string_kind' found.")
    try:
        t_16 = environment.filters['list']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'list' found.")
    try:
        t_17 = environment.filters['map']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'map' found.")
    try:
        t_18 = environment.filters['max']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'max' found.")
    try:
        t_19 = environment.filters['replace']
    except KeyError:
        @internalcode
        def t_19(*unused):
            raise TemplateRuntimeError("No filter named 'replace' found.")
    try:
        t_20 = environment.filters['selectattr']
    except KeyError:
        @internalcode
        def t_20(*unused):
            raise TemplateRuntimeError("No filter named 'selectattr' found.")
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    l_0_class_name = environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name')
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    l_0_proxy_name = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), 'Proxy', ))
    context.vars['proxy_name'] = l_0_proxy_name
    context.exported_vars.add('proxy_name')
    l_0_namespace_as_string = t_6('%s', t_19(context.eval_ctx, (undefined(name='module_namespace') if l_0_module_namespace is missing else l_0_module_namespace), '.', '::'))
    context.vars['namespace_as_string'] = l_0_namespace_as_string
    context.exported_vars.add('namespace_as_string')
    l_0_namespace_as_string_with_variant = str_join(((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (str_join(('::', (undefined(name='variant') if l_0_variant is missing else l_0_variant), )) if (undefined(name='variant') if l_0_variant is missing else l_0_variant) else cond_expr_undefined("the inline if-expression on line 7 in 'interface_definition.tmpl' evaluated to false and no else section was defined.")), ))
    context.vars['namespace_as_string_with_variant'] = l_0_namespace_as_string_with_variant
    context.exported_vars.add('namespace_as_string_with_variant')
    l_0_qualified_class_name = str_join(((str_join(('::', (undefined(name='namespace_as_string_with_variant') if l_0_namespace_as_string_with_variant is missing else l_0_namespace_as_string_with_variant), )) if (undefined(name='namespace_as_string_with_variant') if l_0_namespace_as_string_with_variant is missing else l_0_namespace_as_string_with_variant) else cond_expr_undefined("the inline if-expression on line 8 in 'interface_definition.tmpl' evaluated to false and no else section was defined.")), '::', (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), ))
    context.vars['qualified_class_name'] = l_0_qualified_class_name
    context.exported_vars.add('qualified_class_name')
    def macro(l_1_struct, l_1_params, l_1_message, l_1_method_number, l_1_is_response):
        t_21 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_params is missing:
            l_1_params = undefined("parameter 'params' was not provided", name='params')
        if l_1_message is missing:
            l_1_message = undefined("parameter 'message' was not provided", name='message')
        if l_1_method_number is missing:
            l_1_method_number = undefined("parameter 'method_number' was not provided", name='method_number')
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        pass
        t_21.extend((
            '\n  \n  // Validation for ',
            str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name)),
            '.',
            str(l_1_method_number),
            '\n  bool success = true;',
        ))
        for l_2_param in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            _loop_vars = {}
            pass
            if t_13(l_2_param):
                pass
                if t_14(l_2_param):
                    pass
                    t_21.extend((
                        '\n  ',
                        str(t_4(environment.getattr(environment.getattr(l_2_param, 'original_field'), 'kind'))),
                        ' p_',
                        str(environment.getattr(environment.getattr(l_2_param, 'original_field'), 'name')),
                        '{};',
                    ))
            else:
                pass
                t_21.extend((
                    '\n  ',
                    str(t_4(environment.getattr(environment.getattr(l_2_param, 'field'), 'kind'))),
                    ' p_',
                    str(environment.getattr(environment.getattr(l_2_param, 'field'), 'name')),
                    '{',
                    str(t_5(environment.getattr(l_2_param, 'field'))),
                    '};',
                ))
        l_2_param = missing
        t_21.extend((
            '\n  ',
            str(environment.getattr(l_1_struct, 'name')),
            'DataView input_data_view(',
            str(l_1_params),
            ', ',
            str(l_1_message),
            ');\n  ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'deserialize'), l_1_struct, 'input_data_view', 'p_%s', 'success')),
            '\n  if (!success) {\n    ReportValidationErrorForMessage(\n        ',
            str(l_1_message),
            ',\n        mojo::internal::VALIDATION_ERROR_DESERIALIZATION_FAILED,\n        ',
            str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name)),
            '::Name_, ',
            str(l_1_method_number),
            ', ',
            str(l_1_is_response),
            ');\n    return false;\n  }',
        ))
        return concat(t_21)
    context.exported_vars.add('alloc_params')
    context.vars['alloc_params'] = l_0_alloc_params = Macro(environment, macro, 'alloc_params', ('struct', 'params', 'message', 'method_number', 'is_response'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parameters):
        t_22 = []
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            _loop_vars = {}
            pass
            if t_12(environment.getattr(l_2_param, 'kind')):
                pass
                t_22.extend((
                    '\np_',
                    str(environment.getattr(l_2_param, 'name')),
                ))
            else:
                pass
                t_22.extend((
                    '\nstd::move(p_',
                    str(environment.getattr(l_2_param, 'name')),
                    ')',
                ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_22.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_22)
    context.exported_vars.add('pass_params')
    context.vars['pass_params'] = l_0_pass_params = Macro(environment, macro, 'pass_params', ('parameters',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_iface):
        t_23 = []
        l_1_feature = missing
        if l_1_iface is missing:
            l_1_iface = undefined("parameter 'iface' was not provided", name='iface')
        pass
        l_1_feature = t_7(environment.getattr(l_1_iface, 'runtime_feature'))
        t_23.extend((
            '\n// static\nbool ',
            str(environment.getattr(l_1_iface, 'name')),
            '::RuntimeFeature_IsEnabled_(bool expected) {\n  bool enabled = base::FeatureList::IsEnabled(',
            str((undefined(name='feature') if l_1_feature is missing else l_1_feature)),
            ');\n#if DCHECK_IS_ON()\n  if (expected) {\n    DCHECK(enabled) << "RuntimeFeature ',
            str((undefined(name='feature') if l_1_feature is missing else l_1_feature)),
            ' for ',
            str(environment.getattr(l_1_iface, 'name')),
            ' is not enabled";\n  }\n#endif\n  return enabled;\n}',
        ))
        return concat(t_23)
    context.exported_vars.add('feature_enabled_helper')
    context.vars['feature_enabled_helper'] = l_0_feature_enabled_helper = Macro(environment, macro, 'feature_enabled_helper', ('iface',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method):
        t_24 = []
        l_1_feature_cpp = resolve('feature_cpp')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        if environment.getattr(l_1_method, 'runtime_feature'):
            pass
            l_1_feature_cpp = t_7(environment.getattr(l_1_method, 'runtime_feature'))
            t_24.extend((
                '\nCHECK(base::FeatureList::IsEnabled(',
                str((undefined(name='feature_cpp') if l_1_feature_cpp is missing else l_1_feature_cpp)),
                '));',
            ))
        return concat(t_24)
    context.exported_vars.add('check_feature_for_method')
    context.vars['check_feature_for_method'] = l_0_check_feature_for_method = Macro(environment, macro, 'check_feature_for_method', ('method',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_class_name, l_1_method):
        t_25 = []
        l_1_feature_cpp = missing
        if l_1_class_name is missing:
            l_1_class_name = undefined("parameter 'class_name' was not provided", name='class_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        l_1_feature_cpp = t_7(environment.getattr(l_1_method, 'runtime_feature'))
        t_25.extend((
            '\nbool ValidateWithRuntimeFeature_',
            str(l_1_class_name),
            '_',
            str(environment.getattr(l_1_method, 'name')),
            '(\n  const void* data, mojo::internal::ValidationContext* validation_context) {\n  if (!base::FeatureList::IsEnabled(',
            str((undefined(name='feature_cpp') if l_1_feature_cpp is missing else l_1_feature_cpp)),
            ')) {\n    return false;\n  }\n  return internal::',
            str(l_1_class_name),
            '_',
            str(environment.getattr(l_1_method, 'name')),
            '_Params_Data::Validate(\n    data, validation_context);\n}',
        ))
        return concat(t_25)
    context.exported_vars.add('define_validate_with_runtime_feature')
    context.vars['define_validate_with_runtime_feature'] = l_0_define_validate_with_runtime_feature = Macro(environment, macro, 'define_validate_with_runtime_feature', ('class_name', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_class_name, l_1_method):
        t_26 = []
        if l_1_class_name is missing:
            l_1_class_name = undefined("parameter 'class_name' was not provided", name='class_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        if environment.getattr(l_1_method, 'runtime_feature'):
            pass
            t_26.extend((
                '&ValidateWithRuntimeFeature_',
                str(l_1_class_name),
                '_',
                str(environment.getattr(l_1_method, 'name')),
            ))
        else:
            pass
            t_26.extend((
                '&internal::',
                str(l_1_class_name),
                '_',
                str(environment.getattr(l_1_method, 'name')),
                '_Params_Data::Validate',
            ))
        return concat(t_26)
    context.exported_vars.add('request_validator')
    context.vars['request_validator'] = l_0_request_validator = Macro(environment, macro, 'request_validator', ('class_name', 'method'), False, False, False, context.eval_ctx.autoescape)
    yield '\nconst char '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::Name_[] = "'
    yield str((undefined(name='module_namespace') if l_0_module_namespace is missing else l_0_module_namespace))
    yield '.'
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '";'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'uuid'):
        pass
        yield '\nconstexpr base::Token '
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '::Uuid_;'
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        _loop_vars = {}
        pass
        if t_15(environment.getattr(l_1_constant, 'kind')):
            pass
            yield '\nconst char '
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_constant, 'name'))
            yield '['
            yield str(t_1(l_1_constant))
            yield '] = '
            yield str(t_2(l_1_constant))
            yield ';'
        else:
            pass
            yield '\nconstexpr '
            yield str(t_3(environment.getattr(l_1_constant, 'kind')))
            yield ' '
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_constant, 'name'))
            yield ';'
    l_1_constant = missing
    yield '\n\n'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::IPCStableHashFunction '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::MessageToMethodInfo_(mojo::Message& message) {\n#if !BUILDFLAG(IS_FUCHSIA)'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  switch (static_cast<messages::'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '>(message.name())) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            _loop_vars = {}
            pass
            yield '\n    case messages::'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield ': {\n      return &'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_Sym::IPCStableHash;\n    }'
        l_1_method = missing
        yield '\n  }'
    yield '\n#endif  // !BUILDFLAG(IS_FUCHSIA)\n  return nullptr;\n}\n\n\nconst char* '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '::MessageToMethodName_(mojo::Message& message) {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  bool is_response = message.has_flag(mojo::Message::kFlagIsResponse);\n  if (!is_response) {\n    switch (static_cast<messages::'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '>(message.name())) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            _loop_vars = {}
            pass
            yield '\n      case messages::'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield ':\n            return "Receive '
            yield str((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
            yield '::'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '";'
        l_1_method = missing
        yield '\n    }\n  } else {\n    switch (static_cast<messages::'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '>(message.name())) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            _loop_vars = {}
            pass
            yield '\n      case messages::'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield ':\n            return "Receive reply '
            yield str((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
            yield '::'
            yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '";'
        l_1_method = missing
        yield '\n    }\n  }'
    yield '\n  return "Receive unknown mojo message";\n#else\n  bool is_response = message.has_flag(mojo::Message::kFlagIsResponse);\n  if (is_response) {\n    return "Receive mojo reply";\n  } else {\n    return "Receive mojo message";\n  }\n#endif // BUILDFLAG(MOJO_TRACE_ENABLED)\n}\n\n#if !BUILDFLAG(IS_FUCHSIA)'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\nuint32_t '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '::'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '_Sym::IPCStableHash() {\n  // This method\'s address is used for indetifiying the mojo method name after\n  // symbolization. So each IPCStableHash should have a unique address.\n  // We cannot use NO_CODE_FOLDING() here - it relies on the uniqueness of\n  // __LINE__ value, which is not unique accross different mojo modules.\n  // The code below is very similar to NO_CODE_FOLDING, but it uses a unique\n  // hash instead of __LINE__.\n  constexpr uint32_t kHash = base::MD5Hash32Constexpr(\n          "(Impl)'
        yield str((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string))
        yield '::'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '::'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '");\n  const uint32_t hash = kHash;\n  base::debug::Alias(&hash);\n  return hash;\n}'
    l_1_method = missing
    yield '\n# endif // !BUILDFLAG(IS_FUCHSIA)'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'runtime_feature'):
        pass
        yield '\n'
        yield str(context.call((undefined(name='feature_enabled_helper') if l_0_feature_enabled_helper is missing else l_0_feature_enabled_helper), (undefined(name='interface') if l_0_interface is missing else l_0_interface)))
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method, _loop_vars=_loop_vars))
            yield ') {\n  NOTREACHED();\n}'
    l_1_method = missing
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'sync'):
                pass
                yield '\nclass '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse\n    : public mojo::MessageReceiver {\n public:\n  '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse(\n      bool* result'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield ', '
                    yield str(t_4(environment.getattr(l_2_param, 'kind')))
                    yield '* out_'
                    yield str(environment.getattr(l_2_param, 'name'))
                l_2_param = missing
                yield ')\n      : result_(result)'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield ', out_'
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield '_(out_'
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield ')'
                l_2_param = missing
                yield ' {\n    DCHECK(!*result_);\n  }\n\n  '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse(const '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse&) = delete;\n  '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse& operator=(const '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_HandleSyncResponse&) = delete;\n\n  bool Accept(mojo::Message* message) override;\n private:\n  bool* result_;'
                for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    yield '\n  '
                    yield str(t_4(environment.getattr(l_2_param, 'kind')))
                    yield '* out_'
                    yield str(environment.getattr(l_2_param, 'name'))
                    yield '_;'
                l_2_param = missing
                yield '};'
            yield '\n\nclass '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback\n    : public mojo::MessageReceiver {\n public:\n  '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(\n      '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback callback\n      ) : callback_(std::move(callback)) {\n  }\n\n  '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(const '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback&) = delete;\n  '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback& operator=(const '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback&) = delete;\n\n  bool Accept(mojo::Message* message) override;\n private:\n  '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback callback_;\n};'
    l_1_method = missing
    yield '\n\n'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '::'
    yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
    yield '(mojo::MessageReceiverWithResponder* receiver)\n    : receiver_(receiver) {'
    if t_9((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  if (base::FeatureList::IsEnabled(mojo::features::kMojoPredictiveAllocation)) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_message_name = resolve('message_name')
            _loop_vars = {}
            pass
            if environment.getattr(l_1_method, 'estimate_message_size'):
                pass
                l_1_message_name = t_6('base::to_underlying(messages::%s::k%s)', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
                _loop_vars['message_name'] = l_1_message_name
                yield '\n    size_estimator_.EnablePredictiveAllocation('
                yield str((undefined(name='message_name') if l_1_message_name is missing else l_1_message_name))
                yield ');'
        l_1_method = l_1_message_name = missing
        yield '\n  }'
    yield '\n}'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_event_name = resolve('event_name')
        l_1_message_name = l_1_params_struct = l_1_params_description = l_1_message_typename = missing
        _loop_vars = {}
        pass
        l_1_message_name = t_6('base::to_underlying(messages::%s::k%s)', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
        _loop_vars['message_name'] = l_1_message_name
        l_1_params_struct = environment.getattr(l_1_method, 'param_struct')
        _loop_vars['params_struct'] = l_1_params_struct
        l_1_params_description = t_6('%s.%s request', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
        _loop_vars['params_description'] = l_1_params_description
        l_1_message_typename = t_6('%s_%s_Message', (undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name), environment.getattr(l_1_method, 'name'))
        _loop_vars['message_typename'] = l_1_message_typename
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '(\n    '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), 'param_', l_1_method, _loop_vars=_loop_vars))
            yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
            l_1_event_name = ('Call %s::%s::%s (sync)' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            _loop_vars['event_name'] = l_1_event_name
            yield '\n  '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='param_', method_parameters=environment.getattr(l_1_method, 'parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='input_parameters', trace_event_type='_BEGIN', _loop_vars=_loop_vars))
            yield '\n#else'
            l_1_event_name = ('%s::%s' % ((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            _loop_vars['event_name'] = l_1_event_name
            yield '\n  '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), _loop_vars=_loop_vars))
            yield '\n#endif\n  '
            yield str(t_11(context.call((undefined(name='check_feature_for_method') if l_0_check_feature_for_method is missing else l_0_check_feature_for_method), l_1_method, _loop_vars=_loop_vars), 2))
            yield '\n  const bool kExpectsResponse = true;\n  const bool kIsSync = true;\n  const bool kAllowInterrupt =\n      '
            if environment.getattr(l_1_method, 'allow_interrupt'):
                pass
                yield 'true'
            else:
                pass
                yield 'false'
            yield ';'
            if environment.getattr(l_1_method, 'supports_urgent'):
                pass
                yield '\n  const bool is_urgent = mojo::UrgentMessageScope::IsInUrgentScope();\n'
            else:
                pass
                yield '\n  const bool is_urgent = false;'
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), False, 'kIsSync', 'kAllowInterrupt', 'is_urgent', 'kExpectsResponse', 'kFlags', _loop_vars=_loop_vars))
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'param_%s', (undefined(name='params_struct') if l_1_params_struct is missing else l_1_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description), 'kFlags', 'message', _loop_vars=_loop_vars))
            yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::Name_);\n  message.set_method_name("'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '");\n#endif\n\n  bool result = false;\n  std::unique_ptr<mojo::MessageReceiver> responder(\n      new '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_HandleSyncResponse(\n          &result'
            for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                _loop_vars = {}
                pass
                yield ', out_param_'
                yield str(environment.getattr(l_2_param, 'name'))
            l_2_param = missing
            yield '));\n  ::mojo::internal::SendMojoMessage(*receiver_, message, std::move(responder));\n#if BUILDFLAG(MOJO_TRACE_ENABLED)\n  '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='out_param_', method_parameters=environment.getattr(l_1_method, 'response_parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='sync_response_parameters', trace_event_type='_END', dereference_parameters=True, _loop_vars=_loop_vars))
            yield '\n#endif\n  return result;\n}'
        yield '\n\nvoid '
        yield str((undefined(name='proxy_name') if l_0_proxy_name is missing else l_0_proxy_name))
        yield '::'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '(\n    '
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), 'in_', l_1_method, _loop_vars=_loop_vars))
        yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
        l_1_event_name = ('Send %s::%s::%s' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
        _loop_vars['event_name'] = l_1_event_name
        yield '\n  '
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='in_', method_parameters=environment.getattr(l_1_method, 'parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='input_parameters', _loop_vars=_loop_vars))
        yield '\n#endif\n'
        yield str(t_11(context.call((undefined(name='check_feature_for_method') if l_0_check_feature_for_method is missing else l_0_check_feature_for_method), l_1_method, _loop_vars=_loop_vars), 2))
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n  const bool kExpectsResponse = true;'
        else:
            pass
            yield '\n  const bool kExpectsResponse = false;'
        yield '\n  const bool kIsSync = false;\n  const bool kAllowInterrupt = true;'
        if environment.getattr(l_1_method, 'supports_urgent'):
            pass
            yield '\n  const bool is_urgent = mojo::UrgentMessageScope::IsInUrgentScope();\n'
        else:
            pass
            yield '\n  const bool is_urgent = false;'
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), False, 'kIsSync', 'kAllowInterrupt', 'is_urgent', 'kExpectsResponse', 'kFlags', _loop_vars=_loop_vars))
        yield '\n'
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'in_%s', (undefined(name='params_struct') if l_1_params_struct is missing else l_1_params_struct), (undefined(name='params_description') if l_1_params_description is missing else l_1_params_description), 'kFlags', 'message', True, _loop_vars=_loop_vars))
        yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '::Name_);\n  message.set_method_name("'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '");\n#endif'
        if environment.getattr(l_1_method, 'estimate_message_size'):
            pass
            yield '\n  size_estimator_.TrackPayloadSize('
            yield str((undefined(name='message_name') if l_1_message_name is missing else l_1_message_name))
            yield ', message.payload_num_bytes());'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n  std::unique_ptr<mojo::MessageReceiver> responder(\n      new '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback(\n          std::move(callback)));\n  ::mojo::internal::SendMojoMessage(*receiver_, message, std::move(responder));'
        else:
            pass
            yield '\n  // This return value may be ignored as false implies the Connector has\n  // encountered an error, which will be visible through other means.\n  ::mojo::internal::SendMojoMessage(*receiver_, message);'
        yield '\n}'
    l_1_method = l_1_message_name = l_1_params_struct = l_1_params_description = l_1_message_typename = l_1_event_name = missing
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_message_name = resolve('message_name')
        l_1_response_params_struct = resolve('response_params_struct')
        l_1_params_description = resolve('params_description')
        l_1_response_message_typename = resolve('response_message_typename')
        l_1_desc = resolve('desc')
        l_1_event_name = resolve('event_name')
        l_1_response_params_description = resolve('response_params_description')
        _loop_vars = {}
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            l_1_message_name = t_6('base::to_underlying(messages::%s::k%s)', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            _loop_vars['message_name'] = l_1_message_name
            l_1_response_params_struct = environment.getattr(l_1_method, 'response_param_struct')
            _loop_vars['response_params_struct'] = l_1_response_params_struct
            l_1_params_description = t_6('%s.%s response', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            _loop_vars['params_description'] = l_1_params_description
            l_1_response_message_typename = t_6('%s_%s_Response_Message', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_method, 'name'))
            _loop_vars['response_message_typename'] = l_1_response_message_typename
            yield '\nclass '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder : public ::mojo::internal::ProxyToResponder {\n public:\n  static '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback CreateCallback(\n      ::mojo::Message& message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder) {\n    std::unique_ptr<'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder> proxy(\n        new '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder(\n            message, std::move(responder)));\n    return base::BindOnce(&'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder::Run,\n                          std::move(proxy));\n  }\n\n  ~'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield "_ProxyToResponder() {\n#if DCHECK_IS_ON()\n    if (responder_) {\n      // If we're being destroyed without being run, we want to ensure the\n      // binding endpoint has been closed. This checks for that asynchronously.\n      // We pass a bound generated callback to handle the response so that any\n      // resulting DCHECK stack will have useful interface type information.\n      // Instantiate a ScopedFizzleBlockShutdownTasks to allow this request to\n      // fizzle if this happens after shutdown and the endpoint is bound to a\n      // BLOCK_SHUTDOWN sequence.\n      base::ThreadPoolInstance::ScopedFizzleBlockShutdownTasks fizzler;\n      responder_->IsConnectedAsync(base::BindOnce(&OnIsConnectedComplete));\n    }\n#endif\n  }\n\n private:\n  "
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder(\n      ::mojo::Message& message,\n      std::unique_ptr<mojo::MessageReceiverWithStatus> responder)\n      : ::mojo::internal::ProxyToResponder(message, std::move(responder)) {\n  }\n\n#if DCHECK_IS_ON()\n  static void OnIsConnectedComplete(bool connected) {\n    DCHECK(!connected)\n        << "'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::'
            yield str(environment.getattr(l_1_method, 'name'))
            yield 'Callback was destroyed without "\n        << "first either being run or its corresponding binding being closed. "\n        << "It is an error to drop response callbacks which still correspond "\n        << "to an open interface pipe.";\n  }\n#endif\n\n  void Run(\n      '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), 'in_', environment.getattr(l_1_method, 'response_parameters'), _loop_vars=_loop_vars))
            yield ');\n};\n\nbool '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ForwardToCallback::Accept(\n    mojo::Message* message) {\n  DCHECK(message->is_serialized());\n  internal::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data* params =\n      reinterpret_cast<\n          internal::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data*>(\n              message->mutable_payload());'
            l_1_desc = str_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ' response', ))
            _loop_vars['desc'] = l_1_desc
            yield '\n  '
            yield str(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'response_param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'true', _loop_vars=_loop_vars))
            yield '\n  if (!callback_.is_null())\n    std::move(callback_).Run('
            yield str(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'response_parameters'), _loop_vars=_loop_vars))
            yield ');\n  return true;\n}\n\nvoid '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ProxyToResponder::Run(\n    '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), 'in_', environment.getattr(l_1_method, 'response_parameters'), _loop_vars=_loop_vars))
            yield ') {\n#if BUILDFLAG(MOJO_TRACE_ENABLED)'
            l_1_event_name = ('Send reply %s::%s::%s' % ((undefined(name='namespace_as_string') if l_0_namespace_as_string is missing else l_0_namespace_as_string), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), environment.getattr(l_1_method, 'name')))
            _loop_vars['event_name'] = l_1_event_name
            yield '\n  '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'trace_event'), prefix='in_', method_parameters=environment.getattr(l_1_method, 'response_parameters'), method_name=(undefined(name='event_name') if l_1_event_name is missing else l_1_event_name), parameter_group='async_response_parameters', dereference_parameters=False, _loop_vars=_loop_vars))
            yield '\n#endif\n'
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_message_flags'), True, 'is_sync_', 'true', 'false', 'false', 'kFlags', _loop_vars=_loop_vars))
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'build_serialized_message'), (undefined(name='message_name') if l_1_message_name is missing else l_1_message_name), l_1_method, 'in_%s', (undefined(name='response_params_struct') if l_1_response_params_struct is missing else l_1_response_params_struct), (undefined(name='response_params_description') if l_1_response_params_description is missing else l_1_response_params_description), 'kFlags', 'message', _loop_vars=_loop_vars))
            yield '\n\n#if defined(ENABLE_IPC_FUZZER)\n  message.set_interface_name('
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::Name_);\n  message.set_method_name("'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '");\n#endif\n\n  message.set_request_id(request_id_);\n  message.set_trace_nonce(trace_nonce_);\n  ::mojo::internal::SendMojoMessage(*responder_, message);\n  // SendMojoMessage() fails silently if the responder connection is closed,\n  // or if the message is malformed.\n  //\n  // TODO(darin): If Accept() returns false due to a malformed message, that\n  // may be good reason to close the connection. However, we don\'t have a\n  // way to do that from here. We should add a way.\n  responder_ = nullptr;\n}'
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\nbool '
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_HandleSyncResponse::Accept(\n    mojo::Message* message) {\n  DCHECK(message->is_serialized());\n  internal::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data* params =\n      reinterpret_cast<internal::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '_'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '_ResponseParams_Data*>(\n          message->mutable_payload());'
            l_1_desc = str_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ' response', ))
            _loop_vars['desc'] = l_1_desc
            yield '\n  '
            yield str(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'response_param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'true', _loop_vars=_loop_vars))
            for l_2_param in environment.getattr(l_1_method, 'response_parameters'):
                _loop_vars = {}
                pass
                yield '\n  *out_'
                yield str(environment.getattr(l_2_param, 'name'))
                yield '_ = std::move(p_'
                yield str(environment.getattr(l_2_param, 'name'))
                yield ');'
            l_2_param = missing
            yield '\n  *result_ = true;\n  return true;\n}'
    l_1_method = l_1_message_name = l_1_response_params_struct = l_1_params_description = l_1_response_message_typename = l_1_desc = l_1_event_name = l_1_response_params_description = missing
    yield '\n\n// static\nbool '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'StubDispatch::Accept(\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl,\n    mojo::Message* message) {'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'dispatch_debug_alias'):
            pass
            yield '\n  const uint64_t kDebugAliasSentinel0 = 0xC0FFEE42;\n  const uint64_t kMessageName = message->header()->name;\n  const uint64_t kDebugAliasSentinel1 = 0xDECAFBAD;\n  base::debug::Alias(&kDebugAliasSentinel0);\n  base::debug::Alias(&kMessageName);\n  base::debug::Alias(&kDebugAliasSentinel1);'
        yield '\n  switch (static_cast<messages::'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '>(message->header()->name)) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_desc = resolve('desc')
            _loop_vars = {}
            pass
            yield '\n    case messages::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield ': {'
            if (environment.getattr(l_1_method, 'response_parameters') == None):
                pass
                yield '\n      DCHECK(message->is_serialized());\n      internal::'
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data* params =\n          reinterpret_cast<internal::'
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data*>(\n              message->mutable_payload());'
                l_1_desc = str_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ))
                _loop_vars['desc'] = l_1_desc
                yield '\n      '
                yield str(t_11(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'false', _loop_vars=_loop_vars), 4))
                yield '\n      // A null |impl| means no implementation was bound.\n      DCHECK(impl);\n      impl->'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '('
                yield str(t_11(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'parameters'), _loop_vars=_loop_vars), 8, True))
                yield ');\n      return true;'
            else:
                pass
                yield '\n      break;'
            yield '\n    }'
        l_1_method = l_1_desc = missing
        yield '\n  }'
    yield '\n  return false;\n}\n\n// static\nbool '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'StubDispatch::AcceptWithResponder(\n    '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '* impl,\n    mojo::Message* message,\n    std::unique_ptr<mojo::MessageReceiverWithStatus> responder) {'
    if environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\n  [[maybe_unused]] const bool message_is_sync =\n      message->has_flag(mojo::Message::kFlagIsSync);\n  [[maybe_unused]] const uint64_t request_id = message->request_id();\n  switch (static_cast<messages::'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield '>(message->header()->name)) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_desc = resolve('desc')
            _loop_vars = {}
            pass
            yield '\n    case messages::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield ': {'
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                yield '\n      internal::'
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data* params =\n          reinterpret_cast<\n              internal::'
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_Params_Data*>(\n                  message->mutable_payload());'
                l_1_desc = str_join(((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), '::', environment.getattr(l_1_method, 'name'), ))
                _loop_vars['desc'] = l_1_desc
                yield '\n      '
                yield str(t_11(context.call((undefined(name='alloc_params') if l_0_alloc_params is missing else l_0_alloc_params), environment.getattr(l_1_method, 'param_struct'), 'params', 'message', environment.getattr(l_1_method, 'sequential_ordinal'), 'false', _loop_vars=_loop_vars), 4))
                yield '\n      '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '::'
                yield str(environment.getattr(l_1_method, 'name'))
                yield 'Callback callback =\n          '
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_ProxyToResponder::CreateCallback(\n              *message, std::move(responder));\n      // A null |impl| means no implementation was bound.\n      DCHECK(impl);\n      impl->'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '('
                if environment.getattr(l_1_method, 'parameters'):
                    pass
                    yield str(t_11(context.call((undefined(name='pass_params') if l_0_pass_params is missing else l_0_pass_params), environment.getattr(l_1_method, 'parameters'), _loop_vars=_loop_vars), 8, True))
                    yield ', '
                yield 'std::move(callback));\n      return true;'
            else:
                pass
                yield '\n      break;'
            yield '\n    }'
        l_1_method = l_1_desc = missing
        yield '\n  }'
    yield '\n  return false;\n}'
    if t_20(context, environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), 'runtime_feature'):
        pass
        yield '\nnamespace {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            _loop_vars = {}
            pass
            if environment.getattr(l_1_method, 'runtime_feature'):
                pass
                yield '\n'
                yield str(context.call((undefined(name='define_validate_with_runtime_feature') if l_0_define_validate_with_runtime_feature is missing else l_0_define_validate_with_runtime_feature), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), l_1_method, _loop_vars=_loop_vars))
        l_1_method = missing
        yield '\n}  // namespace'
    if (environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods') and t_10((undefined(name='interface') if l_0_interface is missing else l_0_interface))):
        pass
        yield '\nstatic const mojo::internal::GenericValidationInfo k'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo[] = {'
        for l_1_i in context.call((undefined(name='range') if l_0_range is missing else l_0_range), (t_18(environment, t_17(context, environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), attribute='ordinal')) + 1)):
            l_1_method = missing
            _loop_vars = {}
            pass
            l_1_method = environment.getitem(t_16(context.eval_ctx, t_20(context, environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), 'ordinal', 'equalto', l_1_i)), 0)
            _loop_vars['method'] = l_1_method
            if (undefined(name='method') if l_1_method is missing else l_1_method):
                pass
                yield '\n    { '
                yield str(context.call((undefined(name='request_validator') if l_0_request_validator is missing else l_0_request_validator), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), (undefined(name='method') if l_1_method is missing else l_1_method), _loop_vars=_loop_vars))
                yield ','
                if (environment.getattr((undefined(name='method') if l_1_method is missing else l_1_method), 'response_parameters') != None):
                    pass
                    yield '\n     &internal::'
                    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                    yield '_'
                    yield str(environment.getattr((undefined(name='method') if l_1_method is missing else l_1_method), 'name'))
                    yield '_ResponseParams_Data::Validate},'
                else:
                    pass
                    yield '\n     nullptr /* no response */},'
            else:
                pass
                yield '\n    {nullptr, nullptr},  // nonexistent'
        l_1_i = l_1_method = missing
        yield '\n};'
    elif environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        pass
        yield '\nstatic const std::pair<uint32_t, mojo::internal::GenericValidationInfo> k'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo[] = {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            _loop_vars = {}
            pass
            yield '\n    {base::to_underlying(messages::'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield '::k'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '),\n     { '
            yield str(context.call((undefined(name='request_validator') if l_0_request_validator is missing else l_0_request_validator), (undefined(name='class_name') if l_0_class_name is missing else l_0_class_name), l_1_method, _loop_vars=_loop_vars))
            yield ','
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                yield '\n      &internal::'
                yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
                yield '_'
                yield str(environment.getattr(l_1_method, 'name'))
                yield '_ResponseParams_Data::Validate}},'
            else:
                pass
                yield '\n      nullptr /* no response */}},'
        l_1_method = missing
        yield '\n};'
    yield '\n\nbool '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield 'RequestValidator::Accept(mojo::Message* message) {\n  const char* name = '
    yield str((undefined(name='qualified_class_name') if l_0_qualified_class_name is missing else l_0_qualified_class_name))
    yield '::Name_;'
    if (not environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n  return mojo::internal::ValidateRequestGeneric(message, name, {});'
    elif t_10((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  return mojo::internal::ValidateRequestGenericPacked(message, name, k'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo);'
    else:
        pass
        yield '\n  return mojo::internal::ValidateRequestGeneric(message, name, k'
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ValidationInfo);'
    yield '\n}\n'
    if t_8((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\nbool '
        yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
        yield 'ResponseValidator::Accept(mojo::Message* message) {\n  const char* name = '
        yield str((undefined(name='qualified_class_name') if l_0_qualified_class_name is missing else l_0_qualified_class_name))
        yield '::Name_;'
        if t_10((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
            pass
            yield '\n  return mojo::internal::ValidateResponseGenericPacked(message, name, k'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield 'ValidationInfo);'
        else:
            pass
            yield '\n  return mojo::internal::ValidateResponseGeneric(message, name, k'
            yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
            yield 'ValidationInfo);\n'
        yield '\n}'

blocks = {}
debug_info = '1=136&2=138&4=140&5=143&6=146&7=149&8=152&10=155&12=170&14=175&15=178&16=180&17=184&20=193&23=203&24=209&27=211&29=213&34=223&35=229&36=232&37=236&39=242&41=245&45=254&46=260&48=263&49=265&52=267&59=275&60=281&61=283&62=286&67=292&68=300&69=303&71=307&74=309&79=317&80=324&81=328&83=336&88=345&89=351&90=354&94=356&95=359&96=362&98=373&102=381&104=385&105=388&106=390&107=394&108=398&118=405&120=407&123=410&124=412&125=416&126=420&130=428&131=430&132=434&133=438&150=447&151=451&159=455&167=463&168=466&171=467&172=470&173=473&180=480&181=483&182=485&183=488&186=492&188=496&189=500&192=505&193=509&198=515&199=523&204=531&205=535&210=542&213=546&214=550&218=554&219=562&223=570&228=576&230=580&232=583&233=587&234=589&236=592&245=597&246=602&248=604&249=606&251=608&253=610&254=613&255=617&257=619&259=622&266=624&267=627&269=629&273=631&274=638&279=645&282=647&287=649&288=651&293=653&295=657&296=661&300=664&311=667&312=671&314=673&316=676&321=678&322=679&329=686&334=693&337=695&342=697&343=699&346=701&347=704&350=706&352=709&364=718&365=728&366=730&368=732&369=734&371=736&373=739&375=743&378=747&379=751&381=755&385=759&402=763&411=767&419=771&422=773&425=777&427=781&430=785&431=788&433=790&437=792&438=796&440=798&442=801&448=803&450=805&455=807&456=809&472=811&473=814&476=818&477=822&480=826&481=829&483=830&484=834&496=842&497=844&499=846&500=848&508=852&509=854&510=859&511=863&513=866&514=870&517=874&519=877&522=879&535=890&536=892&539=894&543=897&544=899&545=904&546=908&547=911&549=915&552=919&554=922&555=924&556=928&560=932&561=934&574=946&576=949&577=952&578=955&585=958&586=961&587=963&588=967&589=969&590=972&591=974&592=977&601=989&602=992&603=994&604=998&605=1002&606=1004&607=1007&617=1017&619=1019&620=1021&622=1024&623=1027&625=1032&630=1035&631=1038&632=1040&633=1042&634=1045&636=1050'