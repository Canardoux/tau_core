from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'validation_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_validate_object = l_0_validate_handle_or_interface = l_0_validate_enum = l_0_validate_field = missing
    try:
        t_1 = environment.filters['get_container_validate_params_ctor_args']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_container_validate_params_ctor_args' found.")
    try:
        t_2 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_3 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_4 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_5 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_6 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_7 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_8 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_9 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_10 = environment.filters['is_string_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_string_kind' found.")
    try:
        t_11 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_12 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    pass
    def macro(l_1_field, l_1_field_index, l_1_field_expr, l_1_union_is_inlined):
        t_13 = []
        l_1_name = l_1_kind = missing
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_field_index is missing:
            l_1_field_index = undefined("parameter 'field_index' was not provided", name='field_index')
        if l_1_field_expr is missing:
            l_1_field_expr = undefined("parameter 'field_expr' was not provided", name='field_expr')
        if l_1_union_is_inlined is missing:
            l_1_union_is_inlined = undefined("parameter 'union_is_inlined' was not provided", name='union_is_inlined')
        pass
        l_1_name = environment.getattr(l_1_field, 'name')
        l_1_kind = environment.getattr(l_1_field, 'kind')
        if (not t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
            pass
            if (t_12((undefined(name='kind') if l_1_kind is missing else l_1_kind)) and l_1_union_is_inlined):
                pass
                t_13.extend((
                    '\n  if (!mojo::internal::ValidateInlinedUnionNonNullable(\n          ',
                    str(l_1_field_expr),
                    ', ',
                    str(l_1_field_index),
                    ', validation_context)) {\n    return false;\n  }',
                ))
            else:
                pass
                t_13.extend((
                    '\n  if (!mojo::internal::ValidatePointerNonNullable(\n          ',
                    str(l_1_field_expr),
                    ', ',
                    str(l_1_field_index),
                    ', validation_context)) {\n    return false;\n  }',
                ))
        if ((t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)) or t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind))) or t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
            pass
            t_13.extend((
                '\n  constexpr const mojo::internal::ContainerValidateParams& ',
                str((undefined(name='name') if l_1_name is missing else l_1_name)),
                '_validate_params =\n      ',
                str(t_3(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)), 6)),
                ';\n  if (!mojo::internal::ValidateContainer(',
                str(l_1_field_expr),
                ', validation_context,\n                                         &',
                str((undefined(name='name') if l_1_name is missing else l_1_name)),
                '_validate_params)) {\n    return false;\n  }',
            ))
        elif t_11((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            t_13.extend((
                '\n  if (!mojo::internal::ValidateStruct(',
                str(l_1_field_expr),
                ', validation_context))\n    return false;',
            ))
        elif t_12((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            if l_1_union_is_inlined:
                pass
                t_13.extend((
                    '\n  if (!mojo::internal::ValidateInlinedUnion(',
                    str(l_1_field_expr),
                    ', validation_context))\n    return false;',
                ))
            else:
                pass
                t_13.extend((
                    '\n  if (!mojo::internal::ValidateNonInlinedUnion(',
                    str(l_1_field_expr),
                    ',\n                                               validation_context))\n    return false;',
                ))
        else:
            pass
            t_13.append(
                '\n#error Not reached!',
            )
        return concat(t_13)
    context.exported_vars.add('validate_object')
    context.vars['validate_object'] = l_0_validate_object = Macro(environment, macro, 'validate_object', ('field', 'field_index', 'field_expr', 'union_is_inlined'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_field_index, l_1_field_expr):
        t_14 = []
        l_1_name = l_1_kind = missing
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_field_index is missing:
            l_1_field_index = undefined("parameter 'field_index' was not provided", name='field_index')
        if l_1_field_expr is missing:
            l_1_field_expr = undefined("parameter 'field_expr' was not provided", name='field_expr')
        pass
        l_1_name = environment.getattr(l_1_field, 'name')
        l_1_kind = environment.getattr(l_1_field, 'kind')
        if (not t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
            pass
            t_14.extend((
                '\n  if (!mojo::internal::ValidateHandleOrInterfaceNonNullable(\n          ',
                str(l_1_field_expr),
                ', ',
                str(l_1_field_index),
                ', validation_context)) {\n    return false;\n  }',
            ))
        t_14.extend((
            '\n  if (!mojo::internal::ValidateHandleOrInterface(',
            str(l_1_field_expr),
            ',\n                                                 validation_context)) {\n    return false;\n  }',
        ))
        return concat(t_14)
    context.exported_vars.add('validate_handle_or_interface')
    context.vars['validate_handle_or_interface'] = l_0_validate_handle_or_interface = Macro(environment, macro, 'validate_handle_or_interface', ('field', 'field_index', 'field_expr'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_field_expr):
        t_15 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_field_expr is missing:
            l_1_field_expr = undefined("parameter 'field_expr' was not provided", name='field_expr')
        pass
        t_15.extend((
            '\n  if (!',
            str(t_2(environment.getattr(l_1_field, 'kind'), internal=True, flatten_nested_kind=True)),
            '\n        ::Validate(',
            str(l_1_field_expr),
            ', validation_context))\n    return false;',
        ))
        return concat(t_15)
    context.exported_vars.add('validate_enum')
    context.vars['validate_enum'] = l_0_validate_enum = Macro(environment, macro, 'validate_enum', ('field', 'field_expr'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_field_index, l_1_field_expr, l_1_union_is_inlined):
        t_16 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_field_index is missing:
            l_1_field_index = undefined("parameter 'field_index' was not provided", name='field_index')
        if l_1_field_expr is missing:
            l_1_field_expr = undefined("parameter 'field_expr' was not provided", name='field_expr')
        if l_1_union_is_inlined is missing:
            l_1_union_is_inlined = undefined("parameter 'union_is_inlined' was not provided", name='union_is_inlined')
        pass
        if t_9(environment.getattr(l_1_field, 'kind')):
            pass
            t_16.append(
                str(context.call((undefined(name='validate_object') if l_0_validate_object is missing else l_0_validate_object), l_1_field, l_1_field_index, l_1_field_expr, l_1_union_is_inlined)),
            )
        elif t_4(environment.getattr(l_1_field, 'kind')):
            pass
            t_16.append(
                str(context.call((undefined(name='validate_handle_or_interface') if l_0_validate_handle_or_interface is missing else l_0_validate_handle_or_interface), l_1_field, l_1_field_index, l_1_field_expr)),
            )
        elif t_6(environment.getattr(l_1_field, 'kind')):
            pass
            t_16.extend((
                '\n',
                str(context.call((undefined(name='validate_enum') if l_0_validate_enum is missing else l_0_validate_enum), l_1_field, l_1_field_expr)),
            ))
        return concat(t_16)
    context.exported_vars.add('validate_field')
    context.vars['validate_field'] = l_0_validate_field = Macro(environment, macro, 'validate_field', ('field', 'field_index', 'field_expr', 'union_is_inlined'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '5=84&6=96&7=97&8=98&9=100&11=104&16=113&21=118&22=122&23=124&24=126&25=128&28=131&29=135&31=138&32=140&33=144&36=151&48=162&49=172&50=173&51=174&53=178&57=185&65=191&66=200&67=202&71=208&72=219&73=222&74=224&75=227&76=229&77=233'