from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_namespace = resolve('namespace')
    l_0_validation_macros = l_0_class_name = l_0_ns = missing
    try:
        t_1 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_2 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_3 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_4 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    pass
    l_0_validation_macros = context.vars['validation_macros'] = environment.get_template('validation_macros.tmpl', 'struct_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('validation_macros')
    l_0_class_name = str_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    yield '\n\n// static\nbool '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  if (!data)\n    return true;'
    if (t_4(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions')) == 1):
        pass
        yield '\n  if (!ValidateUnversionedStructHeaderAndSizeAndClaimMemory(\n          data, '
        yield str(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), 0), 'num_bytes'))
        yield ', validation_context)) {\n    return false;\n  }'
    else:
        pass
        yield '\n  static constexpr mojo::internal::StructVersionSize kVersionSizes[] = {'
        for l_1_version in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
            _loop_vars = {}
            pass
            yield '\n    { '
            yield str(environment.getattr(l_1_version, 'version'))
            yield ', '
            yield str(environment.getattr(l_1_version, 'num_bytes'))
            yield ' },'
        l_1_version = missing
        yield '\n  };\n  if (!ValidateStructHeaderAndVersionSizeAndClaimMemory(\n          data, kVersionSizes, validation_context)) {\n    return false;\n  }'
    yield '\n\n  // NOTE: The memory backing |object| may be smaller than |sizeof(*object)| if\n  // the message comes from an older version.\n  [[maybe_unused]] const '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '* object =\n      static_cast<const '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '*>(data);'
    l_0_ns = context.call((undefined(name='namespace') if l_0_namespace is missing else l_0_namespace), last_checked_version=0)
    context.vars['ns'] = l_0_ns
    context.exported_vars.add('ns')
    l_1_loop = missing
    for l_1_packed_field, l_1_loop in LoopContext(environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'), undefined):
        l_1_field_expr = resolve('field_expr')
        l_1_kind = missing
        _loop_vars = {}
        pass
        l_1_kind = environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')
        _loop_vars['kind'] = l_1_kind
        if ((t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)) or t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind))) or t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
            pass
            if (environment.getattr(l_1_packed_field, 'min_version') > environment.getattr((undefined(name='ns') if l_0_ns is missing else l_0_ns), 'last_checked_version')):
                pass
                if not isinstance(l_0_ns, Namespace):
                    raise TemplateRuntimeError("cannot assign attribute on non-namespace object")
                l_0_ns['last_checked_version'] = environment.getattr(l_1_packed_field, 'min_version')
                yield '\n  if (object->header_.version < '
                yield str(environment.getattr(l_1_packed_field, 'min_version'))
                yield ')\n    return true;'
            l_1_field_expr = str_join(('object->', environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'), ))
            _loop_vars['field_expr'] = l_1_field_expr
            yield '\n'
            yield str(context.call(environment.getattr((undefined(name='validation_macros') if l_0_validation_macros is missing else l_0_validation_macros), 'validate_field'), environment.getattr(l_1_packed_field, 'field'), environment.getattr(l_1_loop, 'index'), (undefined(name='field_expr') if l_1_field_expr is missing else l_1_field_expr), True, _loop_vars=_loop_vars))
    l_1_loop = l_1_packed_field = l_1_kind = l_1_field_expr = missing
    yield '\n\n  return true;\n}\n\n'
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '::'
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '()\n    : header_({sizeof(*this), '
    yield str(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'version'))
    yield '}) {}'

blocks = {}
debug_info = '1=38&2=40&5=44&11=46&13=49&18=54&19=58&30=65&31=67&37=69&38=73&39=78&40=80&42=82&43=84&44=88&47=90&48=93&55=96&56=100'