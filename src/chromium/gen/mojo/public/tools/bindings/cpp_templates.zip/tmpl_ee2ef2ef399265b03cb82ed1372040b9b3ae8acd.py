from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_data_view = l_0_data_type = missing
    try:
        t_1 = environment.filters['get_container_validate_params_ctor_args']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_container_validate_params_ctor_args' found.")
    try:
        t_2 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_3 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_4 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_5 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_6 = environment.filters['is_associated_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_associated_kind' found.")
    try:
        t_7 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_8 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_9 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_10 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_11 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_12 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_13 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    l_0_data_view = str_join((t_2((undefined(name='union') if l_0_union is missing else l_0_union)), 'DataView', ))
    context.vars['data_view'] = l_0_data_view
    context.exported_vars.add('data_view')
    l_0_data_type = t_2((undefined(name='union') if l_0_union is missing else l_0_union), internal=True)
    context.vars['data_type'] = l_0_data_type
    context.exported_vars.add('data_type')
    yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = UnionTraits<'
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ', UserType>;\n\n  static void Serialize(MaybeConstUserType& input,\n                        MessageFragment<'
    yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '>& fragment,\n                        bool inlined) {\n    if (CallIsNullIfExists<Traits>(input)) {\n       if (inlined)\n        fragment->set_null();\n      return;\n    }\n\n    if (!inlined)\n      fragment.Allocate();\n\n    // TODO(azani): Handle unknown and objects.\n    // Set the not-null flag.\n    fragment->size = kUnionDataSize;\n    fragment->tag = Traits::GetTag(input);\n    switch (fragment->tag) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_name = l_1_kind = l_1_serializer_type = missing
        _loop_vars = {}
        pass
        l_1_name = environment.getattr(l_1_field, 'name')
        _loop_vars['name'] = l_1_name
        l_1_kind = environment.getattr(l_1_field, 'kind')
        _loop_vars['kind'] = l_1_kind
        l_1_serializer_type = t_13((undefined(name='kind') if l_1_kind is missing else l_1_kind))
        _loop_vars['serializer_type'] = l_1_serializer_type
        yield '\n      case '
        yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield '::Tag::k'
        yield str(t_12(environment.getattr(l_1_field, 'name')))
        yield ': {\n        decltype(Traits::'
        yield str((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '(input))\n            in_'
        yield str((undefined(name='name') if l_1_name is missing else l_1_name))
        yield ' = Traits::'
        yield str((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '(input);'
        if t_10((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::MessageFragment<\n            typename decltype(fragment->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ')::BaseType>\n            value_fragment(fragment.message());'
            if t_11((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                pass
                yield '\n        mojo::internal::Serialize<'
                yield str((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment, false);'
            elif (t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)) or t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        constexpr const mojo::internal::ContainerValidateParams& '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '_validate_params =\n            '
                yield str(t_3(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)), 6))
                yield ';\n        mojo::internal::Serialize<'
                yield str((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment, &'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '_validate_params);'
            else:
                pass
                yield '\n        mojo::internal::Serialize<'
                yield str((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
                yield '>(\n            in_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ', value_fragment);'
            if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n            value_fragment.is_null(),\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_NULL_POINTER,\n            "null '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' in '
                yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
                yield ' union");'
            yield '\n        fragment->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Set(\n            value_fragment.is_null() ? nullptr : value_fragment.data());'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::Serialize<'
            yield str((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
            yield '>(\n            in_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment.message());'
            if (not t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n        MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n            !mojo::internal::IsHandleOrInterfaceValid(fragment->data.f_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '),'
                if t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
                    pass
                    yield '\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_INTERFACE_ID,'
                else:
                    pass
                    yield '\n            mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_HANDLE,'
                yield '\n            "invalid '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ' in '
                yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
                yield ' union");'
        elif t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n        mojo::internal::Serialize<'
            yield str((undefined(name='serializer_type') if l_1_serializer_type is missing else l_1_serializer_type))
            yield '>(\n            in_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &fragment->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ');'
        else:
            pass
            yield '\n        fragment->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ' = in_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';'
        yield '\n        break;\n      }'
    l_1_field = l_1_name = l_1_kind = l_1_serializer_type = missing
    yield '\n    }\n  }\n\n  static bool Deserialize('
    yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
    yield '* input,\n                          UserType* output,\n                          Message* message) {\n    if (!input || input->is_null())\n      return CallSetToNullIfExists<Traits>(output);\n\n    '
    yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
    yield ' data_view(input, message);\n    return Traits::Read(data_view, output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=91&2=94&7=98&9=100&12=102&28=104&29=108&30=110&31=112&32=115&33=119&34=121&35=125&37=128&39=130&40=133&41=135&42=137&43=140&44=142&45=144&46=146&48=153&49=155&51=157&55=160&57=165&60=167&61=170&62=172&63=176&65=179&66=181&71=188&74=192&75=195&76=197&79=204&87=211&93=213'