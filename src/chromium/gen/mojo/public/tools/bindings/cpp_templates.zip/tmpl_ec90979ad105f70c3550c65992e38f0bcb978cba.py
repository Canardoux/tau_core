from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_traits_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_mojom_type = missing
    try:
        t_1 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_2 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_3 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_4 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_5 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_6 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_7 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_8 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    l_0_mojom_type = t_2((undefined(name='union') if l_0_union is missing else l_0_union))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\n// static\nbool UnionTraits<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView, '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr>::Read(\n    '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input,\n    '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) {\n  using UnionType = '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield ';\n  using Tag = UnionType::Tag;\n\n  switch (input.tag()) {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_name = l_1_kind = l_1_serializer_type = missing
        _loop_vars = {}
        pass
        yield '\n    case Tag::k'
        yield str(t_7(environment.getattr(l_1_field, 'name')))
        yield ': {'
        l_1_name = environment.getattr(l_1_field, 'name')
        _loop_vars['name'] = l_1_name
        l_1_kind = environment.getattr(l_1_field, 'kind')
        _loop_vars['kind'] = l_1_kind
        l_1_serializer_type = t_8((undefined(name='kind') if l_1_kind is missing else l_1_kind))
        _loop_vars['serializer_type'] = l_1_serializer_type
        if t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield ' result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n      if (!input.Read'
            yield str(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(&result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '))\n        return false;\n\n      *output = UnionType::New'
            yield str(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          std::move(result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '));'
        elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      *output = UnionType::New'
            yield str(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          input.Take'
            yield str(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '());'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      *output = UnionType::New'
            yield str(t_7(environment.getattr(l_1_field, 'name')))
            yield '(\n          input.Take'
            yield str(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '<'
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield '>());'
        elif t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n      '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind), True))
            yield ' result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n      if (!input.Read'
            yield str(t_7((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(&result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '))\n        return false;\n\n      *output = UnionType::New'
            yield str(t_7(environment.getattr(l_1_field, 'name')))
            yield '(result_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ');'
        else:
            pass
            yield '\n      *output = UnionType::New'
            yield str(t_7(environment.getattr(l_1_field, 'name')))
            yield '(input.'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());'
        yield '\n      break;\n    }'
    l_1_field = l_1_name = l_1_kind = l_1_serializer_type = missing
    yield '\n    default:\n'
    if environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'extensible'):
        pass
        yield '\n      *output = UnionType::New'
        yield str(t_7(environment.getattr(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'default_field'), 'name')))
        yield '({});\n      return true;'
    else:
        pass
        yield '\n      return false;'
    yield '\n  }\n  return true;\n}'

blocks = {}
debug_info = '1=61&4=65&5=69&6=71&7=73&11=75&12=80&13=82&14=84&15=86&16=88&17=91&18=95&21=99&22=101&23=103&24=106&25=108&27=110&28=113&29=115&31=119&32=122&33=126&36=130&38=137&44=144&45=147'