from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-params-data.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_include_guard = l_0_namespace_begin = l_0_namespace_end = l_0_header_guard = missing
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-params-data.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-params-data.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-params-data.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-params-data.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    context.vars.update({'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})
    context.exported_vars.difference_update(('include_guard', 'namespace_begin', 'namespace_end'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'PARAMS_DATA', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "mojo/public/cpp/bindings/lib/bindings_internal.h"\n#include "mojo/public/cpp/bindings/lib/buffer.h"\n\n#if defined(__clang__)\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wunused-private-field"\n#endif\n\nnamespace mojo::internal {\nclass ValidationContext;\n}\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\nnamespace internal {'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            _loop_vars = {}
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            _loop_vars['struct'] = l_2_struct
            yield '\n'
            template = environment.get_template('struct_declaration.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                _loop_vars['struct'] = l_2_struct
                yield '\n'
                template = environment.get_template('struct_declaration.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    yield '\n\n}  // namespace internal'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            _loop_vars = {}
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            _loop_vars['struct'] = l_2_struct
            yield '\n'
            template = environment.get_template('struct_data_view_declaration.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                _loop_vars['struct'] = l_2_struct
                yield '\n'
                template = environment.get_template('struct_data_view_declaration.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_struct = missing
            _loop_vars = {}
            pass
            l_2_struct = environment.getattr(l_2_method, 'param_struct')
            _loop_vars['struct'] = l_2_struct
            yield '\n'
            template = environment.get_template('struct_data_view_definition.tmpl', 'module-params-data.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                yield event
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_struct = environment.getattr(l_2_method, 'response_param_struct')
                _loop_vars['struct'] = l_2_struct
                yield '\n'
                template = environment.get_template('struct_data_view_definition.tmpl', 'module-params-data.h.tmpl')
                for event in template.root_render_func(template.new_context(context.get_all(), True, {'method': l_2_method, 'struct': l_2_struct, 'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end})):
                    yield event
        l_2_method = l_2_struct = missing
    l_1_interface = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n#if defined(__clang__)\n#pragma clang diagnostic pop\n#endif\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=17&8=29&10=33&11=35&25=37&29=39&30=42&31=46&32=49&33=52&34=54&35=57&43=63&44=66&45=70&46=73&47=76&48=78&49=81&54=86&55=89&56=93&57=96&58=99&59=101&60=104&65=110&71=112'