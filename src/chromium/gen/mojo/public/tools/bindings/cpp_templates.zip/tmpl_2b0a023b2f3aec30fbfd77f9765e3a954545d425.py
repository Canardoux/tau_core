from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'cpp_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_namespace_begin = l_0_namespace_end = l_0_variant_path = l_0_include_guard = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_3 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_4 = environment.filters['replace']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'replace' found.")
    try:
        t_5 = environment.filters['upper']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'upper' found.")
    pass
    def macro(l_1_namespaces, l_1_variant):
        t_6 = []
        l_1_full_namespace = missing
        if l_1_namespaces is missing:
            l_1_namespaces = undefined("parameter 'namespaces' was not provided", name='namespaces')
        if l_1_variant is missing:
            l_1_variant = undefined("parameter 'variant' was not provided", name='variant')
        pass
        l_1_full_namespace = t_2(context.eval_ctx, l_1_namespaces, '::')
        if (t_3(l_1_namespaces) and l_1_variant):
            pass
            l_1_full_namespace = t_2(context.eval_ctx, ((undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace), l_1_variant), '::')
        elif l_1_variant:
            pass
            l_1_full_namespace = l_1_variant
        if (undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace):
            pass
            t_6.extend((
                '\nnamespace ',
                str((undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace)),
                ' {',
            ))
        return concat(t_6)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', ('namespaces', 'variant'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_namespaces, l_1_variant):
        t_7 = []
        l_1_full_namespace = missing
        if l_1_namespaces is missing:
            l_1_namespaces = undefined("parameter 'namespaces' was not provided", name='namespaces')
        if l_1_variant is missing:
            l_1_variant = undefined("parameter 'variant' was not provided", name='variant')
        pass
        l_1_full_namespace = t_2(context.eval_ctx, l_1_namespaces, '::')
        if (t_3(l_1_namespaces) and l_1_variant):
            pass
            l_1_full_namespace = t_2(context.eval_ctx, ((undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace), l_1_variant), '::')
        elif l_1_variant:
            pass
            l_1_full_namespace = l_1_variant
        if (undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace):
            pass
            t_7.extend((
                '\n}  // ',
                str((undefined(name='full_namespace') if l_1_full_namespace is missing else l_1_full_namespace)),
            ))
        return concat(t_7)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', ('namespaces', 'variant'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_path, l_1_variant):
        t_8 = []
        l_1_variant_path = l_0_variant_path
        if l_1_path is missing:
            l_1_path = undefined("parameter 'path' was not provided", name='path')
        if l_1_variant is missing:
            l_1_variant = undefined("parameter 'variant' was not provided", name='variant')
        pass
        if l_1_variant:
            pass
            l_1_variant_path = t_1('%s-%s', l_1_path, l_1_variant)
        else:
            pass
            l_1_variant_path = l_1_path
        t_8.append(
            str((undefined(name='variant_path') if l_1_variant_path is missing else l_1_variant_path)),
        )
        return concat(t_8)
    context.exported_vars.add('variant_path')
    context.vars['variant_path'] = l_0_variant_path = Macro(environment, macro, 'variant_path', ('path', 'variant'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_path, l_1_variant):
        t_9 = []
        l_1_header_guard = resolve('header_guard')
        l_1_upper_path = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_path is missing:
            l_1_path = undefined("parameter 'path' was not provided", name='path')
        if l_1_variant is missing:
            l_1_variant = undefined("parameter 'variant' was not provided", name='variant')
        pass
        l_1_upper_path = t_4(context.eval_ctx, t_4(context.eval_ctx, t_4(context.eval_ctx, t_5(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), l_1_path, l_1_variant)), '/', '_'), '.', '_'), '-', '_')
        if l_1_type:
            pass
            l_1_header_guard = t_1('%s_%s_H_', (undefined(name='upper_path') if l_1_upper_path is missing else l_1_upper_path), l_1_type)
        else:
            pass
            l_1_header_guard = t_1('%s_H_', (undefined(name='upper_path') if l_1_upper_path is missing else l_1_upper_path))
        t_9.append(
            str((undefined(name='header_guard') if l_1_header_guard is missing else l_1_header_guard)),
        )
        return concat(t_9)
    context.exported_vars.add('include_guard')
    context.vars['include_guard'] = l_0_include_guard = Macro(environment, macro, 'include_guard', ('type', 'path', 'variant'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '5=42&6=50&7=51&8=53&9=54&10=56&12=57&13=61&18=67&19=75&20=76&21=78&22=79&23=81&25=82&26=86&32=91&33=99&34=101&36=104&38=106&42=111&43=122&45=123&46=125&48=128&50=130'