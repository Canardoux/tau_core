from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_serialize = l_0_deserialize = l_0_assert_nullable_output_type_if_necessary = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['get_container_validate_params_ctor_args']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_container_validate_params_ctor_args' found.")
    try:
        t_3 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_4 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_5 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_6 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_7 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_8 = environment.filters['is_associated_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_associated_kind' found.")
    try:
        t_9 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_10 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_11 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_12 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_13 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_14 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_15 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_16 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_17 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_18 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    yield '\n\n'
    def macro(l_1_struct, l_1_struct_display_name, l_1_input_field_pattern, l_1_fragment, l_1_input_may_be_temp):
        t_19 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_struct_display_name is missing:
            l_1_struct_display_name = undefined("parameter 'struct_display_name' was not provided", name='struct_display_name')
        if l_1_input_field_pattern is missing:
            l_1_input_field_pattern = undefined("parameter 'input_field_pattern' was not provided", name='input_field_pattern')
        if l_1_fragment is missing:
            l_1_fragment = undefined("parameter 'fragment' was not provided", name='fragment')
        if l_1_input_may_be_temp is missing:
            l_1_input_may_be_temp = False
        pass
        t_19.extend((
            str(l_1_fragment),
            '.Allocate();',
        ))
        for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_original_field = resolve('original_field')
            l_2_has_value_pf = resolve('has_value_pf')
            l_2_value_pf = resolve('value_pf')
            l_2_input_field = resolve('input_field')
            l_2_name = resolve('name')
            l_2_kind = resolve('kind')
            l_2_serializer_type = resolve('serializer_type')
            l_2_original_input_field = resolve('original_input_field')
            _loop_vars = {}
            pass
            if t_13(l_2_pf):
                pass
                if t_15(l_2_pf):
                    pass
                    l_2_original_field = environment.getattr(l_2_pf, 'original_field')
                    _loop_vars['original_field'] = l_2_original_field
                    l_2_has_value_pf = l_2_pf
                    _loop_vars['has_value_pf'] = l_2_has_value_pf
                    l_2_value_pf = environment.getattr(l_2_pf, 'linked_value_packed_field')
                    _loop_vars['value_pf'] = l_2_value_pf
                    l_2_input_field = t_1(l_1_input_field_pattern, environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'name'))
                    _loop_vars['input_field'] = l_2_input_field
                    l_2_name = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'name')
                    _loop_vars['name'] = l_2_name
                    l_2_kind = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'kind')
                    _loop_vars['kind'] = l_2_kind
                    l_2_serializer_type = t_18(environment.getattr(environment.getattr((undefined(name='value_pf') if l_2_value_pf is missing else l_2_value_pf), 'field'), 'kind'))
                    _loop_vars['serializer_type'] = l_2_serializer_type
                    t_19.extend((
                        '\n  ',
                        str(l_1_fragment),
                        '->',
                        str(environment.getattr(environment.getattr((undefined(name='has_value_pf') if l_2_has_value_pf is missing else l_2_has_value_pf), 'field'), 'name')),
                        ' = ',
                        str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        '.has_value();',
                    ))
                    if t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_19.extend((
                            '\n  if (',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            '.has_value()) {\n    mojo::internal::Serialize<',
                            str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                            '>(\n        ',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            '.value(), &',
                            str(l_1_fragment),
                            '->',
                            str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_2_value_pf is missing else l_2_value_pf), 'field'), 'name')),
                            ');\n  } else {\n    ',
                            str(l_1_fragment),
                            '->',
                            str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_2_value_pf is missing else l_2_value_pf), 'field'), 'name')),
                            ' =\n        static_cast<int32_t>(',
                            str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                            '::kMinValue);\n  }',
                        ))
                    else:
                        pass
                        t_19.extend((
                            '\n  if (',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            '.has_value()) {\n    ',
                            str(l_1_fragment),
                            '->',
                            str(environment.getattr(environment.getattr((undefined(name='value_pf') if l_2_value_pf is missing else l_2_value_pf), 'field'), 'name')),
                            ' = ',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            '.value();\n  }',
                        ))
            else:
                pass
                l_2_input_field = t_1(l_1_input_field_pattern, environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                _loop_vars['input_field'] = l_2_input_field
                l_2_name = environment.getattr(environment.getattr(l_2_pf, 'field'), 'name')
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                _loop_vars['kind'] = l_2_kind
                l_2_serializer_type = t_18((undefined(name='kind') if l_2_kind is missing else l_2_kind))
                _loop_vars['serializer_type'] = l_2_serializer_type
                if (t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    l_2_original_input_field = t_1(l_1_input_field_pattern, (undefined(name='name') if l_2_name is missing else l_2_name))
                    _loop_vars['original_input_field'] = l_2_original_input_field
                    l_2_input_field = (t_1('in_%s', (undefined(name='name') if l_2_name is missing else l_2_name)) if l_1_input_may_be_temp else (undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field))
                    _loop_vars['input_field'] = l_2_input_field
                    if l_1_input_may_be_temp:
                        pass
                        t_19.extend((
                            '\n  decltype(',
                            str((undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field)),
                            ') in_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ' = ',
                            str((undefined(name='original_input_field') if l_2_original_input_field is missing else l_2_original_input_field)),
                            ';',
                        ))
                if t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                        pass
                        t_19.extend((
                            '\n  mojo::internal::MessageFragment<\n      typename decltype(',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ')::BaseType>\n      ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment(',
                            str(l_1_fragment),
                            '.message());\n  constexpr const mojo::internal::ContainerValidateParams& ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_validate_params =\n      ',
                            str(t_3(t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind)), 6)),
                            ';\n  mojo::internal::Serialize<',
                            str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                            '>(\n      ',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            ', ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment, &',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_validate_params);\n  ',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '.Set(\n      ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment.is_null() ? nullptr : ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment.data());',
                        ))
                    elif t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_19.extend((
                            '\n  mojo::internal::MessageFragment<decltype(',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ')>\n      ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment(',
                            str(l_1_fragment),
                            '.message());\n  ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment.Claim(&',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ');\n  mojo::internal::Serialize<',
                            str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                            '>(\n      ',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            ', ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment, true);',
                        ))
                    else:
                        pass
                        t_19.extend((
                            '\n  mojo::internal::MessageFragment<\n      typename decltype(',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ')::BaseType> ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment(\n          ',
                            str(l_1_fragment),
                            '.message());\n  mojo::internal::Serialize<',
                            str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                            '>(\n      ',
                            str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                            ', ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment);\n  ',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '.Set(\n      ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment.is_null() ? nullptr : ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '_fragment.data());',
                        ))
                    if (not t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                        pass
                        t_19.extend((
                            '\n  MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n      ',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '.is_null(),\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_NULL_POINTER,\n      "null ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ' in ',
                            str(l_1_struct_display_name),
                            '");',
                        ))
                elif t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_19.extend((
                        '\n  mojo::internal::Serialize<',
                        str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                        '>(\n      ',
                        str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ', &',
                        str(l_1_fragment),
                        '->',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ', &',
                        str(l_1_fragment),
                        '.message());',
                    ))
                    if (not t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                        pass
                        t_19.extend((
                            '\n  MOJO_INTERNAL_DLOG_SERIALIZATION_WARNING(\n      !mojo::internal::IsHandleOrInterfaceValid(',
                            str(l_1_fragment),
                            '->',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '),',
                        ))
                        if t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                            pass
                            t_19.append(
                                '\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_INTERFACE_ID,',
                            )
                        else:
                            pass
                            t_19.append(
                                '\n      mojo::internal::VALIDATION_ERROR_UNEXPECTED_INVALID_HANDLE,',
                            )
                        t_19.extend((
                            '\n      "invalid ',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ' in ',
                            str(l_1_struct_display_name),
                            '");',
                        ))
                elif t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_19.extend((
                        '\n  mojo::internal::Serialize<',
                        str((undefined(name='serializer_type') if l_2_serializer_type is missing else l_2_serializer_type)),
                        '>(\n      ',
                        str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ', &',
                        str(l_1_fragment),
                        '->',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                else:
                    pass
                    t_19.extend((
                        '\n  ',
                        str(l_1_fragment),
                        '->',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = ',
                        str((undefined(name='input_field') if l_2_input_field is missing else l_2_input_field)),
                        ';',
                    ))
        l_2_pf = l_2_original_field = l_2_has_value_pf = l_2_value_pf = l_2_input_field = l_2_name = l_2_kind = l_2_serializer_type = l_2_original_input_field = missing
        return concat(t_19)
    context.exported_vars.add('serialize')
    context.vars['serialize'] = l_0_serialize = Macro(environment, macro, 'serialize', ('struct', 'struct_display_name', 'input_field_pattern', 'fragment', 'input_may_be_temp'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct, l_1_input, l_1_output_field_pattern, l_1_success):
        t_20 = []
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_input is missing:
            l_1_input = undefined("parameter 'input' was not provided", name='input')
        if l_1_output_field_pattern is missing:
            l_1_output_field_pattern = undefined("parameter 'output_field_pattern' was not provided", name='output_field_pattern')
        if l_1_success is missing:
            l_1_success = undefined("parameter 'success' was not provided", name='success')
        pass
        for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_original_field = resolve('original_field')
            l_2_output_field = resolve('output_field')
            l_2_name = resolve('name')
            l_2_kind = resolve('kind')
            _loop_vars = {}
            pass
            if t_13(l_2_pf):
                pass
                if t_15(l_2_pf):
                    pass
                    l_2_original_field = environment.getattr(l_2_pf, 'original_field')
                    _loop_vars['original_field'] = l_2_original_field
                    l_2_output_field = t_1(l_1_output_field_pattern, environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'name'))
                    _loop_vars['output_field'] = l_2_output_field
                    l_2_name = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'name')
                    _loop_vars['name'] = l_2_name
                    l_2_kind = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'kind')
                    _loop_vars['kind'] = l_2_kind
                    if t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_20.extend((
                            '\n  if (',
                            str(l_1_success),
                            ' && !',
                            str(l_1_input),
                            '.Read',
                            str(t_17((undefined(name='name') if l_2_name is missing else l_2_name))),
                            '(&',
                            str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                            ')) {\n    ',
                            str(l_1_success),
                            ' = false;',
                        ))
                    else:
                        pass
                        t_20.extend((
                            '\n  if (',
                            str(l_1_success),
                            ') {\n    ',
                            str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                            ' = ',
                            str(l_1_input),
                            '.',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '();',
                        ))
                    t_20.append(
                        '\n  }',
                    )
            else:
                pass
                l_2_output_field = t_1(l_1_output_field_pattern, environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                _loop_vars['output_field'] = l_2_output_field
                l_2_name = environment.getattr(environment.getattr(l_2_pf, 'field'), 'name')
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                _loop_vars['kind'] = l_2_kind
                if (t_14((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_20.extend((
                        '\n  if (',
                        str(l_1_success),
                        ' && !',
                        str(l_1_input),
                        '.Read',
                        str(t_17((undefined(name='name') if l_2_name is missing else l_2_name))),
                        '(&',
                        str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                        '))\n    ',
                        str(l_1_success),
                        ' = false;',
                    ))
                elif t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_20.extend((
                        '\n  if (',
                        str(l_1_success),
                        ')\n    ',
                        str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                        ' = ',
                        str(l_1_input),
                        '.Take',
                        str(t_17((undefined(name='name') if l_2_name is missing else l_2_name))),
                        '();',
                    ))
                elif t_6((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_20.extend((
                        '\n  if (',
                        str(l_1_success),
                        ') {\n    ',
                        str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                        ' =\n        ',
                        str(l_1_input),
                        '.Take',
                        str(t_17((undefined(name='name') if l_2_name is missing else l_2_name))),
                        '<decltype(',
                        str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                        ')>();\n  }',
                    ))
                else:
                    pass
                    t_20.extend((
                        '\n  if (',
                        str(l_1_success),
                        ')\n    ',
                        str((undefined(name='output_field') if l_2_output_field is missing else l_2_output_field)),
                        ' = ',
                        str(l_1_input),
                        '.',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '();',
                    ))
        l_2_pf = l_2_original_field = l_2_output_field = l_2_name = l_2_kind = missing
        return concat(t_20)
    context.exported_vars.add('deserialize')
    context.vars['deserialize'] = l_0_deserialize = Macro(environment, macro, 'deserialize', ('struct', 'input', 'output_field_pattern', 'success'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_21 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_12(l_1_kind) and (not t_11(l_1_kind))):
            pass
            t_21.extend((
                '\nstatic_assert(\n    mojo::internal::IsValidUserTypeForOptionalValue<\n        ',
                str(t_18(l_1_kind)),
                ', UserType>(),\n    "Attempting to read the optional `',
                str(l_1_name),
                '` field into a type which "\n    "cannot represent a null value. Either wrap the destination object "\n    "with std::optional, ensure that any corresponding "\n    "{Struct/Union/Array/String}Traits define the necessary IsNull and "\n    "SetToNull methods, or use `MaybeRead',
                str(t_17(l_1_name)),
                '` instead "\n    "of `Read',
                str(t_17(l_1_name)),
                ' if you\'re fine with null values being "\n    "silently ignored in this case.");',
            ))
        return concat(t_21)
    context.exported_vars.add('assert_nullable_output_type_if_necessary')
    context.vars['assert_nullable_output_type_if_necessary'] = l_0_assert_nullable_output_type_if_necessary = Macro(environment, macro, 'assert_nullable_output_type_if_necessary', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '17=121&19=135&20=138&22=149&23=151&24=153&25=155&26=157&27=159&28=161&29=163&30=165&31=169&32=176&33=180&34=182&35=184&37=190&38=194&41=201&42=203&48=212&49=214&50=216&51=218&53=220&54=222&55=224&57=226&58=230&62=237&63=239&65=243&66=247&67=251&68=253&69=255&70=257&71=263&72=267&73=272&74=276&75=280&76=284&77=290&78=292&81=301&82=307&83=309&84=311&85=315&86=319&88=324&90=328&92=332&95=337&96=341&97=343&98=352&100=356&101=361&106=373&109=378&110=382&111=384&114=395&134=406&135=417&136=424&137=426&138=428&139=430&140=432&141=434&142=436&143=440&144=448&146=455&147=457&152=469&153=471&154=473&155=475&156=479&157=487&158=490&159=494&160=496&161=503&162=507&163=509&164=511&167=522&168=524&174=535&175=542&178=546&179=548&183=550&184=552'