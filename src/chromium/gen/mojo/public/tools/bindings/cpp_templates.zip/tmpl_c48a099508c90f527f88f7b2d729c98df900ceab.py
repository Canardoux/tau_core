from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_data_view_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_struct_macros = missing
    try:
        t_1 = environment.filters['cpp_data_view_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_data_view_type' found.")
    try:
        t_2 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_3 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_4 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_5 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_6 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_7 = environment.filters['requires_context_for_data_view']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'requires_context_for_data_view' found.")
    try:
        t_8 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    try:
        t_9 = environment.filters['unmapped_type_for_serializer']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'unmapped_type_for_serializer' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'union_data_view_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView {\n public:\n  using Tag = internal::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Tag;\n\n  '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView() = default;\n\n  '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield 'DataView(\n      internal::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data* data,\n      mojo::Message* message)'
    if t_7((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n      : data_(data), message_(message) {}'
    else:
        pass
        yield '\n      : data_(data) {}'
    yield '\n\n  bool is_null() const {\n    // For inlined unions, |data_| is always non-null. In that case we need to\n    // check |data_->is_null()|.\n    return !data_ || data_->is_null();\n  }\n\n  Tag tag() const { return data_->tag; }'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_kind = l_1_name = missing
        _loop_vars = {}
        pass
        l_1_kind = environment.getattr(l_1_field, 'kind')
        _loop_vars['kind'] = l_1_kind
        l_1_name = environment.getattr(l_1_field, 'name')
        _loop_vars['name'] = l_1_name
        yield '\n  bool is_'
        yield str((undefined(name='name') if l_1_name is missing else l_1_name))
        yield '() const { return data_->tag == Tag::k'
        yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
        yield '; }'
        if t_5((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  inline void Get'
            yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n      '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) const;\n\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) const {\n    '
            yield str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'assert_nullable_output_type_if_necessary'), (undefined(name='kind') if l_1_kind is missing else l_1_kind), (undefined(name='name') if l_1_name is missing else l_1_name), _loop_vars=_loop_vars))
            yield '\n    CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return mojo::internal::Deserialize<'
            yield str(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Get(), output, message_);\n  }'
        elif t_4((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  [[nodiscard]] bool Read'
            yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '(UserType* output) const {\n    CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return mojo::internal::Deserialize<'
            yield str(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n        data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', output);\n  }'
            if (not t_6((undefined(name='kind') if l_1_kind is missing else l_1_kind))):
                pass
                yield '\n  '
                yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ' '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '() const {\n    CHECK(is_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '());\n    // TODO(dcheng): This seems incorrect, as it bypasses enum traits.\n    return ::mojo::internal::ToKnownEnumValueHelper(\n        static_cast<'
                yield str(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield '>(data_->data.f_'
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '));\n  }'
        elif t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' Take'
            yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' result;\n    bool ret =\n        mojo::internal::Deserialize<'
            yield str(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    CHECK(ret);\n    return result;\n  }'
        elif t_3((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\n  template <typename UserType>\n  UserType Take'
            yield str(t_8((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield '() {\n    CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    UserType result;\n    bool ret =\n        mojo::internal::Deserialize<'
            yield str(t_9((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '>(\n            &data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ', &result, message_);\n    CHECK(ret);\n    return result;\n  }'
        else:
            pass
            yield '\n  '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield ' '
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '() const {\n    CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n    return data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield ';\n  }'
    l_1_field = l_1_kind = l_1_name = missing
    yield '\n\n private:\n  internal::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '_Data* data_ = nullptr;'
    if t_7((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\n  mojo::Message* message_ = nullptr;'
    yield '\n};\n'

blocks = {}
debug_info = '1=67&3=70&5=72&7=76&9=78&10=80&12=82&26=89&27=93&28=95&29=98&31=102&32=105&33=107&36=109&37=111&38=113&39=115&40=117&43=119&45=122&46=124&47=126&48=128&51=130&52=133&53=137&56=139&60=143&61=146&62=150&63=152&65=154&66=156&71=158&73=161&74=163&77=165&78=167&84=172&85=176&86=178&93=182&94=184'