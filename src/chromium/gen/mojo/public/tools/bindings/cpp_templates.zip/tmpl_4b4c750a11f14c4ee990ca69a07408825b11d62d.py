from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_contains_only_enums = resolve('contains_only_enums')
    l_0_imports = resolve('imports')
    l_0_for_blink = resolve('for_blink')
    l_0_disallow_interfaces = resolve('disallow_interfaces')
    l_0_uses_interfaces = resolve('uses_interfaces')
    l_0_disallow_native_types = resolve('disallow_native_types')
    l_0_uses_native_types = resolve('uses_native_types')
    l_0_extra_public_headers = resolve('extra_public_headers')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_typemap_forward_declarations = resolve('typemap_forward_declarations')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_namespace_begin = l_0_namespace_end = l_0_include_guard = l_0_variant_path = l_0_header_guard = l_0_kythe_annotation = l_0_module_prefix = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['format_enum_constant_declaration']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'format_enum_constant_declaration' found.")
    try:
        t_3 = environment.filters['has_callbacks']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'has_callbacks' found.")
    try:
        t_4 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_5 = environment.filters['is_full_header_required_for_import']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_full_header_required_for_import' found.")
    try:
        t_6 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_7 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_8 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_9 = environment.filters['list']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'list' found.")
    try:
        t_10 = environment.filters['selectattr']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'selectattr' found.")
    try:
        t_11 = environment.filters['should_inline']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'should_inline' found.")
    pass
    yield '// Copyright 2013 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module.h.tmpl')._get_default_module(context)
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_variant_path = getattr(included_template, 'variant_path', missing)
    if l_0_variant_path is missing:
        l_0_variant_path = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module.h.tmpl') does not export the requested name 'variant_path'", name='variant_path')
    context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'include_guard': l_0_include_guard, 'variant_path': l_0_variant_path})
    context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'include_guard', 'variant_path'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), '', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro(l_1_name):
        t_12 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
            pass
            t_12.extend((
                '\n// @generated_from: ',
                str(l_1_name),
            ))
        return concat(t_12)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include <stdint.h>\n\n#include <limits>\n#include <optional>\n#include <type_traits>\n#include <utility>\n\n#include "base/types/cxx23_to_underlying.h"'
    if (undefined(name='contains_only_enums') if l_0_contains_only_enums is missing else l_0_contains_only_enums):
        pass
        yield '\n#include "mojo/public/cpp/bindings/type_converter.h"'
    else:
        pass
        yield '\n#include "mojo/public/cpp/bindings/clone_traits.h"\n#include "mojo/public/cpp/bindings/equals_traits.h"\n#include "mojo/public/cpp/bindings/lib/serialization.h"\n#include "mojo/public/cpp/bindings/struct_ptr.h"\n#include "mojo/public/cpp/bindings/struct_traits.h"\n#include "mojo/public/cpp/bindings/union_traits.h"'
    yield '\n\n#include "third_party/perfetto/include/perfetto/tracing/traced_value_forward.h"\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-features.h"  // IWYU pragma: export\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '-shared.h"  // IWYU pragma: export\n#include "'
    yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    yield '-forward.h"  // IWYU pragma: export'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        if t_5(l_1_import):
            pass
            yield '\n#include "'
            yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant), _loop_vars=_loop_vars))
            yield '.h"'
        else:
            pass
            yield '\n#include "'
            yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr(l_1_import, 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant), _loop_vars=_loop_vars))
            yield '-forward.h"'
    l_1_import = missing
    if (not (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink)):
        pass
        yield '\n#include <string>\n#include <vector>'
    else:
        pass
        yield '\n\n#include "mojo/public/cpp/bindings/lib/wtf_clone_equals_util.h"\n#include "mojo/public/cpp/bindings/lib/wtf_hash_util.h"\n#include "third_party/blink/renderer/platform/wtf/hash_functions.h"\n#include "third_party/blink/renderer/platform/wtf/text/wtf_string.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_interfaces') if l_0_disallow_interfaces is missing else l_0_disallow_interfaces)) and (undefined(name='uses_interfaces') if l_0_uses_interfaces is missing else l_0_uses_interfaces)):
        pass
        yield '#include "mojo/public/cpp/bindings/lib/control_message_handler.h"\n#include "mojo/public/cpp/bindings/lib/message_size_estimator.h"\n#include "mojo/public/cpp/bindings/raw_ptr_impl_ref_traits.h"'
    yield '\n\n'
    if ((not (undefined(name='disallow_native_types') if l_0_disallow_native_types is missing else l_0_disallow_native_types)) and (undefined(name='uses_native_types') if l_0_uses_native_types is missing else l_0_uses_native_types)):
        pass
        yield '\n#include "mojo/public/cpp/bindings/lib/native_enum_serialization.h"\n#include "mojo/public/cpp/bindings/lib/native_struct_serialization.h"'
    for l_1_header in (undefined(name='extra_public_headers') if l_0_extra_public_headers is missing else l_0_extra_public_headers):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(l_1_header)
        yield '"'
    l_1_header = missing
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    if (undefined(name='for_blink') if l_0_for_blink is missing else l_0_for_blink):
        pass
        yield '\n#if !BLINK_MOJO_IMPL && !INSIDE_BLINK\n#error "File must only be imported inside blink"\n#endif'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    for l_1_forward_declaration in (undefined(name='typemap_forward_declarations') if l_0_typemap_forward_declarations is missing else l_0_typemap_forward_declarations):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(l_1_forward_declaration)
    l_1_forward_declaration = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        if t_4(environment.getattr(l_1_constant, 'kind')):
            pass
            yield '\n'
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr(l_1_constant, 'name')), _loop_vars=_loop_vars))
            yield '\n'
            yield str(t_2(l_1_constant))
            yield ';'
    l_1_constant = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    l_0_module_prefix = t_1('%s', t_7(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_proxy_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_stub_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_request_validator_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    def t_13(fiter):
        for l_1_interface in fiter:
            if t_3(l_1_interface):
                yield l_1_interface
    for l_1_interface in t_13((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('interface_response_validator_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_interface = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        yield '\n'
        if (t_11(l_1_struct) and (not t_6(l_1_struct))):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
            yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('wrapper_union_class_declaration.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        yield '\n'
        if ((not t_11(l_1_struct)) and (not t_6(l_1_struct))):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
            yield '\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('wrapper_union_class_template_definition.tmpl', 'module.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_union = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_6(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('wrapper_class_template_definition.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    yield '\n\nnamespace mojo {'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        if (not t_6(l_1_struct)):
            pass
            yield '\n'
            template = environment.get_template('struct_traits_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
    l_1_struct = missing
    if (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        pass
        for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
            _loop_vars = {}
            pass
            yield '\n'
            template = environment.get_template('union_traits_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
        l_1_union = missing
    if t_8(t_9(context.eval_ctx, t_10(context, (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), 'runtime_feature'))):
        pass
        yield '\nnamespace internal {'
        def t_14(fiter):
            for l_1_interface in fiter:
                if environment.getattr(l_1_interface, 'runtime_feature'):
                    yield l_1_interface
        for l_1_interface in t_14((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces)):
            _loop_vars = {}
            pass
            template = environment.get_template('interface_feature_declaration.tmpl', 'module.h.tmpl')
            for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'module_prefix': l_0_module_prefix, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
                yield event
        l_1_interface = missing
        yield '\n}  // namespace internal'
    yield '\n\n}  // namespace mojo\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=96&8=111&10=114&11=119&12=123&16=129&17=131&28=133&41=140&42=142&43=144&45=146&46=149&47=152&49=157&53=160&65=167&71=171&76=174&77=178&80=181&81=184&84=186&90=190&96=193&97=197&101=199&102=202&103=205&104=207&108=211&110=212&113=215&114=219&118=223&119=227&123=231&124=235&128=239&129=243&133=247&134=255&141=260&142=264&143=267&150=273&151=277&155=282&156=286&157=289&161=294&162=298&165=302&166=305&167=308&171=313&176=315&177=318&178=321&183=325&184=327&185=331&190=335&192=338&193=345&200=351'