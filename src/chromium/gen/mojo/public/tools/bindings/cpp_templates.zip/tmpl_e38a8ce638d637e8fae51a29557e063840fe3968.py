from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct_macros = l_0_declare_params = l_0_declare_callback = l_0_declare_request_params = l_0_trace_event = l_0_declare_sync_method_params = l_0_build_message_flags = l_0_build_serialized_message = l_0_define_message_type = missing
    try:
        t_1 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_4 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_5 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_6 = environment.filters['is_interface_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_interface_kind' found.")
    try:
        t_7 = environment.filters['is_receiver_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_receiver_kind' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    def macro(l_1_prefix, l_1_parameters, l_1_allow_non_const_ref):
        t_8 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_allow_non_const_ref is missing:
            l_1_allow_non_const_ref = False
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            _loop_vars = {}
            pass
            t_8.extend((
                str(t_2(environment.getattr(l_2_param, 'kind'), allow_non_const_ref=l_1_allow_non_const_ref)),
                ' ',
                str(l_1_prefix),
                str(environment.getattr(l_2_param, 'name')),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_8.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_8)
    context.exported_vars.add('declare_params')
    context.vars['declare_params'] = l_0_declare_params = Macro(environment, macro, 'declare_params', ('prefix', 'parameters', 'allow_non_const_ref'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method, l_1_for_blink):
        t_9 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_for_blink is missing:
            l_1_for_blink = undefined("parameter 'for_blink' was not provided", name='for_blink')
        pass
        t_9.append(
            'base::OnceCallback<void(',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
            _loop_vars = {}
            pass
            t_9.append(
                str(t_2(environment.getattr(l_2_param, 'kind'))),
            )
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_9.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        t_9.append(
            ')>',
        )
        return concat(t_9)
    context.exported_vars.add('declare_callback')
    context.vars['declare_callback'] = l_0_declare_callback = Macro(environment, macro, 'declare_callback', ('method', 'for_blink'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method, l_1_allow_non_const_ref):
        t_10 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_allow_non_const_ref is missing:
            l_1_allow_non_const_ref = False
        pass
        t_10.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'), allow_non_const_ref=l_1_allow_non_const_ref)),
        )
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_10.append(
                    ', ',
                )
            t_10.extend((
                str(environment.getattr(l_1_method, 'name')),
                'Callback callback',
            ))
        return concat(t_10)
    context.exported_vars.add('declare_request_params')
    context.vars['declare_request_params'] = l_0_declare_request_params = Macro(environment, macro, 'declare_request_params', ('prefix', 'method', 'allow_non_const_ref'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method_parameters, l_1_method_name, l_1_parameter_group, l_1_trace_event_type, l_1_dereference_parameters):
        t_11 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method_parameters is missing:
            l_1_method_parameters = undefined("parameter 'method_parameters' was not provided", name='method_parameters')
        if l_1_method_name is missing:
            l_1_method_name = undefined("parameter 'method_name' was not provided", name='method_name')
        if l_1_parameter_group is missing:
            l_1_parameter_group = undefined("parameter 'parameter_group' was not provided", name='parameter_group')
        if l_1_trace_event_type is missing:
            l_1_trace_event_type = ''
        if l_1_dereference_parameters is missing:
            l_1_dereference_parameters = False
        pass
        if l_1_method_parameters:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '1(\n    "mojom", "',
                str(l_1_method_name),
                '", "',
                str(l_1_parameter_group),
                '",\n    [&](perfetto::TracedValue context){\n      auto dict = std::move(context).WriteDictionary();',
            ))
            for l_2_param in l_1_method_parameters:
                _loop_vars = {}
                pass
                t_11.extend((
                    '\n      perfetto::WriteIntoTracedValueWithFallback(\n           dict.AddItem("',
                    str(environment.getattr(l_2_param, 'name')),
                    '"), ',
                    str((l_1_prefix + environment.getattr(l_2_param, 'name'))),
                    ',\n                        "<value of type ',
                    str(t_2(environment.getattr(l_2_param, 'kind'))),
                    '>");',
                ))
            l_2_param = missing
            t_11.append(
                '\n   });',
            )
        else:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '0("mojom", "',
                str(l_1_method_name),
                '");',
            ))
        return concat(t_11)
    context.exported_vars.add('trace_event')
    context.vars['trace_event'] = l_0_trace_event = Macro(environment, macro, 'trace_event', ('prefix', 'method_parameters', 'method_name', 'parameter_group', 'trace_event_type', 'dereference_parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_12 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_12.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if environment.getattr(l_1_method, 'response_parameters'):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_12.append(
                    ', ',
                )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
                _loop_vars = {}
                pass
                t_12.extend((
                    str(t_1(environment.getattr(l_2_param, 'kind'))),
                    '* out_',
                    str(l_1_prefix),
                    str(environment.getattr(l_2_param, 'name')),
                ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_12.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
        return concat(t_12)
    context.exported_vars.add('declare_sync_method_params')
    context.vars['declare_sync_method_params'] = l_0_declare_sync_method_params = Macro(environment, macro, 'declare_sync_method_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_is_response, l_1_is_sync_text, l_1_allow_interrupt_text, l_1_is_urgent_text, l_1_expects_response_text, l_1_flags_name):
        t_13 = []
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_is_sync_text is missing:
            l_1_is_sync_text = undefined("parameter 'is_sync_text' was not provided", name='is_sync_text')
        if l_1_allow_interrupt_text is missing:
            l_1_allow_interrupt_text = undefined("parameter 'allow_interrupt_text' was not provided", name='allow_interrupt_text')
        if l_1_is_urgent_text is missing:
            l_1_is_urgent_text = undefined("parameter 'is_urgent_text' was not provided", name='is_urgent_text')
        if l_1_expects_response_text is missing:
            l_1_expects_response_text = undefined("parameter 'expects_response_text' was not provided", name='expects_response_text')
        if l_1_flags_name is missing:
            l_1_flags_name = undefined("parameter 'flags_name' was not provided", name='flags_name')
        pass
        if l_1_is_response:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags = mojo::Message::kFlagIsResponse |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        else:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags =\n      ((',
                str(l_1_expects_response_text),
                ') ? mojo::Message::kFlagExpectsResponse : 0) |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        return concat(t_13)
    context.exported_vars.add('build_message_flags')
    context.vars['build_message_flags'] = l_0_build_message_flags = Macro(environment, macro, 'build_message_flags', ('is_response', 'is_sync_text', 'allow_interrupt_text', 'is_urgent_text', 'expects_response_text', 'flags_name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_message_name, l_1_method, l_1_param_name_prefix, l_1_params_struct, l_1_params_description, l_1_flags_text, l_1_message_object_name, l_1_has_size_estimator):
        t_14 = []
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_param_name_prefix is missing:
            l_1_param_name_prefix = undefined("parameter 'param_name_prefix' was not provided", name='param_name_prefix')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        if l_1_flags_text is missing:
            l_1_flags_text = undefined("parameter 'flags_text' was not provided", name='flags_text')
        if l_1_message_object_name is missing:
            l_1_message_object_name = undefined("parameter 'message_object_name' was not provided", name='message_object_name')
        if l_1_has_size_estimator is missing:
            l_1_has_size_estimator = False
        pass
        t_14.append(
            '\n  const size_t estimated_payload_size =',
        )
        if (l_1_has_size_estimator and environment.getattr(l_1_method, 'estimate_message_size')):
            pass
            t_14.extend((
                '\n    size_estimator_.EstimatePayloadSize(',
                str(l_1_message_name),
                ');',
            ))
        else:
            pass
            t_14.append(
                '\n    0;',
            )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ',\n      MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE,\n      estimated_payload_size);',
            ))
        else:
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ', estimated_payload_size);',
            ))
        t_14.extend((
            '\n  mojo::internal::MessageFragment<\n      ',
            str(t_5(l_1_params_struct, internal=True)),
            '> params(\n          ',
            str(l_1_message_object_name),
            ');\n  ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, l_1_param_name_prefix, 'params')),
        ))
        return concat(t_14)
    context.exported_vars.add('build_serialized_message')
    context.vars['build_serialized_message'] = l_0_build_serialized_message = Macro(environment, macro, 'build_serialized_message', ('message_name', 'method', 'param_name_prefix', 'params_struct', 'params_description', 'flags_text', 'message_object_name', 'has_size_estimator'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface, l_1_message_typename, l_1_message_name, l_1_is_response, l_1_method, l_1_parameters, l_1_params_struct, l_1_params_description):
        t_15 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        if l_1_message_typename is missing:
            l_1_message_typename = undefined("parameter 'message_typename' was not provided", name='message_typename')
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        pass
        t_15.extend((
            'class ',
            str(l_1_message_typename),
            '\n    : public mojo::internal::UnserializedMessageContext {\n public:\n  static const mojo::internal::UnserializedMessageContext::Tag kMessageTag;\n\n  explicit ',
            str(l_1_message_typename),
            '(\n      uint32_t message_flags',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n      , ',
                str(t_2(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                str(environment.getattr(l_2_param, 'name')),
            ))
        l_2_param = missing
        t_15.extend((
            '\n  )\n      : mojo::internal::UnserializedMessageContext(\n          &kMessageTag,\n          ',
            str(l_1_message_name),
            ',\n          message_flags)',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            if t_6(environment.getattr(l_2_param, 'kind')):
                pass
                t_15.extend((
                    '\n      , param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '_(param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '.PassInterface())',
                ))
            else:
                pass
                t_15.extend((
                    '\n      , param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '_(std::move(param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '))',
                ))
        l_2_param = missing
        t_15.extend((
            '{}\n\n  ',
            str(l_1_message_typename),
            '(const ',
            str(l_1_message_typename),
            '&) = delete;\n  ',
            str(l_1_message_typename),
            '& operator=(const ',
            str(l_1_message_typename),
            '&) = delete;\n\n  ~',
            str(l_1_message_typename),
            '() override = default;\n\n  static mojo::Message Build(\n      bool serialize,',
        ))
        if (not l_1_is_response):
            pass
            t_15.append(
                '\n      bool expects_response,',
            )
        t_15.append(
            '\n      bool is_sync,\n      bool allow_interrupt,\n      bool is_urgent',
        )
        if l_1_parameters:
            pass
            t_15.extend((
                ',\n      ',
                str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), 'param_', l_1_parameters)),
            ))
        t_15.extend((
            ') {\n\n    ',
            str(context.call((undefined(name='build_message_flags') if l_0_build_message_flags is missing else l_0_build_message_flags), l_1_is_response, 'is_sync', 'allow_interrupt', 'is_urgent', 'expects_response', 'kFlags')),
            '\n\n    if (!serialize) {\n      return mojo::Message(std::make_unique<',
            str(l_1_message_typename),
            '>(\n          kFlags',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n          , std::move(param_',
                str(environment.getattr(l_2_param, 'name')),
                ')',
            ))
        l_2_param = missing
        t_15.append(
            '\n          ),',
        )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE);',
            )
        else:
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_NONE);',
            )
        t_15.extend((
            '\n    }\n\n    DCHECK(serialize);\n    ',
            str(context.call((undefined(name='build_serialized_message') if l_0_build_serialized_message is missing else l_0_build_serialized_message), l_1_message_name, l_1_method, 'param_%s', l_1_params_struct, l_1_params_description, 'kFlags', 'message')),
            '\n    return message;\n  }\n\n',
        ))
        if (not l_1_is_response):
            pass
            t_15.extend((
                '\n  void Dispatch(\n      mojo::Message* message,\n      ',
                str(environment.getattr(l_1_interface, 'name')),
                '* impl',
            ))
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                t_15.extend((
                    ', ',
                    str(environment.getattr(l_1_interface, 'name')),
                    '::',
                    str(environment.getattr(l_1_method, 'name')),
                    'Callback callback',
                ))
            t_15.append(
                ') {\n    if (message->receiver_connection_group()) {',
            )
            for l_2_param in l_1_parameters:
                _loop_vars = {}
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.extend((
                '\n    }\n\n    impl->',
                str(environment.getattr(l_1_method, 'name')),
                '(',
            ))
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                _loop_vars = {}
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        str(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ',',
                    )
            l_2_loop = l_2_param = missing
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if l_1_parameters:
                    pass
                    t_15.append(
                        ', ',
                    )
                t_15.append(
                    'std::move(callback)',
                )
            t_15.append(
                ');\n  }',
            )
        else:
            pass
            t_15.extend((
                '\n  void Dispatch(mojo::Message* message,\n                ',
                str(environment.getattr(l_1_interface, 'name')),
                '::',
                str(environment.getattr(l_1_method, 'name')),
                'Callback* callback) {\n    if (message->receiver_connection_group()) {',
            ))
            for l_2_param in l_1_parameters:
                _loop_vars = {}
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.append(
                '\n    }\n\n    std::move(*callback).Run(',
            )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                _loop_vars = {}
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        str(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
            t_15.append(
                ');\n  }\n\n',
            )
            if environment.getattr(l_1_method, 'sync'):
                pass
                t_15.append(
                    '\n  void HandleSyncResponse(\n      mojo::Message* message\n',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    t_15.extend((
                        ',\n      ',
                        str(t_1(environment.getattr(l_2_param, 'kind'))),
                        '* out_',
                        str(environment.getattr(l_2_param, 'name')),
                    ))
                l_2_param = missing
                t_15.append(
                    ') {\n\n    if (message->receiver_connection_group()) {',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    if t_7(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n      param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_.set_connection_group(\n          *message->receiver_connection_group());',
                        ))
                l_2_param = missing
                t_15.append(
                    '\n    }\n\n',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    if t_6(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n    out_',
                            str(environment.getattr(l_2_param, 'name')),
                            '->Bind(std::move(param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_));',
                        ))
                    else:
                        pass
                        t_15.extend((
                            '\n    *out_',
                            str(environment.getattr(l_2_param, 'name')),
                            ' = std::move(param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_);',
                        ))
                    t_15.append(
                        '\n',
                    )
                l_2_param = missing
                t_15.append(
                    '\n  }',
                )
        t_15.extend((
            '\n\n private:\n  // mojo::internal::UnserializedMessageContext:\n  void Serialize(mojo::Message& message) override {\n    mojo::internal::MessageFragment<\n        ',
            str(t_5(l_1_params_struct, internal=True)),
            '> params(\n            message);\n    ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, 'param_%s_', 'params')),
            '\n  }',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n  ',
                str(t_3(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                str(environment.getattr(l_2_param, 'name')),
                '_;',
            ))
        l_2_param = missing
        t_15.extend((
            '\n};\n\nconst mojo::internal::UnserializedMessageContext::Tag\n',
            str(l_1_message_typename),
            '::kMessageTag = {};',
        ))
        return concat(t_15)
    context.exported_vars.add('define_message_type')
    context.vars['define_message_type'] = l_0_define_message_type = Macro(environment, macro, 'define_message_type', ('interface', 'message_typename', 'message_name', 'is_response', 'method', 'parameters', 'params_struct', 'params_description'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=54&3=56&4=66&5=70&6=75&10=84&12=95&13=99&14=101&19=113&20=123&21=125&22=127&23=133&27=139&41=154&42=158&43=160&46=165&48=170&49=174&53=185&57=193&58=201&59=203&60=205&61=211&62=215&63=220&68=229&70=244&72=248&73=250&74=252&77=259&78=261&79=263&80=265&84=271&89=293&90=297&95=305&96=309&97=311&101=320&102=322&105=329&106=331&107=333&111=338&114=359&119=361&121=364&122=369&127=376&129=379&130=382&131=386&133=395&137=403&138=407&140=411&144=414&150=422&152=426&155=430&159=432&161=435&162=440&165=447&173=459&178=462&181=466&182=469&183=473&186=481&187=484&188=488&194=494&195=498&196=501&197=505&199=514&201=517&203=523&204=525&209=540&211=545&212=548&213=552&220=560&221=563&222=567&224=576&226=579&230=588&233=593&234=598&238=606&239=609&240=613&246=620&247=623&248=627&250=636&261=650&263=652&267=655&268=660&273=668'