from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_data_view_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    try:
        t_1 = environment.filters['cpp_data_view_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_data_view_type' found.")
    try:
        t_2 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_3 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_kind = l_1_name = missing
        _loop_vars = {}
        pass
        l_1_kind = environment.getattr(l_1_field, 'kind')
        _loop_vars['kind'] = l_1_kind
        l_1_name = environment.getattr(l_1_field, 'name')
        _loop_vars['name'] = l_1_name
        if t_2((undefined(name='kind') if l_1_kind is missing else l_1_kind)):
            pass
            yield '\ninline void '
            yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
            yield 'DataView::Get'
            yield str(t_3((undefined(name='name') if l_1_name is missing else l_1_name)))
            yield 'DataView(\n    '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '* output) const {\n  CHECK(is_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '());\n  *output = '
            yield str(t_1((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
            yield '(data_->data.f_'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '.Get(), message_);\n}'
    l_1_field = l_1_kind = l_1_name = missing

blocks = {}
debug_info = '1=30&2=34&3=36&5=38&6=41&7=45&8=47&9=49'