from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'feature_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_feature = resolve('feature')
    try:
        t_1 = environment.filters['feature_name']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'feature_name' found.")
    try:
        t_2 = environment.filters['is_feature_on_by_default']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_feature_on_by_default' found.")
    pass
    yield 'BASE_FEATURE('
    yield str(environment.getattr((undefined(name='feature') if l_0_feature is missing else l_0_feature), 'name'))
    yield ',\n             '
    yield str(t_1((undefined(name='feature') if l_0_feature is missing else l_0_feature)))
    yield ','
    if t_2((undefined(name='feature') if l_0_feature is missing else l_0_feature)):
        pass
        yield '\n             base::FEATURE_ENABLED_BY_DEFAULT'
    else:
        pass
        yield '\n             base::FEATURE_DISABLED_BY_DEFAULT'
    yield '\n             );'

blocks = {}
debug_info = '1=25&2=27&3=29'