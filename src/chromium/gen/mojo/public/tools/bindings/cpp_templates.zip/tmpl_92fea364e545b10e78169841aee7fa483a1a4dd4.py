from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_unserialized_message_context.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    pass
    yield '// Used by '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '::WrapAsMessage to lazily serialize the struct.\ntemplate <typename UserType, typename DataView>\nstruct '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext\n    : public mojo::internal::UnserializedMessageContext {\n public:\n  static const mojo::internal::UnserializedMessageContext::Tag kMessageTag;\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext(\n    uint32_t message_name,\n    uint32_t message_flags,\n    UserType input)\n      : mojo::internal::UnserializedMessageContext(&kMessageTag, message_name, message_flags)\n      , user_data_(std::move(input)) {}\n  ~'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext() override = default;\n\n  UserType TakeData() {\n    return std::move(user_data_);\n  }\n\n private:\n  // mojo::internal::UnserializedMessageContext:\n  void Serialize(mojo::Message& message) override {\n    mojo::internal::MessageFragment<'
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_Data> fragment(message);\n    mojo::internal::Serialize<DataView>(user_data_, fragment);\n  }\n\n  UserType user_data_;\n};\n\ntemplate <typename UserType, typename DataView>\nconst mojo::internal::UnserializedMessageContext::Tag\n    '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '_UnserializedMessageContext<UserType, DataView>::kMessageTag = {};'

blocks = {}
debug_info = '1=13&3=15&8=17&14=19&23=21&32=23'