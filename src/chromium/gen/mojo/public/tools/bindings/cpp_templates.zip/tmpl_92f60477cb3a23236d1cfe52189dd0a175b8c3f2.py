from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_traits_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = l_0_mojom_type = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_traits_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    l_0_mojom_type = t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\n// static\nbool StructTraits<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView, '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr>::Read(\n    '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input,\n    '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) {\n  bool success = true;\n  '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr result('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::New());\n  '
    yield str(t_2(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'deserialize'), (undefined(name='struct') if l_0_struct is missing else l_0_struct), 'input', 'result->%s', 'success'), 4))
    yield '\n  *output = std::move(result);\n  return success;\n}'

blocks = {}
debug_info = '1=25&2=27&5=31&6=35&7=37&9=39&11=43'