from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_request_validator_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_export_attribute = resolve('export_attribute')
    l_0_interface = resolve('interface')
    pass
    yield 'class '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'RequestValidator : public mojo::MessageReceiver {\n public:\n  bool Accept(mojo::Message* message) override;\n};'

blocks = {}
debug_info = '1=14'