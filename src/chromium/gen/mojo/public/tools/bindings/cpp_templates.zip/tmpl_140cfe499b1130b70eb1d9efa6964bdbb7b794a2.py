from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_kythe_annotation = l_0_enum_forward = l_0_enum_decl = l_0_enum_stream = l_0_enum_to_string = l_0_enum_data_decl = l_0_enum_hash = l_0_enum_trace_format_traits_decl = l_0_enum_trace_format_traits = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['get_full_mojom_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_full_mojom_name_for_kind' found.")
    try:
        t_3 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_4 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_5 = environment.filters['groupby']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'groupby' found.")
    try:
        t_6 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_7 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_8 = environment.filters['map']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'map' found.")
    try:
        t_9 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_name):
        t_10 = []
        l_1_enable_kythe_annotations = resolve('enable_kythe_annotations')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_1_enable_kythe_annotations is missing else l_1_enable_kythe_annotations):
            pass
            t_10.extend((
                '\n// @generated_from: ',
                str(l_1_name),
            ))
        return concat(t_10)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_11 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_3(l_1_enum, flatten_nested_kind=True)
        t_11.extend((
            '\nenum class ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' : int32_t;',
        ))
        return concat(t_11)
    context.exported_vars.add('enum_forward')
    context.vars['enum_forward'] = l_0_enum_forward = Macro(environment, macro, 'enum_forward', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum, l_1_export_attribute):
        t_12 = []
        l_1_enum_name = l_1_full_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_export_attribute is missing:
            l_1_export_attribute = undefined("parameter 'export_attribute' was not provided", name='export_attribute')
        pass
        l_1_enum_name = t_3(l_1_enum, flatten_nested_kind=True)
        l_1_full_enum_name = t_2(l_1_enum)
        t_12.extend((
            '\n',
            str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='full_enum_name') if l_1_full_enum_name is missing else l_1_full_enum_name))),
            '\nenum class ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' : int32_t {',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_12.extend((
                '\n  ',
                str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='full_enum_name') if l_1_full_enum_name is missing else l_1_full_enum_name), environment.getattr(l_2_field, 'name')), _loop_vars=_loop_vars)),
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        if (not t_9(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_12.extend((
                '\n  kMinValue = ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ',',
            ))
        if (not t_9(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_12.extend((
                '\n  kMaxValue = ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ',',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_12.extend((
                '\n  kDefaultValue = ',
                str(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
            ))
        t_12.extend((
            '\n};\n\n',
            str(l_1_export_attribute),
            ' std::ostream& operator<<(std::ostream& os, ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value);\ninline bool IsKnownEnumValue(',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return ',
            str(t_3(l_1_enum, internal=True, flatten_nested_kind=True)),
            '::IsKnownValue(\n      static_cast<int32_t>(value));\n}',
        ))
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_12.extend((
                '\ninline ',
                str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                ' ToKnownEnumValue(',
                str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                ' value) {\n  if (IsKnownEnumValue(value)) {\n    return value;\n  }\n  return ',
                str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                '::kDefaultValue;\n}',
            ))
        return concat(t_12)
    context.exported_vars.add('enum_decl')
    context.vars['enum_decl'] = l_0_enum_decl = Macro(environment, macro, 'enum_decl', ('enum', 'export_attribute'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_13 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_3(l_1_enum, flatten_nested_kind=True)
        t_13.extend((
            '\nstd::ostream& operator<<(std::ostream& os, ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return os << ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(value);\n}',
        ))
        return concat(t_13)
    context.exported_vars.add('enum_stream')
    context.vars['enum_stream'] = l_0_enum_stream = Macro(environment, macro, 'enum_stream', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_14 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_3(l_1_enum, flatten_nested_kind=True)
        t_14.extend((
            '\nNOINLINE static const char* ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToStringHelper(',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  // Defined in a helper function to ensure that Clang generates a lookup table.',
        ))
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_14.append(
                '\n  switch(value) {',
            )
            for (l_2__, l_2_values) in t_5(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                _loop_vars = {}
                pass
                t_14.extend((
                    '\n    case ',
                    str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                    '::',
                    str(environment.getattr(environment.getitem(l_2_values, 0), 'name')),
                    ':\n      return "',
                ))
                if (t_7(l_2_values) > 1):
                    pass
                    t_14.append(
                        '{',
                    )
                t_14.append(
                    str(t_6(context.eval_ctx, t_8(context, l_2_values, attribute='name'), ', ')),
                )
                if (t_7(l_2_values) > 1):
                    pass
                    t_14.append(
                        '}',
                    )
                t_14.append(
                    '";',
                )
            l_2__ = l_2_values = missing
            t_14.append(
                '\n    default:\n      return nullptr;\n  }',
            )
        else:
            pass
            t_14.append(
                '\n  return nullptr;',
            )
        t_14.extend((
            '\n}\n\nstd::string ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  const char *str = ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToStringHelper(value);\n  if (!str) {\n    return base::StringPrintf("Unknown ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value: %i", static_cast<int32_t>(value));\n  }\n  return str;\n}',
        ))
        return concat(t_14)
    context.exported_vars.add('enum_to_string')
    context.vars['enum_to_string'] = l_0_enum_to_string = Macro(environment, macro, 'enum_to_string', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_15 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_3(l_1_enum, flatten_nested_kind=True)
        t_15.extend((
            '\nstruct ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '_Data {\n public:\n  static bool constexpr kIsExtensible = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_15.append(
                'true',
            )
        else:
            pass
            t_15.append(
                'false',
            )
        t_15.append(
            ';\n\n  static bool IsKnownValue(int32_t value) {',
        )
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_15.append(
                '\n    switch (value) {',
            )
            for l_2_enum_field in t_5(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                _loop_vars = {}
                pass
                t_15.extend((
                    '\n      case ',
                    str(environment.getitem(l_2_enum_field, 0)),
                    ':',
                ))
            l_2_enum_field = missing
            t_15.append(
                '\n        return true;\n    }',
            )
        t_15.append(
            '\n    return false;\n  }\n\n  static bool Validate(int32_t value,\n                       mojo::internal::ValidationContext* validation_context) {\n    if (kIsExtensible || IsKnownValue(value))\n      return true;\n\n    ReportValidationError(validation_context,\n                          mojo::internal::VALIDATION_ERROR_UNKNOWN_ENUM_VALUE);\n    return false;\n  }\n};',
        )
        return concat(t_15)
    context.exported_vars.add('enum_data_decl')
    context.vars['enum_data_decl'] = l_0_enum_data_decl = Macro(environment, macro, 'enum_data_decl', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_16 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_16.extend((
            '\ntemplate <>\nstruct hash<',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>\n    : public mojo::internal::EnumHashImpl<',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '> {};',
        ))
        return concat(t_16)
    context.exported_vars.add('enum_hash')
    context.vars['enum_hash'] = l_0_enum_hash = Macro(environment, macro, 'enum_hash', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum, l_1_export_attributes):
        t_17 = []
        l_1_export_attribute = resolve('export_attribute')
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_export_attributes is missing:
            l_1_export_attributes = undefined("parameter 'export_attributes' was not provided", name='export_attributes')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_17.extend((
            '\nnamespace perfetto {\n\ntemplate <>\nstruct ',
            str((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute)),
            ' TraceFormatTraits<',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '> {\n static void WriteIntoTrace(perfetto::TracedValue context, ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value);\n};\n\n} // namespace perfetto',
        ))
        return concat(t_17)
    context.exported_vars.add('enum_trace_format_traits_decl')
    context.vars['enum_trace_format_traits_decl'] = l_0_enum_trace_format_traits_decl = Macro(environment, macro, 'enum_trace_format_traits_decl', ('enum', 'export_attributes'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_18 = []
        l_1_enum_name = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        t_18.extend((
            '\nnamespace perfetto {\n\n// static\nvoid TraceFormatTraits<',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            '>::WriteIntoTrace(\n   perfetto::TracedValue context, ',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            ' value) {\n  return std::move(context).WriteString(',
            str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
            'ToString(value));\n}\n\n} // namespace perfetto',
        ))
        return concat(t_18)
    context.exported_vars.add('enum_trace_format_traits')
    context.vars['enum_trace_format_traits'] = l_0_enum_trace_format_traits = Macro(environment, macro, 'enum_trace_format_traits', ('enum',), False, False, False, context.eval_ctx.autoescape)
    yield 'endmacro '

blocks = {}
debug_info = '5=66&6=72&7=76&11=81&12=87&13=90&16=96&17=104&19=105&20=108&21=110&22=113&23=118&24=120&26=126&27=130&29=133&30=137&32=140&33=144&37=148&40=152&41=154&46=157&47=161&51=165&56=171&57=177&58=180&59=182&63=188&64=194&65=197&67=202&69=207&70=212&72=217&75=223&76=225&89=244&90=248&92=250&98=256&99=262&100=265&102=268&105=281&107=286&108=291&128=304&129=310&132=313&133=315&136=321&137=330&142=333&143=337&149=343&150=349&155=352&156=354&157=356'