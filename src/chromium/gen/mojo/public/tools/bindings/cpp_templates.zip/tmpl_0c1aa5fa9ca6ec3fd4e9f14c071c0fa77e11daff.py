from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_validation_macros = l_0_class_name = l_0_enum_name = missing
    try:
        t_1 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_2 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_validation_macros = context.vars['validation_macros'] = environment.get_template('validation_macros.tmpl', 'union_definition.tmpl')._get_default_module(context)
    context.exported_vars.discard('validation_macros')
    l_0_class_name = str_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    l_0_enum_name = str_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Tag', ))
    context.vars['enum_name'] = l_0_enum_name
    context.exported_vars.add('enum_name')
    yield '// static\nbool '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield "::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context,\n    bool inlined) {\n  if (!data) {\n    DCHECK(!inlined);\n    return true;\n  }\n\n  // If it is inlined, the alignment is already enforced by its enclosing\n  // object. We don't have to validate that.\n  DCHECK(!inlined || mojo::internal::IsAligned(data));\n\n  if (!inlined &&\n      !mojo::internal::ValidateNonInlinedUnionHeaderAndClaimMemory(\n          data, validation_context)) {\n    return false;\n  }\n\n  const "
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '* object = static_cast<const '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '*>(data);\n\n  if (inlined && object->is_null())\n    return true;\n\n  switch (object->tag) {\n'
    l_1_loop = missing
    for l_1_field, l_1_loop in LoopContext(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'), undefined):
        l_1_field_expr = missing
        _loop_vars = {}
        pass
        yield '\n    case '
        yield str((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
        yield '::k'
        yield str(t_2(environment.getattr(l_1_field, 'name')))
        yield ': {'
        l_1_field_expr = str_join(('object->data.f_', environment.getattr(l_1_field, 'name'), ))
        _loop_vars['field_expr'] = l_1_field_expr
        yield '\n'
        yield str(t_1(context.call(environment.getattr((undefined(name='validation_macros') if l_0_validation_macros is missing else l_0_validation_macros), 'validate_field'), l_1_field, environment.getattr(l_1_loop, 'index'), (undefined(name='field_expr') if l_1_field_expr is missing else l_1_field_expr), False, _loop_vars=_loop_vars), 4))
        yield '\n      return true;\n    }'
    l_1_loop = l_1_field = l_1_field_expr = missing
    yield '\n    default: {\n'
    if environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'extensible'):
        pass
        yield '\n      return true;'
    else:
        pass
        yield '\n      ReportValidationError(\n          validation_context,\n          mojo::internal::VALIDATION_ERROR_UNKNOWN_UNION_TAG,\n          "unknown tag in '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '");\n      return false;'
    yield '\n    }\n  }\n}'

blocks = {}
debug_info = '1=25&2=27&3=30&6=34&25=36&31=41&32=46&33=50&34=53&39=57&45=63'