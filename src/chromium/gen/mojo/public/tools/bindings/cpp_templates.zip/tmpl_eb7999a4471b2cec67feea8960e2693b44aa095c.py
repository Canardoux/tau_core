from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_export_attribute = resolve('export_attribute')
    l_0_kythe_annotation = l_0_class_name = l_0_enum_name = l_0_struct_macros = missing
    try:
        t_1 = environment.filters['cpp_union_field_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_union_field_type' found.")
    try:
        t_2 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_3 = environment.filters['get_full_mojom_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_full_mojom_name_for_kind' found.")
    try:
        t_4 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    def macro(l_1_name):
        t_5 = []
        l_1_enable_kythe_annotations = resolve('enable_kythe_annotations')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_1_enable_kythe_annotations is missing else l_1_enable_kythe_annotations):
            pass
            t_5.extend((
                '\n// @generated_from: ',
                str(l_1_name),
            ))
        return concat(t_5)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    l_0_class_name = str_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Data', ))
    context.vars['class_name'] = l_0_class_name
    context.exported_vars.add('class_name')
    l_0_enum_name = str_join((environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'), '_Tag', ))
    context.vars['enum_name'] = l_0_enum_name
    context.exported_vars.add('enum_name')
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'union_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    yield '\n\nclass '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ' {\n public:\n  // Used to identify Mojom Union Data Classes.\n  typedef void MojomUnionDataType;\n\n  '
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield "() = default;\n  // Do nothing in the destructor since it won't be called when it is a\n  // non-inlined union.\n  ~"
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield '() = default;\n\n  static bool Validate(const void* data,\n                       mojo::internal::ValidationContext* validation_context,\n                       bool inlined);\n\n  bool is_null() const { return size == 0; }\n\n  void set_null() {\n    size = 0U;\n    tag = static_cast<'
    yield str((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield '>(0);\n    data.unknown = 0U;\n  }\n\n  // TODO(crbug.com/40731316): SHOUTY_CASE values are being deprecated per C++ code style\n  // guidelines (https://google.github.io/styleguide/cppguide.html#Enumerator_Names),\n  // please use kCamelCase values instead.  Cleanup NULL_VALUE, BOOL_VALUE, INT_VALUE, etc.\n  // generation once codebase is transitioned to kNullValue, kBoolValue, kIntValue, etc.\n  enum class '
    yield str((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield ' : uint32_t {\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    '
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_2('%s.%s', t_3((undefined(name='union') if l_0_union is missing else l_0_union)), environment.getattr(l_1_field, 'name')), _loop_vars=_loop_vars))
        yield '\n    k'
        yield str(t_4(environment.getattr(l_1_field, 'name')))
        yield ','
    l_1_field = missing
    yield '\n  };\n\n  // A note on layout:\n  // "Each non-static data member is allocated as if it were the sole member of\n  // a struct." - Section 9.5.2 ISO/IEC 14882:2011 (The C++ Spec)\n  union MOJO_ALIGNAS(8) Union_ {\n    Union_() : unknown(0) {}'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        if (environment.getattr(environment.getattr(l_1_field, 'kind'), 'spec') == 'b'):
            pass
            yield '\n    uint8_t f_'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' : 1;'
        else:
            pass
            yield '\n    '
            yield str(t_1(environment.getattr(l_1_field, 'kind')))
            yield ' f_'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';'
    l_1_field = missing
    yield '\n    uint64_t unknown;\n  };\n\n  uint32_t size;\n  '
    yield str((undefined(name='enum_name') if l_0_enum_name is missing else l_0_enum_name))
    yield ' tag;\n  Union_ data;\n};\nstatic_assert(sizeof('
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ') == mojo::internal::kUnionDataSize,\n              "Bad sizeof('
    yield str((undefined(name='class_name') if l_0_class_name is missing else l_0_class_name))
    yield ')");'

blocks = {}
debug_info = '1=38&2=44&3=48&7=53&8=56&9=59&11=62&16=66&19=68&29=70&37=72&38=74&39=78&40=80&50=84&51=87&52=90&54=95&61=101&64=103&65=105'