from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_proxy_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module_prefix = resolve('module_prefix')
    l_0_interface = resolve('interface')
    l_0_kythe_annotation = resolve('kythe_annotation')
    l_0_export_attribute = resolve('export_attribute')
    l_0_interface_macros = l_0_interface_prefix = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['has_estimate_size_methods']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'has_estimate_size_methods' found.")
    pass
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'interface_proxy_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    l_0_interface_prefix = t_1('%s.%s', (undefined(name='module_prefix') if l_0_module_prefix is missing else l_0_module_prefix), environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    context.vars['interface_prefix'] = l_0_interface_prefix
    context.exported_vars.add('interface_prefix')
    yield '\n\n'
    yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix)))
    yield '\nclass '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy\n    : public '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n public:\n  using InterfaceType = '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ';\n\n  explicit '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy(mojo::MessageReceiverWithResponder* receiver);'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        if environment.getattr(l_1_method, 'sync'):
            pass
            yield '\n  '
            yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name')), _loop_vars=_loop_vars))
            yield '\n  bool '
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_1_method, _loop_vars=_loop_vars))
            yield ') final;'
        yield '\n  '
        yield str(context.call((undefined(name='kythe_annotation') if l_0_kythe_annotation is missing else l_0_kythe_annotation), t_1('%s.%s', (undefined(name='interface_prefix') if l_0_interface_prefix is missing else l_0_interface_prefix), environment.getattr(l_1_method, 'name')), _loop_vars=_loop_vars))
        yield '\n  void '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_1_method, _loop_vars=_loop_vars))
        yield ') final;'
    l_1_method = missing
    yield '\n\n private:\n  mojo::MessageReceiverWithResponder* receiver_;'
    if t_2((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  mojo::internal::MessageSizeEstimator size_estimator_;'
    yield '\n};'

blocks = {}
debug_info = '1=28&3=30&5=34&6=36&7=40&9=42&11=44&13=46&14=49&15=52&16=54&18=59&19=61&25=67'