from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-test-utils.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_variant = resolve('variant')
    l_0_export_header = resolve('export_header')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_interfaces = resolve('interfaces')
    l_0_namespace_begin = l_0_namespace_end = l_0_include_guard = l_0_variant_path = l_0_header_guard = l_0_interface_macros = missing
    try:
        t_1 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_2 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-test-utils.h.tmpl')._get_default_module(context)
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-test-utils.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-test-utils.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-test-utils.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_variant_path = getattr(included_template, 'variant_path', missing)
    if l_0_variant_path is missing:
        l_0_variant_path = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-test-utils.h.tmpl') does not export the requested name 'variant_path'", name='variant_path')
    context.vars.update({'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'include_guard': l_0_include_guard, 'variant_path': l_0_variant_path})
    context.exported_vars.difference_update(('namespace_begin', 'namespace_end', 'include_guard', 'variant_path'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'TEST_UTILS', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "'
    yield str(context.call((undefined(name='variant_path') if l_0_variant_path is missing else l_0_variant_path), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    yield '.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    l_0_interface_macros = context.vars['interface_macros'] = environment.get_template('interface_macros.tmpl', 'module-test-utils.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('interface_macros')
    yield '\n\n'
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_export_attribute = resolve('export_attribute')
        _loop_vars = {}
        pass
        yield '\nclass '
        yield str((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute))
        yield ' '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'InterceptorForTesting : public '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ' {\n  virtual '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield '* GetForwardingInterface() = 0;'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            yield '\n  void '
            yield str(environment.getattr(l_2_method, 'name'))
            yield '('
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_request_params'), '', l_2_method, _loop_vars=_loop_vars))
            yield ') override;'
        l_2_method = missing
        yield '\n};\nclass '
        yield str((undefined(name='export_attribute') if l_1_export_attribute is missing else l_1_export_attribute))
        yield ' '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter {\n public:\n  explicit '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter('
        yield str(environment.getattr(l_1_interface, 'name'))
        yield '* proxy);\n\n  '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter(const '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter&) = delete;\n  '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter& operator=(const '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter&) = delete;\n\n  ~'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AsyncWaiter();'
        def t_3(fiter):
            for l_2_method in fiter:
                if (environment.getattr(l_2_method, 'response_parameters') != None):
                    yield l_2_method
        for l_2_method in t_3(environment.getattr(l_1_interface, 'methods')):
            l_2_response_type = resolve('response_type')
            _loop_vars = {}
            pass
            yield '\n  void '
            yield str(environment.getattr(l_2_method, 'name'))
            yield '(\n      '
            yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_sync_method_params'), '', l_2_method, _loop_vars=_loop_vars))
            yield ');\n  '
            if (t_2(environment.getattr(l_2_method, 'response_parameters')) == 1):
                pass
                l_2_response_type = t_1(environment.getattr(environment.getitem(environment.getattr(l_2_method, 'response_parameters'), 0), 'kind'))
                _loop_vars['response_type'] = l_2_response_type
                yield str((undefined(name='response_type') if l_2_response_type is missing else l_2_response_type))
                yield ' '
                yield str(environment.getattr(l_2_method, 'name'))
                yield '('
                yield str(context.call(environment.getattr((undefined(name='interface_macros') if l_0_interface_macros is missing else l_0_interface_macros), 'declare_params'), '', environment.getattr(l_2_method, 'parameters'), _loop_vars=_loop_vars))
                yield ');'
        l_2_method = l_2_response_type = missing
        yield '\n\n private:\n  '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield '* const proxy_;\n};\n\n'
    l_1_interface = l_1_export_attribute = missing
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), (undefined(name='variant') if l_0_variant is missing else l_0_variant)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=30&8=45&10=49&11=51&13=53&15=55&16=58&19=61&21=62&23=65&26=70&27=76&29=78&30=82&35=88&37=92&39=96&40=100&42=104&44=106&45=115&46=117&47=119&48=121&49=123&55=131&60=135&62=137'