from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'wrapper_union_class_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_default_field = missing
    try:
        t_1 = environment.filters['cpp_wrapper_param_type_new']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type_new' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_3 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_4 = environment.filters['is_hashable']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_hashable' found.")
    try:
        t_5 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_6 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_default_field = environment.getitem(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'), 0)
    context.vars['default_field'] = l_0_default_field
    context.exported_vars.add('default_field')
    yield '\n'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '() : tag_(Tag::k'
    yield str(t_6(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name')))
    yield ') {'
    if (t_5(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')) or t_3(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind'))):
        pass
        yield '\n  data_.'
        yield str(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name'))
        yield ' = new '
        yield str(t_2(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')))
        yield ';'
    else:
        pass
        yield '\n  data_.'
        yield str(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'name'))
        yield ' = '
        yield str(t_2(environment.getattr((undefined(name='default_field') if l_0_default_field is missing else l_0_default_field), 'kind')))
        yield '();'
    yield '\n}\n\n'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::~'
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '() {\n  DestroyActive();\n}\n\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\nvoid '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::set_'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '(\n    '
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ') {'
        if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n  if (tag_ == Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    *(data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ') = std::move('
            yield str(environment.getattr(l_1_field, 'name'))
            yield ');\n  } else {\n    DestroyActive();\n    tag_ = Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n    data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = new '
            yield str(t_2(environment.getattr(l_1_field, 'kind')))
            yield '(\n        std::move('
            yield str(environment.getattr(l_1_field, 'name'))
            yield '));\n  }'
        else:
            pass
            yield '\n  if (tag_ != Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ') {\n    DestroyActive();\n    tag_ = Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ';\n  }\n  data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n}'
    l_1_field = missing
    yield '\n\nvoid '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::DestroyActive() {\n  switch (tag_) {\n'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n    case Tag::k'
        yield str(t_6(environment.getattr(l_1_field, 'name')))
        yield ':\n'
        if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
            pass
            yield '\n      delete data_.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ';'
        yield '\n      break;'
    l_1_field = missing
    yield '\n  }\n}'
    if t_4((undefined(name='union') if l_0_union is missing else l_0_union)):
        pass
        yield '\nsize_t '
        yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
        yield '::Hash(size_t seed) const {\n  seed = mojo::internal::HashCombine(seed, static_cast<uint32_t>(tag_));\n  switch (tag_) {\n'
        for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
            l_1_for_blink = resolve('for_blink')
            _loop_vars = {}
            pass
            yield '\n    case Tag::k'
            yield str(t_6(environment.getattr(l_1_field, 'name')))
            yield ':'
            if (undefined(name='for_blink') if l_1_for_blink is missing else l_1_for_blink):
                pass
                if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
                    pass
                    yield '\n      return mojo::internal::WTFHash(seed, *data_.'
                    yield str(environment.getattr(l_1_field, 'name'))
                    yield ');'
                else:
                    pass
                    yield '\n      return mojo::internal::WTFHash(seed, data_.'
                    yield str(environment.getattr(l_1_field, 'name'))
                    yield ');'
            else:
                pass
                if (t_5(environment.getattr(l_1_field, 'kind')) or t_3(environment.getattr(l_1_field, 'kind'))):
                    pass
                    yield '\n      return mojo::internal::Hash(seed, *data_.'
                    yield str(environment.getattr(l_1_field, 'name'))
                    yield ');'
                else:
                    pass
                    yield '\n      return mojo::internal::Hash(seed, data_.'
                    yield str(environment.getattr(l_1_field, 'name'))
                    yield ');'
        l_1_field = l_1_for_blink = missing
        yield '\n    default:\n      NOTREACHED();\n  }\n}'
    yield '\n\nbool '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield '::Validate(\n    const void* data,\n    mojo::internal::ValidationContext* validation_context) {\n  return Data_::Validate(data, validation_context, false);\n}'

blocks = {}
debug_info = '1=49&2=53&3=59&5=62&7=69&11=74&15=78&16=82&17=86&18=90&20=93&21=95&24=99&25=101&26=105&29=110&31=112&33=114&38=121&40=123&41=127&42=129&44=132&51=137&52=140&55=142&56=147&57=149&58=151&60=154&62=159&65=163&67=166&69=171&79=176'