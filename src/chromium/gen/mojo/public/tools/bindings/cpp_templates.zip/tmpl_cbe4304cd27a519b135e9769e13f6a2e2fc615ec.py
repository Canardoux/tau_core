from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_feature_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_iface_name = l_0_feature_name = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_feature']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_feature' found.")
    try:
        t_2 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    pass
    l_0_iface_name = t_2((undefined(name='interface') if l_0_interface is missing else l_0_interface))
    context.vars['iface_name'] = l_0_iface_name
    context.exported_vars.add('iface_name')
    l_0_feature_name = t_1(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'runtime_feature'))
    context.vars['feature_name'] = l_0_feature_name
    context.exported_vars.add('feature_name')
    yield '\ntemplate <>\ninline bool GetRuntimeFeature_IsEnabled<'
    yield str((undefined(name='iface_name') if l_0_iface_name is missing else l_0_iface_name))
    yield '>() {\n  return '
    yield str((undefined(name='iface_name') if l_0_iface_name is missing else l_0_iface_name))
    yield '::RuntimeFeature_IsEnabled_(false);\n}\ntemplate <>\ninline bool GetRuntimeFeature_ExpectEnabled<'
    yield str((undefined(name='iface_name') if l_0_iface_name is missing else l_0_iface_name))
    yield '>() {\n  return '
    yield str((undefined(name='iface_name') if l_0_iface_name is missing else l_0_iface_name))
    yield '::RuntimeFeature_IsEnabled_(true);\n}template <>\ninline constexpr bool kIsRuntimeFeatureGuarded<'
    yield str((undefined(name='iface_name') if l_0_iface_name is missing else l_0_iface_name))
    yield '> = true;'

blocks = {}
debug_info = '3=25&4=28&6=32&7=34&10=36&11=38&15=40'