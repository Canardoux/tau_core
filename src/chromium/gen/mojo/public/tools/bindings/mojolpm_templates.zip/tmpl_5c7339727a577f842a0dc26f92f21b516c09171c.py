from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_not_null = l_0_value = l_0_add_instance = missing
    try:
        t_1 = environment.filters['cpp_wrapper_proto_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_proto_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_3 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_4 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_5 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_6 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_7 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_8 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_9 = environment.filters['is_move_only_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_move_only_kind' found.")
    try:
        t_10 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_11 = environment.filters['is_pending_associated_remote_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_associated_remote_kind' found.")
    try:
        t_12 = environment.filters['is_pending_remote_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_remote_kind' found.")
    try:
        t_13 = environment.filters['is_platform_handle_kind']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_platform_handle_kind' found.")
    try:
        t_14 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_15 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_16 = environment.filters['nullable_is_same_kind']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'nullable_is_same_kind' found.")
    try:
        t_17 = environment.filters['to_unnullable_kind']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'to_unnullable_kind' found.")
    try:
        t_18 = environment.filters['truncate']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'truncate' found.")
    pass
    def macro(l_1_kind, l_1_name):
        t_19 = []
        l_1_data_view = resolve('data_view')
        l_1_data_type = resolve('data_type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if ((t_15(l_1_kind) and t_14(l_1_kind)) and t_16(l_1_kind)):
            pass
            l_1_data_view = str_join((t_3(l_1_kind), 'DataView', ))
            l_1_data_type = t_2(t_17(l_1_kind))
            if (t_18(environment, (undefined(name='data_type') if l_1_data_type is missing else l_1_data_type), 16, True, '', 0) == '::scoped_refptr<'):
                pass
                t_19.extend((
                    '\n',
                    str(l_1_name),
                ))
            else:
                pass
                t_19.extend((
                    '\n!::mojo::internal::CallIsNullIfExists<::mojo::StructTraits<',
                    str((undefined(name='data_view') if l_1_data_view is missing else l_1_data_view)),
                    ', ',
                    str((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                    '>>(',
                    str(l_1_name),
                    ')',
                ))
        elif t_13(l_1_kind):
            pass
            t_19.extend((
                str(l_1_name),
                '.is_valid()',
            ))
        else:
            pass
            t_19.append(
                str(l_1_name),
            )
        return concat(t_19)
    context.exported_vars.add('not_null')
    context.vars['not_null'] = l_0_not_null = Macro(environment, macro, 'not_null', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_20 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_10(l_1_kind) and (not t_16(l_1_kind))):
            pass
            t_20.extend((
                '*',
                str(l_1_name),
            ))
        else:
            pass
            t_20.append(
                str(l_1_name),
            )
        return concat(t_20)
    context.exported_vars.add('value')
    context.vars['value'] = l_0_value = Macro(environment, macro, 'value', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name, l_1_nested):
        t_21 = []
        l_1_mojom_type = resolve('mojom_type')
        l_1_proto_type = resolve('proto_type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_nested is missing:
            l_1_nested = undefined("parameter 'nested' was not provided", name='nested')
        pass
        if (t_10(l_1_kind) and (not t_16(l_1_kind))):
            pass
            t_21.extend((
                'if (',
                str(l_1_name),
                '.has_value()) {',
            ))
        if t_6(l_1_kind):
            pass
            if (not t_7(environment.getattr(l_1_kind, 'kind'))):
                pass
                t_21.extend((
                    '\n  for (auto& ',
                    str(l_1_name),
                    '_iter : ',
                    str(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                    ') {\n',
                    str(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'kind'), str_join((l_1_name, '_iter', )), True), 2, True)),
                    '\n  }',
                ))
        elif t_8(l_1_kind):
            pass
            t_21.extend((
                '\n  for (auto& ',
                str(l_1_name),
                '_iter : ',
                str(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                ') {\n    auto& ',
                str(l_1_name),
                '_key = ',
                str(l_1_name),
                '_iter.first;\n    auto& ',
                str(l_1_name),
                '_value = ',
                str(l_1_name),
                '_iter.second;\n',
                str(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'key_kind'), str_join((l_1_name, '_key', )), True), 2, True)),
                '\n',
                str(t_4(context.call((undefined(name='add_instance') if l_0_add_instance is missing else l_0_add_instance), environment.getattr(l_1_kind, 'value_kind'), str_join((l_1_name, '_value', )), True), 2, True)),
                '\n  }',
            ))
        elif t_12(l_1_kind):
            pass
            l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), flatten_nested_kind=True)
            t_21.extend((
                '\n  if (',
                str(l_1_name),
                ') {\n    ::mojo::Remote<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '> tmp_',
                str(l_1_name),
                '(std::move(',
                str(l_1_name),
                '));\n    mojolpm::GetContext()->AddInstance(std::move(tmp_',
                str(l_1_name),
                '));\n  }',
            ))
        elif t_11(l_1_kind):
            pass
            l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), flatten_nested_kind=True)
            t_21.extend((
                '\n  if (',
                str(l_1_name),
                ') {\n    ::mojo::AssociatedRemote<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '> tmp_',
                str(l_1_name),
                '(std::move(',
                str(l_1_name),
                '));\n    mojolpm::GetContext()->AddInstance(std::move(tmp_',
                str(l_1_name),
                '));\n  }',
            ))
        elif t_5(l_1_kind):
            pass
            t_21.extend((
                '\n  mojolpm::GetContext()->AddInstance(std::move(',
                str(l_1_name),
                '));',
            ))
        else:
            pass
            if t_10(l_1_kind):
                pass
                l_1_proto_type = t_1(l_1_kind, add_same_module_namespaces=True)
                t_21.extend((
                    '\n  ',
                    str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                    ' tmp_',
                    str(l_1_name),
                    ';\n  if (',
                    str(context.call((undefined(name='not_null') if l_0_not_null is missing else l_0_not_null), l_1_kind, l_1_name)),
                    ') {',
                ))
                if t_9(l_1_kind):
                    pass
                    t_21.extend((
                        '\n    if (ToProto(std::move(',
                        str(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                        '), tmp_',
                        str(l_1_name),
                        ')) {',
                    ))
                else:
                    pass
                    t_21.extend((
                        '\n    if (ToProto(',
                        str(context.call((undefined(name='value') if l_0_value is missing else l_0_value), l_1_kind, l_1_name)),
                        ', tmp_',
                        str(l_1_name),
                        ')) {',
                    ))
                t_21.extend((
                    '\n      mojolpm::GetContext()->AddInstance(tmp_',
                    str(l_1_name),
                    ');\n    }\n  }',
                ))
            else:
                pass
                l_1_proto_type = t_1(l_1_kind, add_same_module_namespaces=True)
                t_21.extend((
                    '\n  ',
                    str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                    ' tmp_',
                    str(l_1_name),
                    ';',
                ))
                if t_9(l_1_kind):
                    pass
                    t_21.extend((
                        '\n  if (ToProto(std::move(',
                        str(l_1_name),
                        '), tmp_',
                        str(l_1_name),
                        ')) {',
                    ))
                else:
                    pass
                    t_21.extend((
                        '\n  if (ToProto(',
                        str(l_1_name),
                        ', tmp_',
                        str(l_1_name),
                        ')) {',
                    ))
                t_21.extend((
                    '\n    mojolpm::GetContext()->AddInstance(tmp_',
                    str(l_1_name),
                    ');\n  }',
                ))
        if (t_10(l_1_kind) and (not t_16(l_1_kind))):
            pass
            t_21.append(
                '}',
            )
        return concat(t_21)
    context.exported_vars.add('add_instance')
    context.vars['add_instance'] = l_0_add_instance = Macro(environment, macro, 'add_instance', ('kind', 'name', 'nested'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=120&2=129&3=131&4=132&5=133&6=137&8=143&10=150&11=159&15=164&16=171&17=180&21=185&22=196&23=200&25=203&26=205&27=209&28=213&31=216&32=220&33=224&34=228&35=232&36=234&38=237&39=239&40=242&41=244&42=250&44=253&45=255&46=258&47=260&48=266&50=269&51=273&53=278&54=280&55=283&56=287&57=290&58=294&60=303&62=310&66=315&67=318&68=323&69=327&71=336&73=343&77=346'