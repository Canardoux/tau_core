from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_extra_public_headers = resolve('extra_public_headers')
    l_0_imports = resolve('imports')
    l_0_all_enums = resolve('all_enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_header_guard = l_0_namespace_begin = l_0_namespace_end = l_0_util = l_0_from_proto = l_0_to_proto = missing
    try:
        t_1 = environment.filters['contains_handles_or_interfaces']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'contains_handles_or_interfaces' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_4 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_5 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_6 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_7 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_8 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_9 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_10 = environment.filters['replace']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'replace' found.")
    try:
        t_11 = environment.filters['reverse']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'reverse' found.")
    try:
        t_12 = environment.filters['upper']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'upper' found.")
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_0_header_guard = t_5('%s_MOJOLPM_H_', t_10(context.eval_ctx, t_10(context.eval_ctx, t_10(context.eval_ctx, t_12(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path')), '/', '_'), '.', '_'), '-', '_'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro():
        t_13 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        t_13.append(
            '\nnamespace mojolpm {',
        )
        for l_2_namespace in (undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array):
            _loop_vars = {}
            pass
            t_13.extend((
                '\nnamespace ',
                str(l_2_namespace),
                ' {',
            ))
        l_2_namespace = missing
        return concat(t_13)
    context.exported_vars.add('namespace_begin')
    context.vars['namespace_begin'] = l_0_namespace_begin = Macro(environment, macro, 'namespace_begin', (), False, False, False, context.eval_ctx.autoescape)
    def macro():
        t_14 = []
        l_1_namespaces_as_array = resolve('namespaces_as_array')
        pass
        for l_2_namespace in t_11((undefined(name='namespaces_as_array') if l_1_namespaces_as_array is missing else l_1_namespaces_as_array)):
            _loop_vars = {}
            pass
            t_14.extend((
                '\n}  // namespace ',
                str(l_2_namespace),
            ))
        l_2_namespace = missing
        t_14.append(
            '\n}  // namespace mojolpm',
        )
        return concat(t_14)
    context.exported_vars.add('namespace_end')
    context.vars['namespace_end'] = l_0_namespace_end = Macro(environment, macro, 'namespace_end', (), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "mojo/public/cpp/bindings/associated_receiver.h"\n#include "mojo/public/cpp/bindings/associated_remote.h"\n#include "mojo/public/cpp/bindings/receiver.h"\n#include "mojo/public/cpp/bindings/remote.h"\n#include "mojo/public/tools/fuzzers/mojolpm.h"\n\n'
    for l_1_extra_public_header in (undefined(name='extra_public_headers') if l_0_extra_public_headers is missing else l_0_extra_public_headers):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(l_1_extra_public_header)
        yield '"'
    l_1_extra_public_header = missing
    yield '\n\n'
    for l_1_import in (undefined(name='imports') if l_0_imports is missing else l_0_imports):
        _loop_vars = {}
        pass
        yield '\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '-mojolpm.h"\n#include "'
        yield str(environment.getattr(l_1_import, 'path'))
        yield '.h"'
    l_1_import = missing
    yield '\n\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '.mojolpm.pb.h"\n#include "'
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    yield '.h"'
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('util')
    l_0_from_proto = context.vars['from_proto'] = environment.get_template('mojolpm_from_proto_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('from_proto')
    l_0_to_proto = context.vars['to_proto'] = environment.get_template('mojolpm_to_proto_macros.tmpl', 'mojolpm.h.tmpl')._get_default_module(context)
    context.exported_vars.discard('to_proto')
    yield '\n\nnamespace mojolpm {'
    for l_1_enum in (undefined(name='all_enums') if l_0_all_enums is missing else l_0_all_enums):
        l_1_mojom_type = l_1_proto_type = missing
        _loop_vars = {}
        pass
        l_1_mojom_type = t_4(l_1_enum, add_same_module_namespaces=True)
        _loop_vars['mojom_type'] = l_1_mojom_type
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_enum, flatten_nested_kind=True), ))
        _loop_vars['proto_type'] = l_1_proto_type
        yield '\n// enum '
        yield str(environment.getattr(l_1_enum, 'name'))
        yield '\nbool FromProto(\n  const '
        yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& input,\n  '
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '& output);\n\nbool ToProto(\n  const '
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '& input,\n  '
        yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& output);\n'
    l_1_enum = l_1_mojom_type = l_1_proto_type = missing
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_struct_type = missing
        _loop_vars = {}
        pass
        l_1_mojom_in_type = t_3(l_1_struct, add_same_module_namespaces=True)
        _loop_vars['mojom_in_type'] = l_1_mojom_in_type
        l_1_mojom_out_type = t_2(l_1_struct, add_same_module_namespaces=True)
        _loop_vars['mojom_out_type'] = l_1_mojom_out_type
        l_1_maybe_const = ('const ' if (not t_1(l_1_struct)) else '')
        _loop_vars['maybe_const'] = l_1_maybe_const
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_struct, flatten_nested_kind=True), ))
        _loop_vars['proto_type'] = l_1_proto_type
        l_1_struct_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        _loop_vars['struct_type'] = l_1_struct_type
        yield '\n// struct '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield '\nbool FromProto(\n  const '
        yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& input,\n  '
        yield str((undefined(name='mojom_out_type') if l_1_mojom_out_type is missing else l_1_mojom_out_type))
        yield '& output);\n\nbool ToProto(\n  '
        yield str((undefined(name='mojom_in_type') if l_1_mojom_in_type is missing else l_1_mojom_in_type))
        yield ' input,\n  '
        yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
        yield '& output);\n'
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            l_2_name = l_2_kind = missing
            _loop_vars = {}
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            _loop_vars['name'] = l_2_name
            l_2_kind = environment.getattr(l_2_field, 'kind')
            _loop_vars['kind'] = l_2_kind
            if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield str(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
                yield str(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
        l_2_field = l_2_name = l_2_kind = missing
    l_1_struct = l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_struct_type = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_union_type = missing
        _loop_vars = {}
        pass
        l_1_mojom_in_type = t_3(l_1_union, add_same_module_namespaces=True)
        _loop_vars['mojom_in_type'] = l_1_mojom_in_type
        l_1_mojom_out_type = t_2(l_1_union, add_same_module_namespaces=True)
        _loop_vars['mojom_out_type'] = l_1_mojom_out_type
        l_1_maybe_const = ('const ' if (not t_1(l_1_union)) else '')
        _loop_vars['maybe_const'] = l_1_maybe_const
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_union, flatten_nested_kind=True), ))
        _loop_vars['proto_type'] = l_1_proto_type
        l_1_union_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        _loop_vars['union_type'] = l_1_union_type
        if t_9(l_1_union):
            pass
            yield '\n#error "Mojo native-only union '
            yield str(environment.getattr(l_1_union, 'name'))
            yield ' - don\'t think this is possible"'
        else:
            pass
            yield '\n// union '
            yield str(environment.getattr(l_1_union, 'name'))
            yield '\nbool FromProto(\n  const '
            yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '& input,\n  '
            yield str((undefined(name='mojom_out_type') if l_1_mojom_out_type is missing else l_1_mojom_out_type))
            yield '& output);\n\nbool ToProto(\n  '
            yield str((undefined(name='mojom_in_type') if l_1_mojom_in_type is missing else l_1_mojom_in_type))
            yield ' input,\n  '
            yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '& output);\n'
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_name = l_2_kind = missing
            _loop_vars = {}
            pass
            l_2_name = environment.getattr(l_2_field, 'name')
            _loop_vars['name'] = l_2_name
            l_2_kind = environment.getattr(l_2_field, 'kind')
            _loop_vars['kind'] = l_2_kind
            if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                pass
                yield str(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
                yield str(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='union_type') if l_1_union_type is missing else l_1_union_type), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
        l_2_field = l_2_name = l_2_kind = missing
    l_1_union = l_1_mojom_in_type = l_1_mojom_out_type = l_1_maybe_const = l_1_proto_type = l_1_union_type = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_mojom_type = l_1_proto_type = missing
        _loop_vars = {}
        pass
        l_1_mojom_type = t_6(l_1_interface, flatten_nested_kind=True)
        _loop_vars['mojom_type'] = l_1_mojom_type
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_interface, flatten_nested_kind=True), ))
        _loop_vars['proto_type'] = l_1_proto_type
        yield '\n// interface '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield '\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingRemote<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingRemote<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingReceiver<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingReceiver<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingAssociatedRemote<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingAssociatedRemote<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n\nbool FromProto(\n  uint32_t input,\n  ::mojo::PendingAssociatedReceiver<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>& output);\n\nbool ToProto(\n  ::mojo::PendingAssociatedReceiver<'
        yield str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type))
        yield '>&& input,\n  uint32_t& output);\n'
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = missing
            _loop_vars = {}
            pass
            l_2_method_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), ))
            _loop_vars['method_type'] = l_2_method_type
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                _loop_vars = {}
                pass
                l_3_name = environment.getattr(l_3_param, 'name')
                _loop_vars['name'] = l_3_name
                l_3_kind = environment.getattr(l_3_param, 'kind')
                _loop_vars['kind'] = l_3_kind
                if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                    pass
                    yield str(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars))
                    yield str(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars))
            l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_method_type = resolve('method_type')
            _loop_vars = {}
            pass
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                l_2_method_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '::', environment.getattr(l_1_interface, 'name'), '_', environment.getattr(l_2_method, 'name'), 'Response', ))
                _loop_vars['method_type'] = l_2_method_type
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    _loop_vars = {}
                    pass
                    l_3_name = environment.getattr(l_3_param, 'name')
                    _loop_vars['name'] = l_3_name
                    l_3_kind = environment.getattr(l_3_param, 'kind')
                    _loop_vars['kind'] = l_3_kind
                    if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield str(context.call(environment.getattr((undefined(name='from_proto') if l_0_from_proto is missing else l_0_from_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars))
                        yield str(context.call(environment.getattr((undefined(name='to_proto') if l_0_to_proto is missing else l_0_to_proto), 'declare'), (undefined(name='method_type') if l_2_method_type is missing else l_2_method_type), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars))
                l_3_param = l_3_name = l_3_kind = missing
        l_2_method = l_2_method_type = missing
    l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        l_1_mojom_type = l_1_proto_type = missing
        _loop_vars = {}
        pass
        l_1_mojom_type = t_6(l_1_interface, flatten_nested_kind=True)
        _loop_vars['mojom_type'] = l_1_mojom_type
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_interface, flatten_nested_kind=True), ))
        _loop_vars['proto_type'] = l_1_proto_type
        if environment.getattr(l_1_interface, 'methods'):
            pass
            yield '\nbool HandleRemoteAction(\n  const '
            yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::RemoteAction& input);\n\nbool HandleAssociatedRemoteAction(\n  const '
            yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::AssociatedRemoteAction& input);\n\nbool HandleReceiverAction(\n  const '
            yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
            yield '::ReceiverAction& input);\n'
            for l_2_method in environment.getattr(l_1_interface, 'methods'):
                _loop_vars = {}
                pass
                yield '\nbool HandleRemoteCall(\n  uint32_t instance_id,\n  const '
                yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '& input);\n\nbool HandleAssociatedRemoteCall(\n  uint32_t instance_id,\n  const '
                yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield '& input);\n\nbool HandleResponse(\n  uint32_t callback_id,\n  const '
                yield str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type))
                yield '::'
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield 'Response& input);\n'
            l_2_method = missing
    l_1_interface = l_1_mojom_type = l_1_proto_type = missing
    yield '}  // namespace mojolpm\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=92&9=95&11=102&12=107&16=114&17=118&18=123&23=133&24=135&32=137&33=141&36=145&37=149&38=151&41=155&42=157&44=159&45=161&46=163&50=166&51=170&52=172&53=175&55=177&56=179&59=181&60=183&63=186&64=190&65=192&66=194&67=196&68=198&69=201&71=203&72=205&75=207&76=209&77=211&78=215&79=217&80=219&81=221&82=222&87=225&88=229&89=231&90=233&91=235&92=237&93=239&94=242&96=247&98=249&99=251&102=253&103=255&105=257&106=261&107=263&108=265&109=267&110=268&115=271&116=275&117=277&118=280&121=282&124=284&129=286&132=288&137=290&140=292&145=294&148=296&150=298&151=302&152=304&153=308&154=310&155=312&156=314&157=315&161=318&162=322&163=324&164=326&165=330&166=332&167=334&168=336&169=337&176=341&177=345&178=347&179=349&181=352&184=354&187=356&188=358&191=362&195=368&199=374&205=383'