from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm_to_proto_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_declare_array = l_0_declare_map = l_0_declare = l_0_define_array = l_0_define_map = l_0_define = l_0_define_enum = l_0_define_struct = l_0_define_union = missing
    try:
        t_1 = environment.filters['camel_to_under']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'camel_to_under' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_4 = environment.filters['cpp_wrapper_proto_type']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_proto_type' found.")
    try:
        t_5 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_6 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_7 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_8 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_9 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_10 = environment.filters['is_move_only_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_move_only_kind' found.")
    try:
        t_11 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_12 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_13 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_14 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_15 = environment.filters['is_value_kind']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_value_kind' found.")
    try:
        t_16 = environment.filters['nullable_is_same_kind']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'nullable_is_same_kind' found.")
    try:
        t_17 = environment.filters['to_unnullable_kind']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'to_unnullable_kind' found.")
    try:
        t_18 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_to_proto_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('util')
    def macro(l_1_type, l_1_kind):
        t_19 = []
        l_1_maybe_mojom_type = resolve('maybe_mojom_type')
        l_1_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        if t_12(environment.getattr(l_1_kind, 'kind')):
            pass
            l_1_maybe_mojom_type = t_5(t_17(environment.getattr(l_1_kind, 'kind')), add_same_module_namespaces=True)
        else:
            pass
            l_1_maybe_mojom_type = (undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)
        t_19.append(
            '\nbool ToProto(',
        )
        if t_10(environment.getattr(l_1_kind, 'kind')):
            pass
            t_19.extend((
                '\n  std::vector<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>&& input,',
            ))
        else:
            pass
            t_19.extend((
                '\n  const std::vector<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>& input,',
            ))
        t_19.extend((
            '\n  ',
            str(l_1_type),
            '& output);\n',
        ))
        if t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_19.extend((
                '\n',
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            t_19.extend((
                '\n',
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        else:
            pass
            t_19.extend((
                '\nbool ToProto(\n  ',
                str((undefined(name='maybe_mojom_type') if l_1_maybe_mojom_type is missing else l_1_maybe_mojom_type)),
                ' input,\n  ',
                str(l_1_type),
                'Entry& output);\n',
            ))
        return concat(t_19)
    context.exported_vars.add('declare_array')
    context.vars['declare_array'] = l_0_declare_array = Macro(environment, macro, 'declare_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_20 = []
        l_1_mojom_key_type = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_2(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_2(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        t_20.append(
            '\nbool ToProto(',
        )
        if (t_10(environment.getattr(l_1_kind, 'key_kind')) or t_10(environment.getattr(l_1_kind, 'value_kind'))):
            pass
            t_20.extend((
                '\n  base::flat_map<',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                 ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>&& input,',
            ))
        else:
            pass
            t_20.extend((
                '\n  const base::flat_map<',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                 ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>& input,',
            ))
        t_20.extend((
            '\n  ',
            str(l_1_type),
            '& output);\n',
        ))
        if t_8(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_20.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_20.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        else:
            pass
            t_20.extend((
                '\nbool ToProto(\n  ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' input,\n  ',
                str(l_1_type),
                'Key& output);\n',
            ))
        if t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_20.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_20.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_12(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_20.extend((
                '\nbool ToProto(\n  ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n  ',
                str(l_1_type),
                'Value& output);\n',
            ))
        else:
            pass
            t_20.extend((
                '\nbool ToProto(\n  ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n  ',
                str(l_1_type),
                'Value& output);\n',
            ))
        return concat(t_20)
    context.exported_vars.add('declare_map')
    context.vars['declare_map'] = l_0_declare_map = Macro(environment, macro, 'declare_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_21 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_8(l_1_kind):
            pass
            l_1_array_type = str_join((l_1_parent_name, '::', t_18(l_1_name), '_Array', ))
            t_21.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_9(l_1_kind):
            pass
            l_1_map_type = str_join((l_1_parent_name, '::', t_18(l_1_name), '_Map', ))
            t_21.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_21)
    context.exported_vars.add('declare')
    context.vars['declare'] = l_0_declare = Macro(environment, macro, 'declare', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_22 = []
        l_1_maybe_mojom_type = resolve('maybe_mojom_type')
        l_1_maybe_const = l_1_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_maybe_const = ('const ' if (not t_10(environment.getattr(l_1_kind, 'kind'))) else '')
        l_1_mojom_type = t_5(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        if t_12(environment.getattr(l_1_kind, 'kind')):
            pass
            l_1_maybe_mojom_type = t_5(t_17(environment.getattr(l_1_kind, 'kind')), add_same_module_namespaces=True)
        else:
            pass
            l_1_maybe_mojom_type = (undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)
        t_22.append(
            '\nbool ToProto(',
        )
        if t_10(environment.getattr(l_1_kind, 'kind')):
            pass
            t_22.extend((
                '\n  std::vector<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>&& input,',
            ))
        else:
            pass
            t_22.extend((
                '\n  const std::vector<',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>& input,',
            ))
        t_22.extend((
            '\n  ',
            str(l_1_type),
            '& output) {\n  bool result = true;\n\n  for (auto&& in_value : input) {',
        ))
        if t_12(environment.getattr(l_1_kind, 'kind')):
            pass
            t_22.extend((
                '\n    ',
                str(l_1_type),
                'Entry* out_value = output.mutable_values()->Add();\n    if (',
                str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                ') {',
            ))
            if t_10(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.extend((
                    '\n      ToProto(std::move(',
                    str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    '), *out_value);',
                ))
            else:
                pass
                t_22.extend((
                    '\n      ToProto(',
                    str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    ', *out_value);',
                ))
            t_22.append(
                '\n    }',
            )
        else:
            pass
            t_22.extend((
                '\n    ',
                str(l_1_type),
                'Entry* out_value = output.mutable_values()->Add();',
            ))
            if t_10(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.extend((
                    '\n    ToProto(std::move(',
                    str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    '), *out_value);',
                ))
            else:
                pass
                t_22.extend((
                    '\n    ToProto(',
                    str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), environment.getattr(l_1_kind, 'kind'), 'in_value')),
                    ', *out_value);',
                ))
        t_22.append(
            '\n  }\n\n  return result;\n}\n',
        )
        if t_8(environment.getattr(l_1_kind, 'kind')):
            pass
            t_22.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            t_22.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif (t_12(environment.getattr(l_1_kind, 'kind')) and (not t_15(environment.getattr(l_1_kind, 'kind')))):
            pass
            t_22.extend((
                '\nbool ToProto(\n    ',
                str((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const)),
                str((undefined(name='maybe_mojom_type') if l_1_maybe_mojom_type is missing else l_1_maybe_mojom_type)),
                ' input,\n    ',
                str(l_1_type),
                'Entry& output) {',
            ))
            if t_10(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            else:
                pass
                t_22.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_22.append(
                '\n}\n',
            )
        else:
            pass
            t_22.extend((
                '\nbool ToProto(\n    ',
                str((undefined(name='maybe_const') if l_1_maybe_const is missing else l_1_maybe_const)),
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                ' input,\n    ',
                str(l_1_type),
                'Entry& output) {',
            ))
            if t_15(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.extend((
                    '\n  bool mojolpm_result = true;\n  ',
                    str(t_4(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)),
                    ' value;',
                ))
                if t_12(environment.getattr(l_1_kind, 'kind')):
                    pass
                    t_22.append(
                        '\n  if (input.has_value()) {\n    mojolpm_result = ToProto(input.value(), value);\n    output.set_value(value);\n  }',
                    )
                else:
                    pass
                    t_22.append(
                        '\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);',
                    )
                t_22.append(
                    '\n  return mojolpm_result;',
                )
            elif t_7(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.extend((
                    '\n  bool mojolpm_result;\n  ',
                    str(t_4(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(std::move(input), value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_10(environment.getattr(l_1_kind, 'kind')):
                pass
                t_22.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            elif (t_12(environment.getattr(l_1_kind, 'kind')) and (not t_16(environment.getattr(l_1_kind, 'kind')))):
                pass
                t_22.append(
                    '\n  if (input) {\n    return ToProto(*input, *output.mutable_value());\n  } else {\n    return true;\n  }',
                )
            else:
                pass
                t_22.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_22.append(
                '\n}\n',
            )
        return concat(t_22)
    context.exported_vars.add('define_array')
    context.vars['define_array'] = l_0_define_array = Macro(environment, macro, 'define_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_23 = []
        l_1_maybe_const_key = l_1_mojom_key_type = l_1_maybe_const_value = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_maybe_const_key = ('const ' if (not t_10(environment.getattr(l_1_kind, 'key_kind'))) else '')
        l_1_mojom_key_type = t_2(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_maybe_const_value = ('const ' if (not t_10(environment.getattr(l_1_kind, 'key_kind'))) else '')
        l_1_mojom_value_type = t_2(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        t_23.append(
            '\nbool ToProto(',
        )
        if (t_10(environment.getattr(l_1_kind, 'key_kind')) or t_10(environment.getattr(l_1_kind, 'value_kind'))):
            pass
            t_23.extend((
                '\n    base::flat_map<',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                   ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>&& input,',
            ))
        else:
            pass
            t_23.extend((
                '\n    const base::flat_map<',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ',\n                         ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '>& input,',
            ))
        t_23.extend((
            '\n    ',
            str(l_1_type),
            '& output) {\n  bool result = true;\n\n  for (auto& in_entry : input) {\n    auto out_entry = output.mutable_values()->Add();',
        ))
        if t_10(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_23.append(
                '\n    result = ToProto(std::move(in_entry.first), *out_entry->mutable_key());',
            )
        else:
            pass
            t_23.append(
                '\n    result = ToProto(in_entry.first, *out_entry->mutable_key());',
            )
        t_23.append(
            '\n    if (!result) {\n      break;\n    }',
        )
        if t_12(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_23.extend((
                '\n    if (',
                str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), environment.getattr(l_1_kind, 'value_kind'), 'in_entry.second')),
                ') {',
            ))
            if t_13(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_23.append(
                    '\n      result = ToProto(std::move(in_entry.second), *out_entry->mutable_value());',
                )
            elif t_10(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_23.append(
                    '\n      result = ToProto(std::move(*in_entry.second), *out_entry->mutable_value());',
                )
            else:
                pass
                t_23.append(
                    '\n      result = ToProto(*in_entry.second, *out_entry->mutable_value());',
                )
            t_23.append(
                '\n    }',
            )
        elif t_10(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_23.append(
                '\n    result = ToProto(std::move(in_entry.second), *out_entry->mutable_value());',
            )
        else:
            pass
            t_23.append(
                '\n    result = ToProto(in_entry.second, *out_entry->mutable_value());',
            )
        t_23.append(
            '\n    if (!result) {\n      break;\n    }\n  }\n\n  return result;\n}\n',
        )
        if t_8(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_23.extend((
                '\n',
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        elif t_9(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_23.extend((
                '\n',
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        else:
            pass
            t_23.extend((
                '\nbool ToProto(\n    ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' input,\n    ',
                str(l_1_type),
                'Key& output) {',
            ))
            if t_15(environment.getattr(l_1_kind, 'key_kind')):
                pass
                t_23.extend((
                    '\n  bool mojolpm_result;\n  ',
                    str(t_4(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif t_10(environment.getattr(l_1_kind, 'key_kind')):
                pass
                t_23.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            elif (t_12(environment.getattr(l_1_kind, 'key_kind')) and (not t_16(environment.getattr(l_1_kind, 'key_kind')))):
                pass
                t_23.append(
                    '\n  if (input) {\n    return ToProto(*input, *output.mutable_value());\n  } else {\n    return true;\n  }',
                )
            else:
                pass
                t_23.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_23.append(
                '\n}\n',
            )
        if t_8(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_23.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_23.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        else:
            pass
            t_23.extend((
                '\nbool ToProto(\n    ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' input,\n    ',
                str(l_1_type),
                'Value& output) {',
            ))
            if t_15(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_23.extend((
                    '\n  bool mojolpm_result = true;\n  ',
                    str(t_4(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)),
                    ' value;',
                ))
                if t_12(environment.getattr(l_1_kind, 'value_kind')):
                    pass
                    t_23.append(
                        '\n  if (input.has_value()) {\n    mojolpm_result = ToProto(input.value(), value);\n    output.set_value(value);\n  }',
                    )
                else:
                    pass
                    t_23.append(
                        '\n  mojolpm_result = ToProto(input, value);\n  output.set_value(value);',
                    )
                t_23.append(
                    '\n  return mojolpm_result;',
                )
            elif t_7(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_23.extend((
                    '\n  bool mojolpm_result;\n  ',
                    str(t_4(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)),
                    ' value;\n  mojolpm_result = ToProto(std::move(input), value);\n  output.set_value(value);\n  return mojolpm_result;',
                ))
            elif (t_12(environment.getattr(l_1_kind, 'value_kind')) and (not t_16(environment.getattr(l_1_kind, 'value_kind')))):
                pass
                t_23.append(
                    '\n  if (input) {',
                )
                if t_10(environment.getattr(l_1_kind, 'value_kind')):
                    pass
                    t_23.append(
                        '\n    return ToProto(std::move(*input), *output.mutable_value());',
                    )
                else:
                    pass
                    t_23.append(
                        '\n    return ToProto(*input, *output.mutable_value());',
                    )
                t_23.append(
                    '\n  } else {\n    return true;\n  }',
                )
            elif t_10(environment.getattr(l_1_kind, 'value_kind')):
                pass
                t_23.append(
                    '\n  return ToProto(std::move(input), *output.mutable_value());',
                )
            else:
                pass
                t_23.append(
                    '\n  return ToProto(input, *output.mutable_value());',
                )
            t_23.append(
                '\n}\n',
            )
        return concat(t_23)
    context.exported_vars.add('define_map')
    context.vars['define_map'] = l_0_define_map = Macro(environment, macro, 'define_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_24 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_8(l_1_kind):
            pass
            l_1_array_type = str_join((l_1_parent_name, '::', t_18(l_1_name), '_Array', ))
            t_24.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_9(l_1_kind):
            pass
            l_1_map_type = str_join((l_1_parent_name, '::', t_18(l_1_name), '_Map', ))
            t_24.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_24)
    context.exported_vars.add('define')
    context.vars['define'] = l_0_define = Macro(environment, macro, 'define', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_25 = []
        l_1_mojom_type = l_1_proto_type = l_1_enum_type = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_mojom_type = t_2(l_1_enum, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_enum, flatten_nested_kind=True), ))
        l_1_enum_type = t_6(l_1_enum, flatten_nested_kind=True)
        t_25.extend((
            '\nbool ToProto(\n  const ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& input,\n  ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if (t_11(l_1_enum) or (not t_14(l_1_enum))):
            pass
            t_25.extend((
                "\n  // This ignores IPC_PARAM_TRAITS for native IPC enums, but internal to the\n  // fuzzer we don't want the overhead of the serialization layer if we don't\n  // need it. This doesn't change the actual checks on the receiving end.\n  output = static_cast<",
                str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                '>(input);\n  return true;',
            ))
        else:
            pass
            t_25.extend((
                '\n  output = static_cast<',
                str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
                '>(\n    ::mojo::EnumTraits<',
                str((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                ', ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::ToMojom(input));\n  return true;',
            ))
        t_25.append(
            '\n}\n',
        )
        return concat(t_25)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_26 = []
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_3(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        t_26.extend((
            '\nbool ToProto(\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            ' input,\n    ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if t_11(l_1_struct):
            pass
            t_26.extend((
                '\n  ',
                str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '* new_instance = output.mutable_new_();\n  std::string* bytes = new_instance->mutable_native_bytes();\n  bytes->resize(sizeof(',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '), 0);\n  memcpy(bytes->data(), (void*)&input, sizeof(',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '));\n  return true;',
            ))
        elif t_14(l_1_struct):
            pass
            t_26.append(
                '\n  // TODO(markbrand): ToProto for typemapped struct kind\n  return false;',
            )
        elif environment.getattr(l_1_struct, 'fields'):
            pass
            t_26.extend((
                '\n   ',
                str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '* new_instance = output.mutable_new_();\n  bool mojolpm_result = true;',
            ))
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_raw_name = l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_raw_name = environment.getattr(l_2_field, 'name')
                _loop_vars['raw_name'] = l_2_raw_name
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_26.extend((
                        '\n  ',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(std::move(input->',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '), tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_26.extend((
                        '\n  if (',
                        str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )), _loop_vars=_loop_vars)),
                        ') {',
                    ))
                    if t_15((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_26.extend((
                            '\n    ',
                            str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                            ' tmp_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ';\n    mojolpm_result &= ToProto(*input->',
                            str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                            ', tmp_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ');\n    new_instance->set_m_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '(tmp_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            ');',
                        ))
                    elif t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_26.extend((
                            '\n    mojolpm_result &= ToProto(std::move(',
                            str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )), _loop_vars=_loop_vars)),
                            '), *new_instance->mutable_m_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    else:
                        pass
                        t_26.extend((
                            '\n    mojolpm_result &= ToProto(',
                            str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), )), _loop_vars=_loop_vars)),
                            ', *new_instance->mutable_m_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    t_26.append(
                        '\n  }',
                    )
                elif t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_26.extend((
                        '\n  mojolpm_result &= ToProto(std::move(input->',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '), *new_instance->mutable_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                elif t_15((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_26.extend((
                        '\n  ',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(input->',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        ', tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                else:
                    pass
                    t_26.extend((
                        '\n  mojolpm_result &= ToProto(input->',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        ', *new_instance->mutable_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
            l_2_field = l_2_raw_name = l_2_name = l_2_kind = missing
            t_26.append(
                '\n  return mojolpm_result;',
            )
        else:
            pass
            t_26.append(
                '\n  output.new_();\n  return true;',
            )
        t_26.append(
            '\n}\n',
        )
        return concat(t_26)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_27 = []
        l_1_enum_name = resolve('enum_name')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_3(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_6(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        t_27.extend((
            '\nbool ToProto(\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            ' input,\n    ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& output) {',
        ))
        if t_14(l_1_union):
            pass
            t_27.append(
                '\n  // TODO(markbrand): ToProto for typemapped union kind.\n  return false;',
            )
        else:
            pass
            l_1_enum_name = str_join((t_6(l_1_union, flatten_nested_kind=True, internal=True), '::', environment.getattr(l_1_union, 'name'), '_Tag', ))
            t_27.extend((
                '\n  ',
                str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '* new_instance = output.mutable_new_();\n  bool mojolpm_result = true;\n  switch (input->which()) {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_raw_name = l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_raw_name = environment.getattr(l_2_field, 'name')
                _loop_vars['raw_name'] = l_2_raw_name
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                t_27.extend((
                    '\n    case ',
                    str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name)),
                    '::k',
                    str(t_18(environment.getattr(l_2_field, 'name'), digits_split=False)),
                    ': {',
                ))
                if t_15((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  ',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(input->get_',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '(), tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  ',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)),
                        ' tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  mojolpm_result &= ToProto(std::move(input->get_',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '()), tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  new_instance->set_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(tmp_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                elif t_12((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  if (',
                        str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'not_null'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )), _loop_vars=_loop_vars)),
                        ') {',
                    ))
                    if t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        t_27.extend((
                            '\n    mojolpm_result &= ToProto(std::move(',
                            str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )), _loop_vars=_loop_vars)),
                            '), *new_instance->mutable_m_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    else:
                        pass
                        t_27.extend((
                            '\n    mojolpm_result &= ToProto(',
                            str(context.call(environment.getattr((undefined(name='util') if l_0_util is missing else l_0_util), 'value'), (undefined(name='kind') if l_2_kind is missing else l_2_kind), str_join(('input->get_', (undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name), '()', )), _loop_vars=_loop_vars)),
                            ', *new_instance->mutable_m_',
                            str((undefined(name='name') if l_2_name is missing else l_2_name)),
                            '());',
                        ))
                    t_27.append(
                        '\n  }',
                    )
                elif t_10((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    t_27.extend((
                        '\n  mojolpm_result &= ToProto(std::move(input->get_',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '()), *new_instance->mutable_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                else:
                    pass
                    t_27.extend((
                        '\n  mojolpm_result &= ToProto(input->get_',
                        str((undefined(name='raw_name') if l_2_raw_name is missing else l_2_raw_name)),
                        '(), *new_instance->mutable_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '());',
                    ))
                t_27.append(
                    '\n    } break;',
                )
            l_2_field = l_2_raw_name = l_2_name = l_2_kind = missing
            t_27.append(
                '\n  }\n  return mojolpm_result;',
            )
        t_27.append(
            '\n}\n',
        )
        return concat(t_27)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=120&4=122&5=131&6=132&7=134&9=137&12=141&13=145&15=152&17=157&18=160&19=164&20=166&21=170&24=176&25=178&29=184&30=192&31=193&33=197&34=201&35=203&37=210&38=212&40=217&41=220&42=223&43=225&44=228&47=234&48=236&50=239&51=242&52=244&53=247&54=249&56=253&57=255&60=262&61=264&66=270&67=281&68=283&69=285&70=287&71=289&72=291&77=296&78=305&79=306&80=307&81=309&83=312&86=316&87=320&89=327&91=332&95=335&96=339&97=341&98=344&99=348&101=355&105=365&106=368&107=372&109=379&116=385&117=388&118=390&119=393&120=395&122=399&123=402&124=405&132=422&133=425&134=428&136=432&137=435&147=448&149=452&153=455&155=460&169=476&170=484&171=485&172=486&173=487&175=491&176=495&177=497&179=504&180=506&182=511&187=514&195=527&196=531&197=534&199=539&205=552&217=565&218=569&219=571&220=575&223=581&224=583&225=586&227=590&231=593&233=598&244=611&245=614&246=616&247=619&250=625&251=627&252=630&254=634&255=637&265=650&267=654&271=657&273=662&281=675&291=691&292=702&293=704&294=706&295=708&296=710&297=712&302=717&303=723&304=724&305=725&307=728&308=730&309=733&313=737&316=744&317=746&324=757&325=763&326=764&327=765&329=768&330=770&331=773&332=777&334=779&335=781&337=784&340=789&341=793&343=796&344=800&345=802&346=804&347=806&348=810&349=814&350=818&351=823&352=827&353=830&354=834&355=838&356=842&357=847&358=851&360=860&363=868&364=872&365=877&366=881&367=885&368=889&370=898&382=918&383=925&384=926&385=927&387=930&388=932&389=935&393=942&394=945&397=948&398=952&399=954&400=956&401=960&402=965&403=969&404=973&405=977&406=982&407=986&408=990&409=994&410=999&411=1003&412=1006&413=1010&415=1019&418=1027&419=1031&421=1040'