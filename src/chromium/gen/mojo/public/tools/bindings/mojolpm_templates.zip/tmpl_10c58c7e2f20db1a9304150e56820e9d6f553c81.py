from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm.proto.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_proto_imports = resolve('proto_imports')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_enums = resolve('enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_module_prefix = l_0_optional_or_required = l_0_forward_declare_field_types_inner = l_0_forward_declare_field_types = missing
    try:
        t_1 = environment.filters['camel_to_under']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'camel_to_under' found.")
    try:
        t_2 = environment.filters['enum_field_name']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'enum_field_name' found.")
    try:
        t_3 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_4 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_5 = environment.filters['has_duplicate_values']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'has_duplicate_values' found.")
    try:
        t_6 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_7 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_8 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_9 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_10 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_11 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_12 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_13 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_14 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_15 = environment.filters['lower']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'lower' found.")
    try:
        t_16 = environment.filters['proto_field_type']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'proto_field_type' found.")
    try:
        t_17 = environment.filters['proto_id']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'proto_id' found.")
    try:
        t_18 = environment.filters['replace']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'replace' found.")
    try:
        t_19 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_19(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    yield '// Copyright 2019 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\nsyntax = "proto2";\n\npackage mojolpm.'
    yield str(t_18(context.eval_ctx, environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'mojom_namespace'), '/', '.'))
    yield ';\n\n'
    for l_1_proto_import in (undefined(name='proto_imports') if l_0_proto_imports is missing else l_0_proto_imports):
        _loop_vars = {}
        pass
        yield '\nimport "'
        yield str(l_1_proto_import)
        yield '";'
    l_1_proto_import = missing
    l_0_module_prefix = t_3('%s', t_13(context.eval_ctx, (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array), '.'))
    context.vars['module_prefix'] = l_0_module_prefix
    context.exported_vars.add('module_prefix')
    def macro(l_1_kind):
        t_20 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        if t_10(l_1_kind):
            pass
            t_20.append(
                'optional',
            )
        else:
            pass
            t_20.append(
                'required',
            )
        return concat(t_20)
    context.exported_vars.add('optional_or_required')
    context.vars['optional_or_required'] = l_0_optional_or_required = Macro(environment, macro, 'optional_or_required', ('kind',), False, False, False, context.eval_ctx.autoescape)
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        l_1_i = resolve('i')
        l_1_enum_name = missing
        _loop_vars = {}
        pass
        l_1_enum_name = t_4(l_1_enum, flatten_nested_kind=True)
        _loop_vars['enum_name'] = l_1_enum_name
        if t_9(l_1_enum):
            pass
            yield '\n// WARNING Native only enum support '
            yield str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name))
            yield ' is very basic.\nenum '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield ' {\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_0 = 0;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_1 = 1;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_2 = 2;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_3 = 3;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_4 = 4;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_5 = 5;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_6 = 6;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_7 = 7;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_8 = 8;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_9 = 9;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_10 = 10;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_11 = 11;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_12 = 12;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_13 = 13;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_14 = 14;\n  '
            yield str(environment.getattr(l_1_enum, 'name'))
            yield '_15 = 15;\n}'
        else:
            pass
            yield '\n\nenum '
            yield str((undefined(name='enum_name') if l_1_enum_name is missing else l_1_enum_name))
            yield ' {'
            if t_5(l_1_enum):
                pass
                yield '\n  option allow_alias = true;'
            l_1_i = 0
            _loop_vars['i'] = l_1_i
            for l_2_field in environment.getattr(l_1_enum, 'fields'):
                _loop_vars = {}
                pass
                yield '\n  MojoLPM_'
                yield str(environment.getattr(l_1_enum, 'name'))
                yield '_'
                yield str(t_2(environment.getattr(l_2_field, 'name'), l_1_enum))
                yield ' = '
                yield str(environment.getattr(l_2_field, 'numeric_value'))
                yield ';'
            l_2_field = missing
            yield '\n}'
    l_1_enum = l_1_enum_name = l_1_i = missing
    def macro(l_1_kind, l_1_name):
        t_21 = []
        l_1_entry_name = resolve('entry_name')
        l_1_key_name = resolve('key_name')
        l_1_value_name = resolve('value_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_7(l_1_kind):
            pass
            l_1_entry_name = str_join((l_1_name, 'Entry', ))
            if (t_7(environment.getattr(l_1_kind, 'kind')) or t_8(environment.getattr(l_1_kind, 'kind'))):
                pass
                t_21.extend((
                    '\n',
                    str(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'kind'), (undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name))),
                ))
            else:
                pass
                t_21.extend((
                    '\n  message ',
                    str((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                    ' {\n    ',
                    str(t_16(environment.getattr(l_1_kind, 'kind'))),
                    ' value = 1;\n  }',
                ))
            t_21.extend((
                '\n\n  message ',
                str(l_1_name),
                ' {\n    repeated ',
                str((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' values = 1;\n  }',
            ))
        elif t_8(l_1_kind):
            pass
            l_1_entry_name = str_join((l_1_name, 'Entry', ))
            l_1_key_name = str_join((l_1_name, 'Key', ))
            l_1_value_name = str_join((l_1_name, 'Value', ))
            if (t_7(environment.getattr(l_1_kind, 'key_kind')) or t_8(environment.getattr(l_1_kind, 'key_kind'))):
                pass
                t_21.append(
                    str(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'key_kind'), (undefined(name='key_name') if l_1_key_name is missing else l_1_key_name))),
                )
            else:
                pass
                t_21.extend((
                    '\n  message ',
                    str((undefined(name='key_name') if l_1_key_name is missing else l_1_key_name)),
                    ' {\n    ',
                    str(t_16(environment.getattr(l_1_kind, 'key_kind'))),
                    ' value = 1;\n  }\n',
                ))
            if (t_7(environment.getattr(l_1_kind, 'value_kind')) or t_8(environment.getattr(l_1_kind, 'value_kind'))):
                pass
                t_21.append(
                    str(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), environment.getattr(l_1_kind, 'value_kind'), (undefined(name='value_name') if l_1_value_name is missing else l_1_value_name))),
                )
            else:
                pass
                t_21.extend((
                    '\n  message ',
                    str((undefined(name='value_name') if l_1_value_name is missing else l_1_value_name)),
                    ' {\n    ',
                    str(t_16(environment.getattr(l_1_kind, 'value_kind'))),
                    ' value = 1;\n  }\n',
                ))
            t_21.extend((
                '\n  message ',
                str((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' {\n    required ',
                str((undefined(name='key_name') if l_1_key_name is missing else l_1_key_name)),
                ' key = 1;\n    required ',
                str((undefined(name='value_name') if l_1_value_name is missing else l_1_value_name)),
                ' value = 2;\n  }\n\n  message ',
                str(l_1_name),
                ' {\n    repeated ',
                str((undefined(name='entry_name') if l_1_entry_name is missing else l_1_entry_name)),
                ' values = 1;\n  }',
            ))
        t_21.append(
            '\n',
        )
        return concat(t_21)
    context.exported_vars.add('forward_declare_field_types_inner')
    context.vars['forward_declare_field_types_inner'] = l_0_forward_declare_field_types_inner = Macro(environment, macro, 'forward_declare_field_types_inner', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_22 = []
        l_1_array_name = resolve('array_name')
        l_1_map_name = resolve('map_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_7(l_1_kind):
            pass
            l_1_array_name = str_join((t_19(l_1_name), '_Array', ))
            t_22.append(
                str(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), l_1_kind, (undefined(name='array_name') if l_1_array_name is missing else l_1_array_name))),
            )
        elif t_8(l_1_kind):
            pass
            l_1_map_name = str_join((t_19(l_1_name), '_Map', ))
            t_22.extend((
                '\n',
                str(context.call((undefined(name='forward_declare_field_types_inner') if l_0_forward_declare_field_types_inner is missing else l_0_forward_declare_field_types_inner), l_1_kind, (undefined(name='map_name') if l_1_map_name is missing else l_1_map_name))),
            ))
        t_22.append(
            '\n',
        )
        return concat(t_22)
    context.exported_vars.add('forward_declare_field_types')
    context.vars['forward_declare_field_types'] = l_0_forward_declare_field_types = Macro(environment, macro, 'forward_declare_field_types', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_struct_name = missing
        _loop_vars = {}
        pass
        l_1_struct_name = t_4(l_1_struct, flatten_nested_kind=True)
        _loop_vars['struct_name'] = l_1_struct_name
        if t_9(l_1_struct):
            pass
            yield '\nmessage '
            yield str((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
            yield '_ProtoStruct {\n  // native-only struct\n  required uint32 id = 1;\n  required bytes native_bytes = 2;\n}'
        else:
            pass
            yield '\n\nmessage '
            yield str((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
            yield '_ProtoStruct {\n  required uint32 id = 1;'
            for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
                l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                _loop_vars['kind'] = l_2_kind
                if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    yield str(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
            l_2_pf = l_2_name = l_2_kind = missing
            for l_2_pf in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
                l_2_original_field = resolve('original_field')
                l_2_kind = resolve('kind')
                l_2_name = resolve('name')
                _loop_vars = {}
                pass
                if t_11(l_2_pf):
                    pass
                    if t_12(l_2_pf):
                        pass
                        l_2_original_field = environment.getattr(l_2_pf, 'original_field')
                        _loop_vars['original_field'] = l_2_original_field
                        l_2_kind = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'kind')
                        _loop_vars['kind'] = l_2_kind
                        l_2_name = environment.getattr((undefined(name='original_field') if l_2_original_field is missing else l_2_original_field), 'name')
                        _loop_vars['name'] = l_2_name
                        yield '\n  '
                        yield str(t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ' m_'
                        yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ';'
                else:
                    pass
                    l_2_name = t_1(environment.getattr(environment.getattr(l_2_pf, 'field'), 'name'))
                    _loop_vars['name'] = l_2_name
                    l_2_kind = environment.getattr(environment.getattr(l_2_pf, 'field'), 'kind')
                    _loop_vars['kind'] = l_2_kind
                    if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        yield '\n  '
                        yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_2_kind is missing else l_2_kind), _loop_vars=_loop_vars))
                        yield ' '
                        yield str(t_19((undefined(name='name') if l_2_name is missing else l_2_name)))
                        yield '_Array m_'
                        yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ';'
                    elif t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                        pass
                        yield '\n  '
                        yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_2_kind is missing else l_2_kind), _loop_vars=_loop_vars))
                        yield ' '
                        yield str(t_19((undefined(name='name') if l_2_name is missing else l_2_name)))
                        yield '_Map m_'
                        yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ';'
                    else:
                        pass
                        yield '\n  '
                        yield str(t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ' m_'
                        yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                        yield ';'
            l_2_pf = l_2_original_field = l_2_kind = l_2_name = missing
            yield '\n}'
        yield '\n\nmessage '
        yield str((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
        yield ' {'
        for l_2_enum in environment.getattr(l_1_struct, 'enums'):
            l_2_i = resolve('i')
            l_2_enum_name = missing
            _loop_vars = {}
            pass
            l_2_enum_name = t_4(l_2_enum, flatten_nested_kind=True)
            _loop_vars['enum_name'] = l_2_enum_name
            if t_9(l_2_enum):
                pass
                yield '\n  // WARNING Native only enum support '
                yield str((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                yield ' is very basic.\n  enum '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield ' {\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_0 = 0;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_1 = 1;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_2 = 2;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_3 = 3;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_4 = 4;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_5 = 5;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_6 = 6;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_7 = 7;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_8 = 8;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_9 = 9;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_10 = 10;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_11 = 11;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_12 = 12;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_13 = 13;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_14 = 14;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_15 = 15;\n  }'
            else:
                pass
                yield '\n\n  enum '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield ' {'
                if t_5(l_2_enum):
                    pass
                    yield '\n    option allow_alias = true;'
                l_2_i = 0
                _loop_vars['i'] = l_2_i
                for l_3_field in environment.getattr(l_2_enum, 'fields'):
                    _loop_vars = {}
                    pass
                    yield '\n    '
                    yield str((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                    yield '_'
                    yield str(environment.getattr(l_3_field, 'name'))
                    yield ' = '
                    yield str(environment.getattr(l_3_field, 'numeric_value'))
                    yield ';'
                l_3_field = missing
                yield '\n  }'
        l_2_enum = l_2_enum_name = l_2_i = missing
        yield '\n\n  oneof instance {\n    uint32 old = 1;\n    '
        yield str((undefined(name='struct_name') if l_1_struct_name is missing else l_1_struct_name))
        yield '_ProtoStruct new = 2;\n  }\n}'
    l_1_struct = l_1_struct_name = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_union_name = missing
        _loop_vars = {}
        pass
        l_1_union_name = t_4(l_1_union, flatten_nested_kind=True)
        _loop_vars['union_name'] = l_1_union_name
        if t_9(l_1_union):
            pass
            yield '\n// ERROR native-only union kind'
        else:
            pass
            yield '\n\nmessage '
            yield str((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield '_ProtoUnion {\n  required uint32 id = 1;'
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                if (t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)) or t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    yield str(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_2_kind is missing else l_2_kind), (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars))
            l_2_field = l_2_name = l_2_kind = missing
            yield '\n  oneof union_member {'
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_name = t_15(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                if t_7((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n    '
                    yield str(t_19((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Array m_'
                    yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                elif t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    yield '\n    '
                    yield str(t_19((undefined(name='name') if l_2_name is missing else l_2_name)))
                    yield '_Map m_'
                    yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
                else:
                    pass
                    yield '\n    '
                    yield str(t_16((undefined(name='kind') if l_2_kind is missing else l_2_kind), quantified=False))
                    yield ' m_'
                    yield str((undefined(name='name') if l_2_name is missing else l_2_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_2_name is missing else l_2_name), (undefined(name='kind') if l_2_kind is missing else l_2_kind)))
                    yield ';'
            l_2_field = l_2_name = l_2_kind = missing
            yield '\n  }\n}\n\nmessage '
            yield str((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield ' {\n  oneof instance {\n    uint32 old = 1;\n    '
            yield str((undefined(name='union_name') if l_1_union_name is missing else l_1_union_name))
            yield '_ProtoUnion new = 2;\n  }\n}'
    l_1_union = l_1_union_name = missing
    l_1_loop = missing
    for l_1_interface, l_1_loop in LoopContext((undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces), undefined):
        _loop_vars = {}
        pass
        yield '\n\nmessage '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ' {\n  message Reset {\n  }'
        for l_2_enum in environment.getattr(l_1_interface, 'enums'):
            l_2_i = resolve('i')
            l_2_enum_name = missing
            _loop_vars = {}
            pass
            l_2_enum_name = t_4(l_2_enum, flatten_nested_kind=True)
            _loop_vars['enum_name'] = l_2_enum_name
            if t_9(l_2_enum):
                pass
                yield '\n  // WARNING Native only enum support '
                yield str((undefined(name='enum_name') if l_2_enum_name is missing else l_2_enum_name))
                yield ' is very basic.\n  enum '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield ' {\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_0 = 0;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_1 = 1;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_2 = 2;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_3 = 3;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_4 = 4;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_5 = 5;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_6 = 6;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_7 = 7;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_8 = 8;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_9 = 9;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_10 = 10;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_11 = 11;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_12 = 12;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_13 = 13;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_14 = 14;\n    '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield '_15 = 15;\n  }'
            else:
                pass
                yield '\n\n  enum '
                yield str(environment.getattr(l_2_enum, 'name'))
                yield ' {'
                if t_5(l_2_enum):
                    pass
                    yield '\n    option allow_alias = true;'
                l_2_i = 0
                _loop_vars['i'] = l_2_i
                for l_3_field in environment.getattr(l_2_enum, 'fields'):
                    _loop_vars = {}
                    pass
                    yield '\n    '
                    yield str(environment.getattr(l_2_enum, 'name'))
                    yield '_'
                    yield str(environment.getattr(l_3_field, 'name'))
                    yield ' = '
                    yield str(environment.getattr(l_3_field, 'numeric_value'))
                    yield ';'
                l_3_field = missing
                yield '\n  }'
        l_2_enum = l_2_enum_name = l_2_i = missing
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            yield '\n\n  message '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield '_'
            yield str(environment.getattr(l_2_method, 'name'))
            yield ' {'
            for l_3_parameter in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                _loop_vars = {}
                pass
                l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                _loop_vars['name'] = l_3_name
                l_3_kind = environment.getattr(l_3_parameter, 'kind')
                _loop_vars['kind'] = l_3_kind
                if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                    pass
                    yield str(t_6(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars), width=2))
            l_3_parameter = l_3_name = l_3_kind = missing
            for l_3_parameter in environment.getattr(l_2_method, 'parameters'):
                l_3_name = l_3_kind = missing
                _loop_vars = {}
                pass
                l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                _loop_vars['name'] = l_3_name
                l_3_kind = environment.getattr(l_3_parameter, 'kind')
                _loop_vars['kind'] = l_3_kind
                if t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                    pass
                    yield '\n    '
                    yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind), _loop_vars=_loop_vars))
                    yield ' '
                    yield str(t_19((undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield '_Array m_'
                    yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
                elif t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                    pass
                    yield '\n    '
                    yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind), _loop_vars=_loop_vars))
                    yield ' '
                    yield str(t_19((undefined(name='name') if l_3_name is missing else l_3_name)))
                    yield '_Map m_'
                    yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
                else:
                    pass
                    yield '\n    '
                    yield str(t_16((undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ' m_'
                    yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                    yield ' = '
                    yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                    yield ';'
            l_3_parameter = l_3_name = l_3_kind = missing
            yield '\n  }\n\n  message '
            yield str(environment.getattr(l_1_interface, 'name'))
            yield '_'
            yield str(environment.getattr(l_2_method, 'name'))
            yield 'Response {'
            if environment.getattr(l_2_method, 'response_parameters'):
                pass
                for l_3_parameter in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    _loop_vars = {}
                    pass
                    l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                    _loop_vars['name'] = l_3_name
                    l_3_kind = environment.getattr(l_3_parameter, 'kind')
                    _loop_vars['kind'] = l_3_kind
                    if (t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)) or t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind))):
                        pass
                        yield str(t_6(context.call((undefined(name='forward_declare_field_types') if l_0_forward_declare_field_types is missing else l_0_forward_declare_field_types), (undefined(name='kind') if l_3_kind is missing else l_3_kind), (undefined(name='name') if l_3_name is missing else l_3_name), _loop_vars=_loop_vars), width=2))
                l_3_parameter = l_3_name = l_3_kind = missing
                for l_3_parameter in environment.getattr(l_2_method, 'response_parameters'):
                    l_3_name = l_3_kind = missing
                    _loop_vars = {}
                    pass
                    l_3_name = t_1(environment.getattr(l_3_parameter, 'name'))
                    _loop_vars['name'] = l_3_name
                    l_3_kind = environment.getattr(l_3_parameter, 'kind')
                    _loop_vars['kind'] = l_3_kind
                    if t_7((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                        pass
                        yield '\n    '
                        yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind), _loop_vars=_loop_vars))
                        yield ' '
                        yield str(t_19((undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield '_Array m_'
                        yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                    elif t_8((undefined(name='kind') if l_3_kind is missing else l_3_kind)):
                        pass
                        yield '\n    '
                        yield str(context.call((undefined(name='optional_or_required') if l_0_optional_or_required is missing else l_0_optional_or_required), (undefined(name='kind') if l_3_kind is missing else l_3_kind), _loop_vars=_loop_vars))
                        yield ' '
                        yield str(t_19((undefined(name='name') if l_3_name is missing else l_3_name)))
                        yield '_Map m_'
                        yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                    else:
                        pass
                        yield '\n    '
                        yield str(t_16((undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ' m_'
                        yield str((undefined(name='name') if l_3_name is missing else l_3_name))
                        yield ' = '
                        yield str(t_17((undefined(name='name') if l_3_name is missing else l_3_name), (undefined(name='kind') if l_3_kind is missing else l_3_kind)))
                        yield ';'
                l_3_parameter = l_3_name = l_3_kind = missing
            yield '\n  }'
        l_2_method = missing
        if t_14(environment.getattr(l_1_interface, 'methods')):
            pass
            yield '\n  message RemoteAction {\n    required uint32 id = 1;\n\n    oneof method {\n      Reset reset = 2;'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                _loop_vars = {}
                pass
                yield '\n      '
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield ' m_'
                yield str(t_1(environment.getattr(l_2_method, 'name')))
                yield ' = '
                yield str((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }\n\n  message AssociatedRemoteAction {\n    required uint32 id = 1;\n\n    oneof method {\n      Reset reset = 2;'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                _loop_vars = {}
                pass
                yield '\n      '
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield ' m_'
                yield str(t_1(environment.getattr(l_2_method, 'name')))
                yield ' = '
                yield str((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }\n\n  message ReceiverAction {\n    required uint32 id = 1;\n\n    oneof response {'
            l_2_loop = missing
            for l_2_method, l_2_loop in LoopContext(environment.getattr(l_1_interface, 'methods'), undefined):
                _loop_vars = {}
                pass
                yield '\n      '
                yield str(environment.getattr(l_1_interface, 'name'))
                yield '_'
                yield str(environment.getattr(l_2_method, 'name'))
                yield 'Response m_'
                yield str(t_1(environment.getattr(l_2_method, 'name')))
                yield '_response = '
                yield str((environment.getattr(l_2_loop, 'index') + 2))
                yield ';'
            l_2_loop = l_2_method = missing
            yield '\n    }\n  }'
        yield '\n}'
    l_1_loop = l_1_interface = missing

blocks = {}
debug_info = '7=134&9=136&10=140&13=143&15=146&16=151&21=164&22=169&23=171&24=174&25=176&26=178&27=180&28=182&29=184&30=186&31=188&32=190&33=192&34=194&35=196&36=198&37=200&38=202&39=204&40=206&41=208&45=213&46=215&49=218&50=220&51=224&57=233&58=243&59=245&60=246&61=250&63=256&64=258&68=263&69=265&72=268&73=270&74=271&75=272&76=273&77=276&79=282&80=284&83=287&84=290&86=296&87=298&90=303&91=305&92=307&95=309&96=311&101=320&102=329&103=331&104=333&105=335&106=337&107=340&111=348&112=352&113=354&114=357&121=362&123=364&124=368&125=370&126=372&127=374&130=376&131=382&132=384&133=386&134=388&135=390&136=393&139=401&140=403&141=405&142=408&143=416&144=419&146=430&153=439&154=441&155=446&156=448&157=451&158=453&159=455&160=457&161=459&162=461&163=463&164=465&165=467&166=469&167=471&168=473&169=475&170=477&171=479&172=481&173=483&174=485&178=490&179=492&182=495&183=497&184=501&192=511&197=514&198=518&199=520&203=526&205=528&206=532&207=534&208=536&209=538&213=541&214=545&215=547&216=549&217=552&218=558&219=561&221=570&227=578&230=580&236=584&238=588&242=590&243=595&244=597&245=600&246=602&247=604&248=606&249=608&250=610&251=612&252=614&253=616&254=618&255=620&256=622&257=624&258=626&259=628&260=630&261=632&262=634&266=639&267=641&270=644&271=646&272=650&278=659&280=663&281=667&282=671&283=673&284=675&285=677&288=679&289=683&290=685&291=687&292=690&293=698&294=701&296=712&301=720&302=724&303=726&304=730&305=732&306=734&307=736&310=738&311=742&312=744&313=746&314=749&315=757&316=760&318=771&325=780&331=784&332=788&342=799&343=803&352=814&353=818'