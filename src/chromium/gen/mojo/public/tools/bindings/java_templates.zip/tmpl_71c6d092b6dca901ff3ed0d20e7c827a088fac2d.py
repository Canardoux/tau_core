from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_constant_def = l_0_enum_def = l_0_struct_def = l_0_declare_params = l_0_declare_request_params = l_0_declare_callback = l_0_run_callback = l_0_flags_for_method = l_0_flags = l_0_manager_class = l_0_manager_def = l_0_accept_body = l_0_interface_def = l_0_interface_internal_def = missing
    try:
        t_1 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_2 = environment.filters['interface_response_name']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'interface_response_name' found.")
    try:
        t_3 = environment.filters['java_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'java_type' found.")
    try:
        t_4 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_5 = environment.filters['method_ordinal_name']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'method_ordinal_name' found.")
    try:
        t_6 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    pass
    included_template = environment.get_template('constant_definition.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    l_0_constant_def = getattr(included_template, 'constant_def', missing)
    if l_0_constant_def is missing:
        l_0_constant_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'interface_definition.tmpl') does not export the requested name 'constant_def'", name='constant_def')
    context.vars['constant_def'] = l_0_constant_def
    context.exported_vars.discard('constant_def')
    yield '\n'
    included_template = environment.get_template('enum_definition.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 2 in 'interface_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    included_template = environment.get_template('data_types_definition.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    l_0_struct_def = getattr(included_template, 'struct_def', missing)
    if l_0_struct_def is missing:
        l_0_struct_def = undefined(f"the template {included_template.__name__!r} (imported on line 3 in 'interface_definition.tmpl') does not export the requested name 'struct_def'", name='struct_def')
    context.vars['struct_def'] = l_0_struct_def
    context.exported_vars.discard('struct_def')
    def macro(l_1_parameters, l_1_boxed):
        t_7 = []
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_boxed is missing:
            l_1_boxed = False
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            _loop_vars = {}
            pass
            t_7.extend((
                str(t_3(context, environment.getattr(l_2_param, 'kind'), l_1_boxed)),
                ' ',
                str(t_6(l_2_param)),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_7.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_7)
    context.exported_vars.add('declare_params')
    context.vars['declare_params'] = l_0_declare_params = Macro(environment, macro, 'declare_params', ('parameters', 'boxed'), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_method):
        t_8 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_8.extend((
            '\n',
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), environment.getattr(l_1_method, 'parameters'))),
        ))
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_8.append(
                    ', ',
                )
            t_8.extend((
                '\n',
                str(t_2(l_1_method)),
                ' callback',
            ))
        return concat(t_8)
    context.exported_vars.add('declare_request_params')
    context.vars['declare_request_params'] = l_0_declare_request_params = Macro(environment, macro, 'declare_request_params', ('method',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method):
        t_9 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_9.extend((
            'interface ',
            str(t_2(l_1_method)),
            ' {\n  public void call(',
        ))
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
            _loop_vars = {}
            pass
            t_9.extend((
                '\n      ',
                str(t_3(context, environment.getattr(l_2_param, 'kind'), False)),
                ' ',
                str(t_6(l_2_param)),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_9.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        t_9.append(
            ');\n}',
        )
        return concat(t_9)
    context.exported_vars.add('declare_callback')
    context.vars['declare_callback'] = l_0_declare_callback = Macro(environment, macro, 'declare_callback', ('method',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_parameters):
        t_10 = []
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        pass
        if l_1_parameters:
            pass
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                _loop_vars = {}
                pass
                t_10.extend((
                    str(l_1_variable),
                    '.',
                    str(t_6(l_2_param)),
                ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_10.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
        return concat(t_10)
    context.exported_vars.add('run_callback')
    context.vars['run_callback'] = l_0_run_callback = Macro(environment, macro, 'run_callback', ('variable', 'parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method, l_1_is_request):
        t_11 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_is_request is missing:
            l_1_is_request = undefined("parameter 'is_request' was not provided", name='is_request')
        pass
        t_11.append(
            str(context.call((undefined(name='flags') if l_0_flags is missing else l_0_flags), (environment.getattr(l_1_method, 'response_parameters') != None), l_1_is_request, environment.getattr(l_1_method, 'sync'))),
        )
        return concat(t_11)
    context.exported_vars.add('flags_for_method')
    context.vars['flags_for_method'] = l_0_flags_for_method = Macro(environment, macro, 'flags_for_method', ('method', 'is_request'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_use_response_flag, l_1_is_request, l_1_is_sync):
        t_12 = []
        if l_1_use_response_flag is missing:
            l_1_use_response_flag = undefined("parameter 'use_response_flag' was not provided", name='use_response_flag')
        if l_1_is_request is missing:
            l_1_is_request = undefined("parameter 'is_request' was not provided", name='is_request')
        if l_1_is_sync is missing:
            l_1_is_sync = undefined("parameter 'is_sync' was not provided", name='is_sync')
        pass
        if (not l_1_use_response_flag):
            pass
            t_12.append(
                'org.chromium.mojo.bindings.MessageHeader.NO_FLAG',
            )
        elif l_1_is_request:
            pass
            t_12.append(
                'org.chromium.mojo.bindings.MessageHeader.MESSAGE_EXPECTS_RESPONSE_FLAG',
            )
        else:
            pass
            t_12.append(
                'org.chromium.mojo.bindings.MessageHeader.MESSAGE_IS_RESPONSE_FLAG',
            )
            if l_1_is_sync:
                pass
                t_12.append(
                    '| org.chromium.mojo.bindings.MessageHeader.MESSAGE_IS_SYNC_FLAG',
                )
        return concat(t_12)
    context.exported_vars.add('flags')
    context.vars['flags'] = l_0_flags = Macro(environment, macro, 'flags', ('use_response_flag', 'is_request', 'is_sync'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface, l_1_fully_qualified):
        t_13 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        if l_1_fully_qualified is missing:
            l_1_fully_qualified = False
        pass
        if l_1_fully_qualified:
            pass
            t_13.append(
                'org.chromium.mojo.bindings.Interface.',
            )
        t_13.extend((
            'Manager<',
            str(t_6(l_1_interface)),
            ', ',
            str(t_6(l_1_interface)),
            '.Proxy>',
        ))
        return concat(t_13)
    context.exported_vars.add('manager_class')
    context.vars['manager_class'] = l_0_manager_class = Macro(environment, macro, 'manager_class', ('interface', 'fully_qualified'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface):
        t_14 = []
        l_1_namespace = resolve('namespace')
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        pass
        t_14.extend((
            'public static final ',
            str(context.call((undefined(name='manager_class') if l_0_manager_class is missing else l_0_manager_class), l_1_interface, True)),
            ' MANAGER =\n        new ',
            str(context.call((undefined(name='manager_class') if l_0_manager_class is missing else l_0_manager_class), l_1_interface, True)),
            '() {\n\n    @Override\n    public String getName() {\n        return "',
            str((undefined(name='namespace') if l_1_namespace is missing else l_1_namespace)),
            '.',
            str(environment.getattr(l_1_interface, 'name')),
            '";\n    }\n\n    @Override\n    public int getVersion() {\n      return ',
            str(environment.getattr(l_1_interface, 'version')),
            ';\n    }\n\n    @Override\n    public Proxy buildProxy(org.chromium.mojo.system.Core core,\n                            org.chromium.mojo.bindings.MessageReceiverWithResponder messageReceiver) {\n        return new Proxy(core, messageReceiver);\n    }\n\n    @Override\n    public Stub buildStub(org.chromium.mojo.system.Core core, ',
            str(t_6(l_1_interface)),
            ' impl) {\n        return new Stub(core, impl);\n    }\n\n    @Override\n    public ',
            str(t_6(l_1_interface)),
            '[] buildArray(int size) {\n      return new ',
            str(t_6(l_1_interface)),
            '[size];\n    }\n};',
        ))
        return concat(t_14)
    context.exported_vars.add('manager_def')
    context.vars['manager_def'] = l_0_manager_def = Macro(environment, macro, 'manager_def', ('interface',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface, l_1_with_response):
        t_15 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        if l_1_with_response is missing:
            l_1_with_response = undefined("parameter 'with_response' was not provided", name='with_response')
        pass
        t_15.extend((
            'try {\n    org.chromium.mojo.bindings.ServiceMessage messageWithHeader =\n            message.asServiceMessage();\n    org.chromium.mojo.bindings.MessageHeader header = messageWithHeader.getHeader();\n    int flags = ',
            str(context.call((undefined(name='flags') if l_0_flags is missing else l_0_flags), l_1_with_response, True)),
            ';\n    if (header.hasFlag(org.chromium.mojo.bindings.MessageHeader.MESSAGE_IS_SYNC_FLAG)) {\n        flags = flags | org.chromium.mojo.bindings.MessageHeader.MESSAGE_IS_SYNC_FLAG;\n    }\n    if (!header.validateHeader(flags)) {\n        return false;\n    }\n    switch(header.getType()) {\n',
        ))
        if l_1_with_response:
            pass
            t_15.extend((
                '\n        case org.chromium.mojo.bindings.interfacecontrol.InterfaceControlMessagesConstants.RUN_MESSAGE_ID:\n            return org.chromium.mojo.bindings.InterfaceControlMessagesHelper.handleRun(\n                    getCore(), ',
                str(t_6(l_1_interface)),
                '_Internal.MANAGER, messageWithHeader, receiver);\n',
            ))
        else:
            pass
            t_15.extend((
                '\n        case org.chromium.mojo.bindings.interfacecontrol.InterfaceControlMessagesConstants.RUN_OR_CLOSE_PIPE_MESSAGE_ID:\n            return org.chromium.mojo.bindings.InterfaceControlMessagesHelper.handleRunOrClosePipe(\n                    ',
                str(t_6(l_1_interface)),
                '_Internal.MANAGER, messageWithHeader);\n',
            ))
        t_15.append(
            '\n',
        )
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_request_struct = resolve('request_struct')
            l_2_response_struct = resolve('response_struct')
            _loop_vars = {}
            pass
            t_15.append(
                '\n',
            )
            if ((l_1_with_response and (environment.getattr(l_2_method, 'response_parameters') != None)) or ((not l_1_with_response) and (environment.getattr(l_2_method, 'response_parameters') == None))):
                pass
                t_15.append(
                    '\n',
                )
                l_2_request_struct = environment.getattr(l_2_method, 'param_struct')
                _loop_vars['request_struct'] = l_2_request_struct
                t_15.append(
                    '\n',
                )
                if l_1_with_response:
                    pass
                    t_15.append(
                        '\n',
                    )
                    l_2_response_struct = environment.getattr(l_2_method, 'response_param_struct')
                    _loop_vars['response_struct'] = l_2_response_struct
                    t_15.append(
                        '\n',
                    )
                t_15.extend((
                    '\n        case ',
                    str(t_5(l_2_method)),
                    ': {\n',
                ))
                if environment.getattr(l_2_method, 'parameters'):
                    pass
                    t_15.extend((
                        '\n            ',
                        str(t_6((undefined(name='request_struct') if l_2_request_struct is missing else l_2_request_struct))),
                        ' data =\n                    ',
                        str(t_6((undefined(name='request_struct') if l_2_request_struct is missing else l_2_request_struct))),
                        '.deserialize(messageWithHeader.getPayload());\n',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n            ',
                        str(t_6((undefined(name='request_struct') if l_2_request_struct is missing else l_2_request_struct))),
                        '.deserialize(messageWithHeader.getPayload());\n',
                    ))
                t_15.extend((
                    '\n            getImpl().',
                    str(t_6(l_2_method)),
                    '(',
                    str(context.call((undefined(name='run_callback') if l_0_run_callback is missing else l_0_run_callback), 'data', environment.getattr(l_2_method, 'parameters'), _loop_vars=_loop_vars)),
                ))
                if l_1_with_response:
                    pass
                    if environment.getattr(l_2_method, 'parameters'):
                        pass
                        t_15.append(
                            ', ',
                        )
                    t_15.extend((
                        'new ',
                        str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                        'ProxyToResponder(getCore(), receiver, header.getRequestId())',
                    ))
                t_15.append(
                    ');\n            return true;\n        }\n',
                )
            t_15.append(
                '\n',
            )
        l_2_method = l_2_request_struct = l_2_response_struct = missing
        t_15.append(
            '\n        default:\n            return false;\n    }\n} catch (org.chromium.mojo.bindings.DeserializationException e) {\n    System.err.println(e.toString());\n    return false;\n}',
        )
        return concat(t_15)
    context.exported_vars.add('accept_body')
    context.vars['accept_body'] = l_0_accept_body = Macro(environment, macro, 'accept_body', ('interface', 'with_response'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface):
        t_16 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        pass
        t_16.extend((
            '\npublic interface ',
            str(t_6(l_1_interface)),
            ' extends org.chromium.mojo.bindings.Interface {\n',
        ))
        for l_2_constant in environment.getattr(l_1_interface, 'constants'):
            _loop_vars = {}
            pass
            t_16.extend((
                '\n\n    ',
                str(t_1(context.call((undefined(name='constant_def') if l_0_constant_def is missing else l_0_constant_def), l_2_constant, _loop_vars=_loop_vars), 4)),
                '\n',
            ))
        l_2_constant = missing
        t_16.append(
            '\n',
        )
        for l_2_enum in environment.getattr(l_1_interface, 'enums'):
            _loop_vars = {}
            pass
            t_16.extend((
                '\n\n    ',
                str(t_1(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_2_enum, False, _loop_vars=_loop_vars), 4)),
                '\n',
            ))
        l_2_enum = missing
        t_16.extend((
            '\n\n    public interface Proxy extends ',
            str(t_6(l_1_interface)),
            ', org.chromium.mojo.bindings.Interface.Proxy {\n    }\n\n    ',
            str(context.call((undefined(name='manager_class') if l_0_manager_class is missing else l_0_manager_class), l_1_interface)),
            ' MANAGER = ',
            str(t_6(l_1_interface)),
            '_Internal.MANAGER;\n',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_16.extend((
                '\n    void ',
                str(t_6(l_2_method)),
                '(',
                str(context.call((undefined(name='declare_request_params') if l_0_declare_request_params is missing else l_0_declare_request_params), l_2_method, _loop_vars=_loop_vars)),
                ');\n',
            ))
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                t_16.extend((
                    '\n    ',
                    str(t_1(context.call((undefined(name='declare_callback') if l_0_declare_callback is missing else l_0_declare_callback), l_2_method, _loop_vars=_loop_vars), 4)),
                    '\n',
                ))
            t_16.append(
                '\n',
            )
        l_2_method = missing
        t_16.append(
            '\n}\n',
        )
        return concat(t_16)
    context.exported_vars.add('interface_def')
    context.vars['interface_def'] = l_0_interface_def = Macro(environment, macro, 'interface_def', ('interface',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n'
    def macro(l_1_interface):
        t_17 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        pass
        t_17.extend((
            '\nclass ',
            str(t_6(l_1_interface)),
            '_Internal {\n\n    ',
            str(t_1(context.call((undefined(name='manager_def') if l_0_manager_def is missing else l_0_manager_def), l_1_interface), 4)),
            '\n\n',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_17.extend((
                '\n    private static final int ',
                str(t_5(l_2_method)),
                ' = ',
                str(environment.getattr(l_2_method, 'ordinal')),
                ';\n',
            ))
        l_2_method = missing
        t_17.extend((
            '\n\n    static final class Proxy extends org.chromium.mojo.bindings.Interface.AbstractProxy implements ',
            str(t_6(l_1_interface)),
            '.Proxy {\n\n        Proxy(org.chromium.mojo.system.Core core,\n              org.chromium.mojo.bindings.MessageReceiverWithResponder messageReceiver) {\n            super(core, messageReceiver);\n        }\n',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_request_struct = missing
            _loop_vars = {}
            pass
            t_17.extend((
                '\n\n        @Override\n        public void ',
                str(t_6(l_2_method)),
                '(',
                str(context.call((undefined(name='declare_request_params') if l_0_declare_request_params is missing else l_0_declare_request_params), l_2_method, _loop_vars=_loop_vars)),
                ') {\n',
            ))
            l_2_request_struct = environment.getattr(l_2_method, 'param_struct')
            _loop_vars['request_struct'] = l_2_request_struct
            t_17.extend((
                '\n            ',
                str(t_6((undefined(name='request_struct') if l_2_request_struct is missing else l_2_request_struct))),
                ' _message = new ',
                str(t_6((undefined(name='request_struct') if l_2_request_struct is missing else l_2_request_struct))),
                '();\n',
            ))
            for l_3_param in environment.getattr(l_2_method, 'parameters'):
                _loop_vars = {}
                pass
                t_17.extend((
                    '\n            _message.',
                    str(t_6(l_3_param)),
                    ' = ',
                    str(t_6(l_3_param)),
                    ';\n',
                ))
            l_3_param = missing
            t_17.append(
                '\n',
            )
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                t_17.extend((
                    '\n            getProxyHandler().getMessageReceiver().acceptWithResponder(\n                    _message.serializeWithHeader(\n                            getProxyHandler().getCore(),\n                            new org.chromium.mojo.bindings.MessageHeader(\n                                    ',
                    str(t_5(l_2_method)),
                    ',\n                                    ',
                    str(context.call((undefined(name='flags_for_method') if l_0_flags_for_method is missing else l_0_flags_for_method), l_2_method, True, _loop_vars=_loop_vars)),
                    ',\n                                    0)),\n                    new ',
                    str(t_6(environment.getattr(l_2_method, 'response_param_struct'))),
                    'ForwardToCallback(callback));\n',
                ))
            else:
                pass
                t_17.extend((
                    '\n            getProxyHandler().getMessageReceiver().accept(\n                    _message.serializeWithHeader(\n                            getProxyHandler().getCore(),\n                            new org.chromium.mojo.bindings.MessageHeader(',
                    str(t_5(l_2_method)),
                    ')));\n',
                ))
            t_17.append(
                '\n        }\n',
            )
        l_2_method = l_2_request_struct = missing
        t_17.extend((
            '\n\n    }\n\n    static final class Stub extends org.chromium.mojo.bindings.Interface.Stub<',
            str(t_6(l_1_interface)),
            '> {\n\n        Stub(org.chromium.mojo.system.Core core, ',
            str(t_6(l_1_interface)),
            ' impl) {\n            super(core, impl);\n        }\n\n        @Override\n        public boolean accept(org.chromium.mojo.bindings.Message message) {\n            ',
            str(t_1(context.call((undefined(name='accept_body') if l_0_accept_body is missing else l_0_accept_body), l_1_interface, False), 12)),
            '\n        }\n\n        @Override\n        public boolean acceptWithResponder(org.chromium.mojo.bindings.Message message, org.chromium.mojo.bindings.MessageReceiver receiver) {\n            ',
            str(t_1(context.call((undefined(name='accept_body') if l_0_accept_body is missing else l_0_accept_body), l_1_interface, True), 12)),
            '\n        }\n    }\n',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            l_2_response_struct = resolve('response_struct')
            _loop_vars = {}
            pass
            t_17.extend((
                '\n\n    ',
                str(t_1(context.call((undefined(name='struct_def') if l_0_struct_def is missing else l_0_struct_def), environment.getattr(l_2_method, 'param_struct'), True, _loop_vars=_loop_vars), 4)),
                '\n',
            ))
            if (environment.getattr(l_2_method, 'response_parameters') != None):
                pass
                t_17.append(
                    '\n',
                )
                l_2_response_struct = environment.getattr(l_2_method, 'response_param_struct')
                _loop_vars['response_struct'] = l_2_response_struct
                t_17.extend((
                    '\n\n    ',
                    str(t_1(context.call((undefined(name='struct_def') if l_0_struct_def is missing else l_0_struct_def), (undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct), True, _loop_vars=_loop_vars), 4)),
                    '\n\n    static class ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    'ForwardToCallback extends org.chromium.mojo.bindings.SideEffectFreeCloseable\n            implements org.chromium.mojo.bindings.MessageReceiver {\n        private final ',
                    str(t_6(l_1_interface)),
                    '.',
                    str(t_2(l_2_method)),
                    ' mCallback;\n\n        ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    'ForwardToCallback(',
                    str(t_6(l_1_interface)),
                    '.',
                    str(t_2(l_2_method)),
                    ' callback) {\n            this.mCallback = callback;\n        }\n\n        @Override\n        public boolean accept(org.chromium.mojo.bindings.Message message) {\n            try {\n                org.chromium.mojo.bindings.ServiceMessage messageWithHeader =\n                        message.asServiceMessage();\n                org.chromium.mojo.bindings.MessageHeader header = messageWithHeader.getHeader();\n                if (!header.validateHeader(',
                    str(t_5(l_2_method)),
                    ',\n                                           ',
                    str(context.call((undefined(name='flags_for_method') if l_0_flags_for_method is missing else l_0_flags_for_method), l_2_method, False, _loop_vars=_loop_vars)),
                    ')) {\n                    return false;\n                }\n',
                ))
                if t_4(environment.getattr(l_2_method, 'response_parameters')):
                    pass
                    t_17.extend((
                        '\n                ',
                        str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                        ' response = ',
                        str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                        '.deserialize(messageWithHeader.getPayload());\n',
                    ))
                t_17.extend((
                    '\n                mCallback.call(',
                    str(context.call((undefined(name='run_callback') if l_0_run_callback is missing else l_0_run_callback), 'response', environment.getattr(l_2_method, 'response_parameters'), _loop_vars=_loop_vars)),
                    ');\n                return true;\n            } catch (org.chromium.mojo.bindings.DeserializationException e) {\n                return false;\n            }\n        }\n    }\n\n    static class ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    'ProxyToResponder implements ',
                    str(t_6(l_1_interface)),
                    '.',
                    str(t_2(l_2_method)),
                    ' {\n\n        private final org.chromium.mojo.system.Core mCore;\n        private final org.chromium.mojo.bindings.MessageReceiver mMessageReceiver;\n        private final long mRequestId;\n\n        ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    'ProxyToResponder(\n                org.chromium.mojo.system.Core core,\n                org.chromium.mojo.bindings.MessageReceiver messageReceiver,\n                long requestId) {\n            mCore = core;\n            mMessageReceiver = messageReceiver;\n            mRequestId = requestId;\n        }\n\n        @Override\n        public void call(',
                    str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), environment.getattr(l_2_method, 'response_parameters'), _loop_vars=_loop_vars)),
                    ') {\n            ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    ' _response = new ',
                    str(t_6((undefined(name='response_struct') if l_2_response_struct is missing else l_2_response_struct))),
                    '();\n',
                ))
                for l_3_param in environment.getattr(l_2_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    t_17.extend((
                        '\n            _response.',
                        str(t_6(l_3_param)),
                        ' = ',
                        str(t_6(l_3_param)),
                        ';\n',
                    ))
                l_3_param = missing
                t_17.extend((
                    '\n            org.chromium.mojo.bindings.ServiceMessage _message =\n                    _response.serializeWithHeader(\n                            mCore,\n                            new org.chromium.mojo.bindings.MessageHeader(\n                                    ',
                    str(t_5(l_2_method)),
                    ',\n                                    ',
                    str(context.call((undefined(name='flags_for_method') if l_0_flags_for_method is missing else l_0_flags_for_method), l_2_method, False, _loop_vars=_loop_vars)),
                    ',\n                                    mRequestId));\n            mMessageReceiver.accept(_message);\n        }\n    }\n',
                ))
            t_17.append(
                '\n',
            )
        l_2_method = l_2_response_struct = missing
        t_17.append(
            '\n\n}\n',
        )
        return concat(t_17)
    context.exported_vars.add('interface_internal_def')
    context.vars['interface_internal_def'] = l_0_interface_internal_def = Macro(environment, macro, 'interface_internal_def', ('interface',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=48&2=55&3=62&5=68&6=76&7=80&8=84&12=94&13=101&14=103&15=105&16=112&20=118&21=125&23=129&24=134&25=138&31=150&32=157&33=160&34=164&35=168&40=177&41=185&44=190&45=199&47=204&51=214&57=222&58=229&61=244&62=252&63=254&67=256&72=260&82=262&87=264&88=266&93=272&98=281&106=284&109=288&113=295&115=301&116=309&118=314&119=319&120=324&122=331&123=334&124=338&125=340&127=347&129=352&143=381&144=388&145=391&147=396&149=403&151=408&154=414&157=416&158=421&159=426&160=431&161=435&167=449&168=456&170=458&172=461&173=466&176=474&182=477&185=483&186=488&187=492&188=497&189=502&191=511&196=515&197=517&199=519&204=526&211=535&213=537&219=539&224=541&227=544&229=550&230=553&231=558&233=562&235=564&237=566&239=570&249=576&250=578&253=581&254=585&256=592&264=594&270=600&280=602&281=604&282=609&283=614&289=622&290=624'