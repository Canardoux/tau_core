from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'constants.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_main_entity = resolve('main_entity')
    l_0_constants = resolve('constants')
    l_0_constant_def = missing
    try:
        t_1 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    pass
    included_template = environment.get_template('constant_definition.tmpl', 'constants.java.tmpl')._get_default_module(context)
    l_0_constant_def = getattr(included_template, 'constant_def', missing)
    if l_0_constant_def is missing:
        l_0_constant_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'constants.java.tmpl') does not export the requested name 'constant_def'", name='constant_def')
    context.vars['constant_def'] = l_0_constant_def
    context.exported_vars.discard('constant_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'constants.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'constant_def': l_0_constant_def})):
        yield event
    yield '\n\npublic final class '
    yield str((undefined(name='main_entity') if l_0_main_entity is missing else l_0_main_entity))
    yield ' {\n'
    for l_1_constant in (undefined(name='constants') if l_0_constants is missing else l_0_constants):
        _loop_vars = {}
        pass
        yield '\n\n    '
        yield str(t_1(context.call((undefined(name='constant_def') if l_0_constant_def is missing else l_0_constant_def), l_1_constant, _loop_vars=_loop_vars), 4))
        yield '\n'
    l_1_constant = missing
    yield '\n\n    private '
    yield str((undefined(name='main_entity') if l_0_main_entity is missing else l_0_main_entity))
    yield '() {}\n\n}'

blocks = {}
debug_info = '1=20&2=27&4=31&5=33&7=37&10=41'