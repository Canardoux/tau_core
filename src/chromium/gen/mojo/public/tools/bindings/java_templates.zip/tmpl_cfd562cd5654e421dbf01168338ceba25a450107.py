from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'constant_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_constant_def = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['java_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'java_type' found.")
    try:
        t_3 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    pass
    def macro(l_1_constant):
        t_4 = []
        if l_1_constant is missing:
            l_1_constant = undefined("parameter 'constant' was not provided", name='constant')
        pass
        t_4.extend((
            '\npublic static final ',
            str(t_2(context, environment.getattr(l_1_constant, 'kind'))),
            ' ',
            str(t_3(l_1_constant)),
            ' = ',
            str(t_1(context, l_1_constant)),
            ';\n',
        ))
        return concat(t_4)
    context.exported_vars.add('constant_def')
    context.vars['constant_def'] = l_0_constant_def = Macro(environment, macro, 'constant_def', ('constant',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=30&2=37'