from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_internal.java.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_interface_internal_def = missing
    pass
    included_template = environment.get_template('interface_definition.tmpl', 'interface_internal.java.tmpl')._get_default_module(context)
    l_0_interface_internal_def = getattr(included_template, 'interface_internal_def', missing)
    if l_0_interface_internal_def is missing:
        l_0_interface_internal_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'interface_internal.java.tmpl') does not export the requested name 'interface_internal_def'", name='interface_internal_def')
    context.vars['interface_internal_def'] = l_0_interface_internal_def
    context.exported_vars.discard('interface_internal_def')
    yield '\n'
    template = environment.get_template('header.java.tmpl', 'interface_internal.java.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface_internal_def': l_0_interface_internal_def})):
        yield event
    yield '\n\n'
    yield str(context.call((undefined(name='interface_internal_def') if l_0_interface_internal_def is missing else l_0_interface_internal_def), (undefined(name='interface') if l_0_interface is missing else l_0_interface)))

blocks = {}
debug_info = '1=13&2=20&4=24'