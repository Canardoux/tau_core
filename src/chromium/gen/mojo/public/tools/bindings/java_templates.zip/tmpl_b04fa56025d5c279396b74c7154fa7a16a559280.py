from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['covers_continuous_range']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'covers_continuous_range' found.")
    try:
        t_2 = environment.filters['groupby']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'groupby' found.")
    try:
        t_3 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_4 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_enum, l_1_top_level):
        t_5 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        if l_1_top_level is missing:
            l_1_top_level = undefined("parameter 'top_level' was not provided", name='top_level')
        pass
        t_5.extend((
            'public ',
            str(('static ' if (not l_1_top_level) else cond_expr_undefined("the inline if-expression on line 2 in 'enum_definition.tmpl' evaluated to false and no else section was defined."))),
            'final class ',
            str(t_3(l_1_enum)),
            ' {\n    private static final boolean IS_EXTENSIBLE = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_5.append(
                'true',
            )
        else:
            pass
            t_5.append(
                'false',
            )
        t_5.append(
            ';\n    @IntDef({\n',
        )
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_enum, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n        ',
                str(t_3(l_1_enum)),
                '.',
                str(t_3(l_2_field)),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_5.append(
                    ',',
                )
        l_2_loop = l_2_field = missing
        t_5.append(
            '})\n    public @interface EnumType {}\n',
        )
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_5.extend((
                '\n    public static final int ',
                str(t_3(l_2_field)),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ';',
            ))
        l_2_field = missing
        if (not t_4(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_5.extend((
                '\n    public static final int MIN_VALUE = ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ';',
            ))
        if (not t_4(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_5.extend((
                '\n    public static final int MAX_VALUE = ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ';',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_5.extend((
                '\n    public static final int DEFAULT_VALUE = ',
                str(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
                ';',
            ))
        if t_1(l_1_enum):
            pass
            t_5.extend((
                '\n\n    public static boolean isKnownValue(int value) {\n        return value >= ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ' && value <= ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ';\n    }',
            ))
        else:
            pass
            t_5.append(
                '\n\n    public static boolean isKnownValue(int value) {',
            )
            if environment.getattr(l_1_enum, 'fields'):
                pass
                t_5.append(
                    '\n        switch (value) {',
                )
                for l_2_enum_field in t_2(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                    _loop_vars = {}
                    pass
                    t_5.extend((
                        '\n            case ',
                        str(environment.getitem(l_2_enum_field, 0)),
                        ':',
                    ))
                l_2_enum_field = missing
                t_5.append(
                    '\n                return true;\n        }',
                )
            t_5.append(
                '\n        return false;\n    }',
            )
        t_5.append(
            '\n\n    public static void validate(int value) {\n        if (IS_EXTENSIBLE || isKnownValue(value)) return;\n        throw new org.chromium.mojo.bindings.DeserializationException("Invalid enum value.");\n    }\n\n    public static int toKnownValue(int value) {',
        )
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_5.append(
                '\n      if (isKnownValue(value)) {\n        return value;\n      }\n      return DEFAULT_VALUE;',
            )
        else:
            pass
            t_5.append(
                '\n      return value;',
            )
        t_5.extend((
            '\n    }\n\n    private ',
            str(t_3(l_1_enum)),
            '() {}\n}',
        ))
        return concat(t_5)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum', 'top_level'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=36&2=45&3=50&5=64&6=69&7=73&11=82&12=87&14=93&15=97&17=100&18=104&20=107&21=111&24=114&27=118&32=128&34=133&35=138&50=151&60=163'