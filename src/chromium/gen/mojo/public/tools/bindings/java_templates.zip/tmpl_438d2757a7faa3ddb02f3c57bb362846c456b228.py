from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'data_types_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_constant_def = l_0_enum_def = l_0_array_element_size = l_0_encode = l_0_decode_nullable_value_packed_field = l_0_decode = l_0_struct_def = l_0_union_def = missing
    try:
        t_1 = environment.filters['array']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'array' found.")
    try:
        t_2 = environment.filters['array_expected_length']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'array_expected_length' found.")
    try:
        t_3 = environment.filters['decode_method']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'decode_method' found.")
    try:
        t_4 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_5 = environment.filters['encode_method']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'encode_method' found.")
    try:
        t_6 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_7 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_8 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_9 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_10 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_11 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_12 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_13 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_14 = environment.filters['is_pointer_array_kind']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_pointer_array_kind' found.")
    try:
        t_15 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_16 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_17 = environment.filters['is_union_array_kind']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_array_kind' found.")
    try:
        t_18 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_19 = environment.filters['java_class_for_enum']
    except KeyError:
        @internalcode
        def t_19(*unused):
            raise TemplateRuntimeError("No filter named 'java_class_for_enum' found.")
    try:
        t_20 = environment.filters['java_true_false']
    except KeyError:
        @internalcode
        def t_20(*unused):
            raise TemplateRuntimeError("No filter named 'java_true_false' found.")
    try:
        t_21 = environment.filters['java_type']
    except KeyError:
        @internalcode
        def t_21(*unused):
            raise TemplateRuntimeError("No filter named 'java_type' found.")
    try:
        t_22 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_22(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_23 = environment.filters['name']
    except KeyError:
        @internalcode
        def t_23(*unused):
            raise TemplateRuntimeError("No filter named 'name' found.")
    try:
        t_24 = environment.filters['new_array']
    except KeyError:
        @internalcode
        def t_24(*unused):
            raise TemplateRuntimeError("No filter named 'new_array' found.")
    try:
        t_25 = environment.filters['ucc']
    except KeyError:
        @internalcode
        def t_25(*unused):
            raise TemplateRuntimeError("No filter named 'ucc' found.")
    pass
    included_template = environment.get_template('constant_definition.tmpl', 'data_types_definition.tmpl')._get_default_module(context)
    l_0_constant_def = getattr(included_template, 'constant_def', missing)
    if l_0_constant_def is missing:
        l_0_constant_def = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'data_types_definition.tmpl') does not export the requested name 'constant_def'", name='constant_def')
    context.vars['constant_def'] = l_0_constant_def
    context.exported_vars.discard('constant_def')
    included_template = environment.get_template('enum_definition.tmpl', 'data_types_definition.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 2 in 'data_types_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    def macro(l_1_kind):
        t_26 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        if t_18(l_1_kind):
            pass
            t_26.append(
                '\norg.chromium.mojo.bindings.BindingsHelper.UNION_SIZE',
            )
        else:
            pass
            t_26.append(
                'org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE',
            )
        return concat(t_26)
    context.exported_vars.add('array_element_size')
    context.vars['array_element_size'] = l_0_array_element_size = Macro(environment, macro, 'array_element_size', ('kind',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_kind, l_1_offset, l_1_bit, l_1_level, l_1_check_for_null):
        t_27 = []
        l_1_sub_kind = resolve('sub_kind')
        l_1_encodePointer = resolve('encodePointer')
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_bit is missing:
            l_1_bit = undefined("parameter 'bit' was not provided", name='bit')
        if l_1_level is missing:
            l_1_level = 0
        if l_1_check_for_null is missing:
            l_1_check_for_null = True
        pass
        if (t_14(l_1_kind) or t_17(l_1_kind)):
            pass
            l_1_sub_kind = environment.getattr(l_1_kind, 'kind')
            if l_1_check_for_null:
                pass
                t_27.extend((
                    '\nif (',
                    str(l_1_variable),
                    ' == null) {\n    encoder',
                    str(l_1_level),
                    '.encodeNullPointer(',
                    str(l_1_offset),
                    ', ',
                    str(t_20(t_12(l_1_kind))),
                    ');\n} else {',
                ))
            else:
                pass
                t_27.append(
                    '\n{',
                )
            if t_14(l_1_kind):
                pass
                l_1_encodePointer = 'encodePointerArray'
            else:
                pass
                l_1_encodePointer = 'encodeUnionArray'
            t_27.extend((
                '\n    org.chromium.mojo.bindings.Encoder encoder',
                str((l_1_level + 1)),
                ' = encoder',
                str(l_1_level),
                '.',
                str((undefined(name='encodePointer') if l_1_encodePointer is missing else l_1_encodePointer)),
                '(',
                str(l_1_variable),
                '.length, ',
                str(l_1_offset),
                ', ',
                str(t_2(l_1_kind)),
                ');\n    for (int i',
                str(l_1_level),
                ' = 0; i',
                str(l_1_level),
                ' < ',
                str(l_1_variable),
                '.length; ++i',
                str(l_1_level),
                ') {\n        ',
                str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), str_join((l_1_variable, '[i', l_1_level, ']', )), (undefined(name='sub_kind') if l_1_sub_kind is missing else l_1_sub_kind), str_join(('org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + ', context.call((undefined(name='array_element_size') if l_0_array_element_size is missing else l_0_array_element_size), (undefined(name='sub_kind') if l_1_sub_kind is missing else l_1_sub_kind)), ' * i', l_1_level, )), 0, (l_1_level + 1)), 8)),
                '\n    }\n}',
            ))
        elif t_11(l_1_kind):
            pass
            t_27.extend((
                '\nif (',
                str(l_1_variable),
                ' == null) {\n    encoder',
                str(l_1_level),
                '.encodeNullPointer(',
                str(l_1_offset),
                ', ',
                str(t_20(t_12(l_1_kind))),
                ');\n} else {\n    org.chromium.mojo.bindings.Encoder encoder',
                str((l_1_level + 1)),
                ' = encoder',
                str(l_1_level),
                '.encoderForMap(',
                str(l_1_offset),
                ');\n    int size',
                str(l_1_level),
                ' = ',
                str(l_1_variable),
                '.size();\n    ',
                str(t_21(context, environment.getattr(l_1_kind, 'key_kind'))),
                '[] keys',
                str(l_1_level),
                ' = ',
                str(t_24(context, t_1(environment.getattr(l_1_kind, 'key_kind')), str_join(('size', l_1_level, )))),
                ';\n    ',
                str(t_21(context, environment.getattr(l_1_kind, 'value_kind'))),
                '[] values',
                str(l_1_level),
                ' = ',
                str(t_24(context, t_1(environment.getattr(l_1_kind, 'value_kind')), str_join(('size', l_1_level, )))),
                ';\n    int index',
                str(l_1_level),
                ' = 0;\n    for (java.util.Map.Entry<',
                str(t_21(context, environment.getattr(l_1_kind, 'key_kind'), True)),
                ', ',
                str(t_21(context, environment.getattr(l_1_kind, 'value_kind'), True)),
                '> entry',
                str(l_1_level),
                ' : ',
                str(l_1_variable),
                '.entrySet()) {\n        keys',
                str(l_1_level),
                '[index',
                str(l_1_level),
                '] = entry',
                str(l_1_level),
                '.getKey();\n        values',
                str(l_1_level),
                '[index',
                str(l_1_level),
                '] = entry',
                str(l_1_level),
                '.getValue();\n        ++index',
                str(l_1_level),
                ';\n    }\n    ',
                str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), str_join(('keys', l_1_level, )), t_1(environment.getattr(l_1_kind, 'key_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0, (l_1_level + 1), False), 4)),
                '\n    ',
                str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), str_join(('values', l_1_level, )), t_1(environment.getattr(l_1_kind, 'value_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE', 0, (l_1_level + 1), False), 4)),
                '\n}',
            ))
        else:
            pass
            t_27.extend((
                '\nencoder',
                str(l_1_level),
                '.',
                str(t_5(context, l_1_kind, l_1_variable, l_1_offset, l_1_bit)),
                ';',
            ))
        return concat(t_27)
    context.exported_vars.add('encode')
    context.vars['encode'] = l_0_encode = Macro(environment, macro, 'encode', ('variable', 'kind', 'offset', 'bit', 'level', 'check_for_null'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_original_field, l_1_has_value_pf, l_1_value_pf, l_1_level):
        t_28 = []
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_original_field is missing:
            l_1_original_field = undefined("parameter 'original_field' was not provided", name='original_field')
        if l_1_has_value_pf is missing:
            l_1_has_value_pf = undefined("parameter 'has_value_pf' was not provided", name='has_value_pf')
        if l_1_value_pf is missing:
            l_1_value_pf = undefined("parameter 'value_pf' was not provided", name='value_pf')
        if l_1_level is missing:
            l_1_level = 0
        pass
        t_28.extend((
            '\nif (decoder',
            str(l_1_level),
            '.',
            str(t_3(context, environment.getattr(environment.getattr(l_1_has_value_pf, 'field'), 'kind'), (8 + environment.getattr(l_1_has_value_pf, 'offset')), environment.getattr(l_1_has_value_pf, 'bit'))),
            ') {\n  ',
            str(l_1_variable),
            ' = new ',
            str(t_21(context, environment.getattr(l_1_original_field, 'kind'))),
            '(decoder',
            str(l_1_level),
            '.',
            str(t_3(context, environment.getattr(environment.getattr(l_1_value_pf, 'field'), 'kind'), (8 + environment.getattr(l_1_value_pf, 'offset')), environment.getattr(l_1_value_pf, 'bit'))),
            ');\n} else {\n  ',
            str(l_1_variable),
            ' = null;\n}',
        ))
        return concat(t_28)
    context.exported_vars.add('decode_nullable_value_packed_field')
    context.vars['decode_nullable_value_packed_field'] = l_0_decode_nullable_value_packed_field = Macro(environment, macro, 'decode_nullable_value_packed_field', ('variable', 'original_field', 'has_value_pf', 'value_pf', 'level'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_variable, l_1_kind, l_1_offset, l_1_bit, l_1_level):
        t_29 = []
        if l_1_variable is missing:
            l_1_variable = undefined("parameter 'variable' was not provided", name='variable')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_bit is missing:
            l_1_bit = undefined("parameter 'bit' was not provided", name='bit')
        if l_1_level is missing:
            l_1_level = 0
        pass
        if (((t_16(l_1_kind) or t_14(l_1_kind)) or t_17(l_1_kind)) or t_11(l_1_kind)):
            pass
            t_29.extend((
                '\norg.chromium.mojo.bindings.Decoder decoder',
                str((l_1_level + 1)),
                ' = decoder',
                str(l_1_level),
                '.readPointer(',
                str(l_1_offset),
                ', ',
                str(t_20(t_12(l_1_kind))),
                ');',
            ))
            if t_16(l_1_kind):
                pass
                t_29.extend((
                    '\n',
                    str(l_1_variable),
                    ' = ',
                    str(t_21(context, l_1_kind)),
                    '.decode(decoder',
                    str((l_1_level + 1)),
                    ');',
                ))
            else:
                pass
                if t_12(l_1_kind):
                    pass
                    t_29.extend((
                        '\nif (decoder',
                        str((l_1_level + 1)),
                        ' == null) {\n    ',
                        str(l_1_variable),
                        ' = null;\n} else {',
                    ))
                else:
                    pass
                    t_29.append(
                        '\n{',
                    )
                if t_11(l_1_kind):
                    pass
                    t_29.extend((
                        '\n    decoder',
                        str((l_1_level + 1)),
                        '.readDataHeaderForMap();\n    ',
                        str(t_21(context, environment.getattr(l_1_kind, 'key_kind'))),
                        '[] keys',
                        str(l_1_level),
                        ';\n    ',
                        str(t_21(context, environment.getattr(l_1_kind, 'value_kind'))),
                        '[] values',
                        str(l_1_level),
                        ';\n    {\n        ',
                        str(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), str_join(('keys', l_1_level, )), t_1(environment.getattr(l_1_kind, 'key_kind')), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0, (l_1_level + 1)), 8)),
                        '\n    }\n    {\n        ',
                        str(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), str_join(('values', l_1_level, )), t_1(environment.getattr(l_1_kind, 'value_kind'), str_join(('keys', l_1_level, '.length', ))), 'org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + org.chromium.mojo.bindings.BindingsHelper.POINTER_SIZE', 0, (l_1_level + 1)), 8)),
                        '\n    }\n    ',
                        str(l_1_variable),
                        ' = new java.util.HashMap<',
                        str(t_21(context, environment.getattr(l_1_kind, 'key_kind'), True)),
                        ', ',
                        str(t_21(context, environment.getattr(l_1_kind, 'value_kind'), True)),
                        '>();\n    for (int index',
                        str(l_1_level),
                        ' = 0; index',
                        str(l_1_level),
                        ' < keys',
                        str(l_1_level),
                        '.length; ++index',
                        str(l_1_level),
                        ') {\n        ',
                        str(l_1_variable),
                        '.put(keys',
                        str(l_1_level),
                        '[index',
                        str(l_1_level),
                        '],  values',
                        str(l_1_level),
                        '[index',
                        str(l_1_level),
                        ']);\n    }',
                    ))
                else:
                    pass
                    t_29.extend((
                        '\n    org.chromium.mojo.bindings.DataHeader si',
                        str((l_1_level + 1)),
                        ' = decoder',
                        str((l_1_level + 1)),
                        '.readDataHeaderForPointerArray(',
                        str(t_2(l_1_kind)),
                        ');\n    ',
                        str(l_1_variable),
                        ' = ',
                        str(t_24(context, l_1_kind, str_join(('si', (l_1_level + 1), '.elementsOrVersion', )))),
                        ';\n    for (int i',
                        str((l_1_level + 1)),
                        ' = 0; i',
                        str((l_1_level + 1)),
                        ' < si',
                        str((l_1_level + 1)),
                        '.elementsOrVersion; ++i',
                        str((l_1_level + 1)),
                        ') {\n        ',
                        str(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), str_join((l_1_variable, '[i', (l_1_level + 1), ']', )), environment.getattr(l_1_kind, 'kind'), str_join(('org.chromium.mojo.bindings.DataHeader.HEADER_SIZE + ', context.call((undefined(name='array_element_size') if l_0_array_element_size is missing else l_0_array_element_size), environment.getattr(l_1_kind, 'kind')), ' * i', (l_1_level + 1), )), 0, (l_1_level + 1)), 8)),
                        '\n    }',
                    ))
                t_29.append(
                    '\n}',
                )
        elif t_18(l_1_kind):
            pass
            t_29.extend((
                '\n',
                str(l_1_variable),
                ' = ',
                str(t_21(context, l_1_kind)),
                '.decode(decoder',
                str(l_1_level),
                ', ',
                str(l_1_offset),
                ');',
            ))
        else:
            pass
            t_29.extend((
                '\n',
                str(l_1_variable),
                ' = decoder',
                str(l_1_level),
                '.',
                str(t_3(context, l_1_kind, l_1_offset, l_1_bit)),
                ';',
            ))
            if (t_8(l_1_kind) and t_10(environment.getattr(l_1_kind, 'kind'))):
                pass
                if t_12(l_1_kind):
                    pass
                    t_29.extend((
                        '\nif (',
                        str(l_1_variable),
                        ' != null) {',
                    ))
                else:
                    pass
                    t_29.append(
                        '\n{',
                    )
                t_29.extend((
                    '\n    for (int i',
                    str((l_1_level + 1)),
                    ' = 0; i',
                    str((l_1_level + 1)),
                    ' < ',
                    str(l_1_variable),
                    '.length; ++i',
                    str((l_1_level + 1)),
                    ') {',
                ))
                if t_12(environment.getattr(l_1_kind, 'kind')):
                    pass
                    t_29.extend((
                        '\n        if (',
                        str(l_1_variable),
                        '[i',
                        str((l_1_level + 1)),
                        '] == null)\n          continue;',
                    ))
                t_29.extend((
                    '\n        ',
                    str(t_19(context, environment.getattr(l_1_kind, 'kind'))),
                    '.validate(',
                    str(l_1_variable),
                    '[i',
                    str((l_1_level + 1)),
                    ']);\n        ',
                    str(l_1_variable),
                    '[i',
                    str((l_1_level + 1)),
                    '] = ',
                    str(t_19(context, environment.getattr(l_1_kind, 'kind'))),
                    '.toKnownValue(',
                    str(l_1_variable),
                    '[i',
                    str((l_1_level + 1)),
                    ']);\n    }\n}',
                ))
            elif t_10(l_1_kind):
                pass
                t_29.extend((
                    '\n    ',
                    str(t_19(context, l_1_kind)),
                    '.validate(',
                    str(l_1_variable),
                    ');\n    ',
                    str(l_1_variable),
                    ' = ',
                    str(t_19(context, l_1_kind)),
                    '.toKnownValue(',
                    str(l_1_variable),
                    ');',
                ))
        return concat(t_29)
    context.exported_vars.add('decode')
    context.vars['decode'] = l_0_decode = Macro(environment, macro, 'decode', ('variable', 'kind', 'offset', 'bit', 'level'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct, l_1_inner_class):
        t_30 = []
        l_1_prev_ver = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        if l_1_inner_class is missing:
            l_1_inner_class = False
        pass
        t_30.extend((
            '\n',
            str(('static' if l_1_inner_class else 'public')),
            ' final class ',
            str(t_23(l_1_struct)),
            ' extends org.chromium.mojo.bindings.Struct {\n\n    private static final int STRUCT_SIZE = ',
            str(environment.getattr(environment.getitem(environment.getattr(l_1_struct, 'versions'), -1), 'num_bytes')),
            ';\n    private static final org.chromium.mojo.bindings.DataHeader[] VERSION_ARRAY = new org.chromium.mojo.bindings.DataHeader[] {',
        ))
        l_2_loop = missing
        for l_2_version, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'versions'), undefined):
            _loop_vars = {}
            pass
            t_30.extend((
                'new org.chromium.mojo.bindings.DataHeader(',
                str(environment.getattr(l_2_version, 'num_bytes')),
                ', ',
                str(environment.getattr(l_2_version, 'version')),
                ')',
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_30.append(
                    ',',
                )
        l_2_loop = l_2_version = missing
        t_30.extend((
            '};\n    private static final org.chromium.mojo.bindings.DataHeader DEFAULT_STRUCT_INFO = VERSION_ARRAY[',
            str((t_22(environment.getattr(l_1_struct, 'versions')) - 1)),
            '];',
        ))
        for l_2_constant in environment.getattr(l_1_struct, 'constants'):
            _loop_vars = {}
            pass
            t_30.extend((
                '\n\n    ',
                str(t_6(context.call((undefined(name='constant_def') if l_0_constant_def is missing else l_0_constant_def), l_2_constant, _loop_vars=_loop_vars), 4)),
            ))
        l_2_constant = missing
        for l_2_enum in environment.getattr(l_1_struct, 'enums'):
            _loop_vars = {}
            pass
            t_30.extend((
                '\n\n    ',
                str(t_6(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_2_enum, False, _loop_vars=_loop_vars), 4)),
            ))
        l_2_enum = missing
        if environment.getattr(l_1_struct, 'fields'):
            pass
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                _loop_vars = {}
                pass
                t_30.extend((
                    '\n    public ',
                    str(t_21(context, environment.getattr(l_2_field, 'kind'))),
                    ' ',
                    str(t_23(l_2_field)),
                    ';',
                ))
            l_2_field = missing
        t_30.extend((
            '\n\n    private ',
            str(t_23(l_1_struct)),
            '(int version) {\n        super(STRUCT_SIZE, version);',
        ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            _loop_vars = {}
            pass
            if environment.getattr(l_2_field, 'default'):
                pass
                t_30.extend((
                    '\n        this.',
                    str(t_23(l_2_field)),
                    ' = ',
                    str(t_4(context, l_2_field)),
                    ';',
                ))
            elif t_7(environment.getattr(l_2_field, 'kind')):
                pass
                t_30.extend((
                    '\n        this.',
                    str(t_23(l_2_field)),
                    ' = org.chromium.mojo.system.InvalidHandle.INSTANCE;',
                ))
        l_2_field = missing
        t_30.extend((
            '\n    }\n\n    public ',
            str(t_23(l_1_struct)),
            '() {\n        this(',
            str(environment.getattr(environment.getitem(environment.getattr(l_1_struct, 'versions'), -1), 'version')),
            ');\n    }\n\n    public static ',
            str(t_23(l_1_struct)),
            ' deserialize(org.chromium.mojo.bindings.Message message) {\n        return decode(new org.chromium.mojo.bindings.Decoder(message));\n    }\n\n    /**\n     * Similar to the method above, but deserializes from a |ByteBuffer| instance.\n     *\n     * @throws org.chromium.mojo.bindings.DeserializationException on deserialization failure.\n     */\n    public static ',
            str(t_23(l_1_struct)),
            ' deserialize(java.nio.ByteBuffer data) {\n        return deserialize(new org.chromium.mojo.bindings.Message(\n                data, new java.util.ArrayList<org.chromium.mojo.system.Handle>()));\n    }\n\n    @SuppressWarnings("unchecked")\n    public static ',
            str(t_23(l_1_struct)),
            ' decode(org.chromium.mojo.bindings.Decoder decoder0) {\n        if (decoder0 == null) {\n            return null;\n        }\n        decoder0.increaseStackDepth();\n        ',
            str(t_23(l_1_struct)),
            ' result;\n        try {\n            org.chromium.mojo.bindings.DataHeader mainDataHeader = decoder0.readAndValidateDataHeader(VERSION_ARRAY);\n            final int elementsOrVersion = mainDataHeader.elementsOrVersion;\n            result = new ',
            str(t_23(l_1_struct)),
            '(elementsOrVersion);',
        ))
        l_1_prev_ver = [0]
        for l_2_byte in environment.getattr(l_1_struct, 'bytes'):
            _loop_vars = {}
            pass
            for l_3_packed_field in environment.getattr(l_2_byte, 'packed_fields'):
                l_3__ = resolve('_')
                l_3_original_field = resolve('original_field')
                l_3_has_value_pf = resolve('has_value_pf')
                l_3_value_pf = resolve('value_pf')
                _loop_vars = {}
                pass
                if (environment.getattr(l_3_packed_field, 'min_version') != environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1)):
                    pass
                    if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
                        pass
                        t_30.append(
                            '\n            }',
                        )
                    l_3__ = context.call(environment.getattr((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), 'append'), environment.getattr(l_3_packed_field, 'min_version'), _loop_vars=_loop_vars)
                    _loop_vars['_'] = l_3__
                    if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
                        pass
                        t_30.extend((
                            '\n            if (elementsOrVersion >= ',
                            str(environment.getattr(l_3_packed_field, 'min_version')),
                            ') {',
                        ))
                if t_13(l_3_packed_field):
                    pass
                    if t_15(l_3_packed_field):
                        pass
                        l_3_original_field = environment.getattr(l_3_packed_field, 'original_field')
                        _loop_vars['original_field'] = l_3_original_field
                        l_3_has_value_pf = l_3_packed_field
                        _loop_vars['has_value_pf'] = l_3_has_value_pf
                        l_3_value_pf = environment.getattr(l_3_packed_field, 'linked_value_packed_field')
                        _loop_vars['value_pf'] = l_3_value_pf
                        t_30.extend((
                            '\n                {\n                    ',
                            str(t_6(context.call((undefined(name='decode_nullable_value_packed_field') if l_0_decode_nullable_value_packed_field is missing else l_0_decode_nullable_value_packed_field), str_join(('result.', t_23((undefined(name='original_field') if l_3_original_field is missing else l_3_original_field)), )), (undefined(name='original_field') if l_3_original_field is missing else l_3_original_field), (undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), (undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), _loop_vars=_loop_vars), 16)),
                            '\n                }',
                        ))
                else:
                    pass
                    t_30.extend((
                        '\n                {\n                    ',
                        str(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), str_join(('result.', t_23(environment.getattr(l_3_packed_field, 'field')), )), environment.getattr(environment.getattr(l_3_packed_field, 'field'), 'kind'), (8 + environment.getattr(l_3_packed_field, 'offset')), environment.getattr(l_3_packed_field, 'bit'), _loop_vars=_loop_vars), 16)),
                        '\n                }',
                    ))
            l_3_packed_field = l_3__ = l_3_original_field = l_3_has_value_pf = l_3_value_pf = missing
        l_2_byte = missing
        if (environment.getitem((undefined(name='prev_ver') if l_1_prev_ver is missing else l_1_prev_ver), -1) != 0):
            pass
            t_30.append(
                '\n            }',
            )
        t_30.append(
            '\n\n        } finally {\n            decoder0.decreaseStackDepth();\n        }\n        return result;\n    }\n\n    @SuppressWarnings("unchecked")\n    @Override\n    protected final void encode(org.chromium.mojo.bindings.Encoder encoder) {',
        )
        if (not environment.getattr(l_1_struct, 'bytes')):
            pass
            t_30.append(
                '\n        encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);',
            )
        else:
            pass
            t_30.append(
                '\n        org.chromium.mojo.bindings.Encoder encoder0 = encoder.getEncoderAtDataOffset(DEFAULT_STRUCT_INFO);',
            )
        for l_2_byte in environment.getattr(l_1_struct, 'bytes'):
            _loop_vars = {}
            pass
            for l_3_packed_field in environment.getattr(l_2_byte, 'packed_fields'):
                l_3_original_field = resolve('original_field')
                l_3_has_value_pf = resolve('has_value_pf')
                l_3_value_pf = resolve('value_pf')
                _loop_vars = {}
                pass
                if t_13(l_3_packed_field):
                    pass
                    if t_15(l_3_packed_field):
                        pass
                        l_3_original_field = environment.getattr(l_3_packed_field, 'original_field')
                        _loop_vars['original_field'] = l_3_original_field
                        l_3_has_value_pf = l_3_packed_field
                        _loop_vars['has_value_pf'] = l_3_has_value_pf
                        l_3_value_pf = environment.getattr(l_3_packed_field, 'linked_value_packed_field')
                        _loop_vars['value_pf'] = l_3_value_pf
                        t_30.extend((
                            '\n        final boolean ',
                            str(t_23(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field'))),
                            ' = this.',
                            str(t_23((undefined(name='original_field') if l_3_original_field is missing else l_3_original_field))),
                            ' != null;',
                        ))
                        if t_10(environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind')):
                            pass
                            t_30.extend((
                                '\n        final ',
                                str(t_21(context, environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind'))),
                                ' ',
                                str(t_23(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'))),
                                ' = ',
                                str(t_23(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field'))),
                                '\n            ? this.',
                                str(t_23((undefined(name='original_field') if l_3_original_field is missing else l_3_original_field))),
                                '\n            : ',
                                str(t_19(context, environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind'))),
                                '.MIN_VALUE;',
                            ))
                        elif t_9(environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind')):
                            pass
                            t_30.extend((
                                '\n        final ',
                                str(t_21(context, environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind'))),
                                ' ',
                                str(t_23(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'))),
                                ' = ',
                                str(t_23(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field'))),
                                '\n            ? this.',
                                str(t_23((undefined(name='original_field') if l_3_original_field is missing else l_3_original_field))),
                                '\n            : false;',
                            ))
                        else:
                            pass
                            t_30.extend((
                                '\n        final ',
                                str(t_21(context, environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind'))),
                                ' ',
                                str(t_23(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'))),
                                ' = ',
                                str(t_23(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field'))),
                                '\n            ? this.',
                                str(t_23((undefined(name='original_field') if l_3_original_field is missing else l_3_original_field))),
                                '\n            : 0;',
                            ))
                        t_30.extend((
                            '\n        ',
                            str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), t_23(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field')), environment.getattr(environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'field'), 'kind'), (8 + environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'offset')), environment.getattr((undefined(name='has_value_pf') if l_3_has_value_pf is missing else l_3_has_value_pf), 'bit'), _loop_vars=_loop_vars), 8)),
                            '\n        ',
                            str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), t_23(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field')), environment.getattr(environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'field'), 'kind'), (8 + environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'offset')), environment.getattr((undefined(name='value_pf') if l_3_value_pf is missing else l_3_value_pf), 'bit'), _loop_vars=_loop_vars), 8)),
                        ))
                else:
                    pass
                    t_30.extend((
                        '\n        ',
                        str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), str_join(('this.', t_23(environment.getattr(l_3_packed_field, 'field')), )), environment.getattr(environment.getattr(l_3_packed_field, 'field'), 'kind'), (8 + environment.getattr(l_3_packed_field, 'offset')), environment.getattr(l_3_packed_field, 'bit'), _loop_vars=_loop_vars), 8)),
                    ))
            l_3_packed_field = l_3_original_field = l_3_has_value_pf = l_3_value_pf = missing
        l_2_byte = missing
        t_30.append(
            '\n    }\n}',
        )
        return concat(t_30)
    context.exported_vars.add('struct_def')
    context.vars['struct_def'] = l_0_struct_def = Macro(environment, macro, 'struct_def', ('struct', 'inner_class'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_31 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_31.extend((
            '\npublic final class ',
            str(t_23(l_1_union)),
            ' extends org.chromium.mojo.bindings.Union {\n\n    public static final class Tag {',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_union, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_31.extend((
                '\n        public static final int ',
                str(t_25(l_2_field)),
                ' = ',
                str(environment.getattr(l_2_loop, 'index0')),
                ';',
            ))
        l_2_loop = l_2_field = missing
        t_31.append(
            '\n    };',
        )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_31.extend((
                '\n    private ',
                str(t_21(context, environment.getattr(l_2_field, 'kind'))),
                ' m',
                str(t_25(l_2_field)),
                ';',
            ))
        l_2_field = missing
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_31.extend((
                '\n\n    public void set',
                str(t_25(l_2_field)),
                '(',
                str(t_21(context, environment.getattr(l_2_field, 'kind'))),
                ' ',
                str(t_23(l_2_field)),
                ') {\n        this.mTag = Tag.',
                str(t_25(l_2_field)),
                ';\n        this.m',
                str(t_25(l_2_field)),
                ' = ',
                str(t_23(l_2_field)),
                ';\n    }\n\n    public ',
                str(t_21(context, environment.getattr(l_2_field, 'kind'))),
                ' get',
                str(t_25(l_2_field)),
                '() {\n        assert this.mTag == Tag.',
                str(t_25(l_2_field)),
                ';\n        return this.m',
                str(t_25(l_2_field)),
                ';\n    }',
            ))
        l_2_field = missing
        t_31.append(
            '\n\n\n    @Override\n    protected final void encode(org.chromium.mojo.bindings.Encoder encoder0, int offset) {\n        encoder0.encode(org.chromium.mojo.bindings.BindingsHelper.UNION_SIZE, offset);\n        encoder0.encode(this.mTag, offset + 4);\n        switch (mTag) {',
        )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_31.extend((
                '\n            case Tag.',
                str(t_25(l_2_field)),
                ': {',
            ))
            if t_18(environment.getattr(l_2_field, 'kind')):
                pass
                t_31.extend((
                    '\n                if (this.m',
                    str(t_25(l_2_field)),
                    ' == null) {\n                    encoder0.encodeNullPointer(offset + 8, ',
                    str(t_20(t_12(environment.getattr(l_2_field, 'kind')))),
                    ');\n                } else {\n                    encoder0.encoderForUnionPointer(offset + 8).encode(\n                        this.m',
                    str(t_25(l_2_field)),
                    ', 0, ',
                    str(t_20(t_12(environment.getattr(l_2_field, 'kind')))),
                    ');\n                }',
                ))
            else:
                pass
                t_31.extend((
                    '\n                ',
                    str(t_6(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), str_join(('this.m', t_25(l_2_field), )), environment.getattr(l_2_field, 'kind'), 'offset + 8', 0, _loop_vars=_loop_vars), 16)),
                ))
            t_31.append(
                '\n                break;\n            }',
            )
        l_2_field = missing
        t_31.extend((
            '\n            default: {\n                break;\n            }\n        }\n    }\n\n    public static ',
            str(t_23(l_1_union)),
            ' deserialize(org.chromium.mojo.bindings.Message message) {\n        return decode(new org.chromium.mojo.bindings.Decoder(message).decoderForSerializedUnion(), 0);\n    }\n\n    public static final ',
            str(t_23(l_1_union)),
            ' decode(org.chromium.mojo.bindings.Decoder decoder0, int offset) {\n        org.chromium.mojo.bindings.DataHeader dataHeader = decoder0.readDataHeaderForUnion(offset);\n        if (dataHeader.size == 0) {\n            return null;\n        }\n        ',
            str(t_23(l_1_union)),
            ' result = new ',
            str(t_23(l_1_union)),
            '();\n        switch (dataHeader.elementsOrVersion) {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_31.extend((
                '\n            case Tag.',
                str(t_25(l_2_field)),
                ': {',
            ))
            if t_18(environment.getattr(l_2_field, 'kind')):
                pass
                t_31.extend((
                    '\n                org.chromium.mojo.bindings.Decoder decoder1 = decoder0.readPointer(offset + org.chromium.mojo.bindings.DataHeader.HEADER_SIZE, ',
                    str(t_20(t_12(environment.getattr(l_2_field, 'kind')))),
                    ');\n                if (decoder1 != null) {\n                    result.m',
                    str(t_25(l_2_field)),
                    ' = ',
                    str(t_21(context, environment.getattr(l_2_field, 'kind'))),
                    '.decode(decoder1, 0);\n                }',
                ))
            else:
                pass
                t_31.extend((
                    '\n                ',
                    str(t_6(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), str_join(('result.m', t_25(l_2_field), )), environment.getattr(l_2_field, 'kind'), 'offset + org.chromium.mojo.bindings.DataHeader.HEADER_SIZE', 0, _loop_vars=_loop_vars), 16)),
                ))
            t_31.extend((
                '\n                result.mTag = Tag.',
                str(t_25(l_2_field)),
                ';\n                break;\n            }',
            ))
        l_2_field = missing
        t_31.append(
            '\n            default: {\n                break;\n            }\n        }\n        return result;\n    }\n}',
        )
        return concat(t_31)
    context.exported_vars.add('union_def')
    context.vars['union_def'] = l_0_union_def = Macro(environment, macro, 'union_def', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=162&2=168&4=174&5=179&12=192&13=209&14=211&15=212&16=216&17=218&22=230&23=232&25=235&27=238&28=250&29=258&32=261&33=265&34=267&36=273&37=279&38=283&39=289&40=295&41=297&42=305&43=311&44=317&46=319&47=321&50=328&54=336&55=351&56=355&58=363&62=369&63=382&67=386&68=395&69=399&71=408&72=412&73=414&78=422&79=426&80=428&81=432&83=436&86=438&88=440&89=446&90=454&93=469&94=475&95=479&96=487&101=493&102=497&104=510&105=517&106=519&107=523&111=533&112=542&113=546&116=553&117=559&120=570&121=574&122=578&127=588&128=598&130=602&132=606&133=611&136=624&137=627&139=632&141=635&143=640&145=643&147=645&148=650&152=658&154=661&155=664&156=668&157=673&158=677&163=683&164=685&167=687&176=689&182=691&187=693&191=695&193=698&194=699&195=702&196=709&197=711&200=716&201=718&202=722&205=725&206=727&207=729&208=731&209=733&211=737&216=744&221=749&234=757&239=767&240=770&241=776&242=778&243=780&244=782&245=784&246=788&247=793&248=797&249=803&250=805&251=808&252=812&253=818&256=825&257=831&260=836&261=838&264=844&273=854&274=861&277=865&278=870&282=879&283=884&286=890&288=895&289=901&290=903&293=907&294=911&295=913&305=920&306=925&307=928&308=932&309=934&312=936&315=945&326=953&330=955&335=957&337=962&338=967&339=970&340=974&342=976&345=985&347=989'