from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_enum = missing
    pass
    def macro(l_1_name, l_1_enum):
        t_1 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_1.extend((
            '#[derive(Clone, Copy, Debug, Eq, PartialEq, bytemuck::Pod, bytemuck::Zeroable)]\n#[repr(transparent)]\npub struct ',
            str(l_1_name),
            '(pub i32);\n\n// Alias for consistent naming, and in case the wrapper binding changes.\npub type ',
            str(l_1_name),
            '_Data = ',
            str(l_1_name),
            ';\n\nimpl ',
            str(l_1_name),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_1.extend((
                '\n    #[allow(non_upper_case_globals)]\n    pub const r#',
                str(environment.getattr(l_2_field, 'name')),
                ': Self = Self(',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ');',
            ))
        l_2_field = missing
        t_1.append(
            '\n\n    pub fn validate(\n        &self,\n    ) -> bindings::Result<()> {',
        )
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_1.append(
                '\n        Ok(())',
            )
        else:
            pass
            t_1.append(
                '\n        match *self {',
            )
            for l_2_field in environment.getattr(l_1_enum, 'fields'):
                _loop_vars = {}
                pass
                t_1.extend((
                    '\n            #[allow(unreachable_patterns)]\n            Self::r#',
                    str(environment.getattr(l_2_field, 'name')),
                    ' => Ok(()),',
                ))
            l_2_field = missing
            t_1.append(
                '\n            _ => Err(bindings::ValidationError::new(\n                bindings::ValidationErrorKind::UnknownEnumValue)),\n        }',
            )
        t_1.append(
            '\n    }\n}',
        )
        return concat(t_1)
    context.exported_vars.add('declare_enum')
    context.vars['declare_enum'] = l_0_declare_enum = Macro(environment, macro, 'declare_enum', ('name', 'enum'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=12&5=21&8=23&10=27&11=30&13=35&19=44&23=54&25=59'