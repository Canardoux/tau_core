from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_union = missing
    try:
        t_1 = environment.filters['rust_field_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'rust_field_type' found.")
    try:
        t_2 = environment.filters['to_upper_snake_case']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'to_upper_snake_case' found.")
    pass
    def macro(l_1_union):
        t_3 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_3.extend((
            '#[derive(Debug)]\npub enum ',
            str(environment.getattr(l_1_union, 'name')),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n    r#',
                str(environment.getattr(l_2_field, 'name')),
                '(',
                str(t_1(environment.getattr(l_2_field, 'kind'))),
                '),',
            ))
        l_2_field = missing
        t_3.extend((
            '\n}\n\n#[derive(Clone, Copy, Debug, bytemuck::Pod, bytemuck::Zeroable)]\n#[repr(C)]\npub struct ',
            str(environment.getattr(l_1_union, 'name')),
            '_Data {\n    size: u32,\n    tag: ',
            str(environment.getattr(l_1_union, 'name')),
            '_Tag,\n    inner: ',
            str(environment.getattr(l_1_union, 'name')),
            "_Inner,\n}\n\n// All unions have a predefined size in the wire format. Assert it's correct.\nstatic_assertions::const_assert_eq!(\n    bindings::data::UNION_DATA_SIZE,\n    std::mem::size_of::<",
            str(environment.getattr(l_1_union, 'name')),
            '_Data>()\n);\n\n#[derive(Clone, Copy, Debug, bytemuck::Pod, bytemuck::Zeroable)]\n#[repr(transparent)]\npub struct ',
            str(environment.getattr(l_1_union, 'name')),
            '_Tag(u32);\n\nimpl ',
            str(environment.getattr(l_1_union, 'name')),
            '_Tag {',
        ))
        l_2_loop = missing
        for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_union, 'fields'), undefined):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n    pub const r#',
                str(t_2(environment.getattr(l_2_field, 'name'))),
                ': Self = Self(',
                str(environment.getattr(l_2_loop, 'index0')),
                ');',
            ))
        l_2_loop = l_2_field = missing
        t_3.extend((
            '\n}\n\n#[derive(Clone, Copy, Debug, bytemuck::Pod, bytemuck::Zeroable)]\n#[repr(transparent)]\npub struct ',
            str(environment.getattr(l_1_union, 'name')),
            "_Inner(u64);\n\n// All unions have a predefined size in the wire format. Assert it's correct.\nstatic_assertions::const_assert_eq!(\n    bindings::data::UNION_INNER_SIZE,\n    std::mem::size_of::<",
            str(environment.getattr(l_1_union, 'name')),
            '_Inner>()\n);',
        ))
        return concat(t_3)
    context.exported_vars.add('declare_union')
    context.vars['declare_union'] = l_0_declare_union = Macro(environment, macro, 'declare_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=24&4=31&5=34&6=39&12=47&14=49&15=51&21=53&26=55&28=57&29=61&30=66&36=74&41=76'