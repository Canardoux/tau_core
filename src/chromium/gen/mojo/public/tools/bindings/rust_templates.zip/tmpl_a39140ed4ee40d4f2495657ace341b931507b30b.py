from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_enum = l_0_declare_struct = l_0_declare_interface = missing
    try:
        t_1 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_2 = environment.filters['to_lower_snake_case']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'to_lower_snake_case' found.")
    try:
        t_3 = environment.filters['to_upper_snake_case']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'to_upper_snake_case' found.")
    pass
    included_template = environment.get_template('enum.tmpl', 'interface.tmpl')._get_default_module(context)
    l_0_declare_enum = getattr(included_template, 'declare_enum', missing)
    if l_0_declare_enum is missing:
        l_0_declare_enum = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'interface.tmpl') does not export the requested name 'declare_enum'", name='declare_enum')
    context.vars['declare_enum'] = l_0_declare_enum
    context.exported_vars.discard('declare_enum')
    included_template = environment.get_template('struct.tmpl', 'interface.tmpl')._get_default_module(context)
    l_0_declare_struct = getattr(included_template, 'declare_struct', missing)
    if l_0_declare_struct is missing:
        l_0_declare_struct = undefined(f"the template {included_template.__name__!r} (imported on line 2 in 'interface.tmpl') does not export the requested name 'declare_struct'", name='declare_struct')
    context.vars['declare_struct'] = l_0_declare_struct
    context.exported_vars.discard('declare_struct')
    def macro(l_1_interface):
        t_4 = []
        l_1_internal_module = missing
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        pass
        l_1_internal_module = t_1('internal__%s', t_2(environment.getattr(l_1_interface, 'name')))
        t_4.extend((
            '/// Mojo interface ',
            str(environment.getattr(l_1_interface, 'name')),
            '\n///\n/// This does not have any functionality itself. It serves as a marker type to\n/// uniquely identify the interface in other mojo code.\n#[derive(Debug)]\npub struct ',
            str(environment.getattr(l_1_interface, 'name')),
            ';\n\nimpl bindings::mojom::Interface for ',
            str(environment.getattr(l_1_interface, 'name')),
            " {\n    fn get_method_info(name: u32) -> Option<&'static bindings::mojom::MethodInfo> {\n        match name {",
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n            ',
                str(environment.getattr(l_2_method, 'ordinal')),
                ' =>\n                Some(&',
                str((undefined(name='internal_module') if l_1_internal_module is missing else l_1_internal_module)),
                '::METHOD_INFO__',
                str(t_3(environment.getattr(l_2_method, 'name'))),
                '),',
            ))
        l_2_method = missing
        t_4.append(
            '\n            _ => None,\n        }\n    }\n}',
        )
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n',
                str(context.call((undefined(name='declare_struct') if l_0_declare_struct is missing else l_0_declare_struct), t_1('%s_%s_Req', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_method, 'name')), environment.getattr(l_2_method, 'param_struct'), _loop_vars=_loop_vars)),
            ))
            if environment.getattr(l_2_method, 'response_parameters'):
                pass
                t_4.extend((
                    '\n',
                    str(context.call((undefined(name='declare_struct') if l_0_declare_struct is missing else l_0_declare_struct), t_1('%s_%s_Resp', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_method, 'name')), environment.getattr(l_2_method, 'response_param_struct'), _loop_vars=_loop_vars)),
                ))
        l_2_method = missing
        for l_2_enum in environment.getattr(l_1_interface, 'enums'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n',
                str(context.call((undefined(name='declare_enum') if l_0_declare_enum is missing else l_0_declare_enum), t_1('%s_%s', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_enum, 'name')), l_2_enum, _loop_vars=_loop_vars)),
            ))
        l_2_enum = missing
        t_4.extend((
            '\n\npub mod ',
            str((undefined(name='internal_module') if l_1_internal_module is missing else l_1_internal_module)),
            ' {',
        ))
        for l_2_method in environment.getattr(l_1_interface, 'methods'):
            _loop_vars = {}
            pass
            t_4.extend((
                '\n    fn validate_request_',
                str(t_2(environment.getattr(l_2_method, 'name'))),
                "(\n        ctx: &'_ mut bindings::ValidationContext<'_, '_>,\n    ) -> bindings::Result<()> {\n        let chunk = ctx.claim_payload_root()?;\n        super::",
                str(t_1('%s_%s_Req_Data', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_method, 'name'))),
                '\n            ::validate(ctx, &chunk)\n    }',
            ))
            if environment.getattr(l_2_method, 'response_parameters'):
                pass
                t_4.extend((
                    '\n    fn validate_response_',
                    str(t_2(environment.getattr(l_2_method, 'name'))),
                    "(\n        ctx: &'_ mut bindings::ValidationContext<'_, '_>,\n    ) -> bindings::Result<()> {\n        let chunk = ctx.claim_payload_root()?;\n        super::",
                    str(t_1('%s_%s_Resp_Data', environment.getattr(l_1_interface, 'name'), environment.getattr(l_2_method, 'name'))),
                    '\n            ::validate(ctx, &chunk)\n    }',
                ))
            t_4.extend((
                '\n\n    pub static METHOD_INFO__',
                str(t_3(environment.getattr(l_2_method, 'name'))),
                '\n        : bindings::mojom::MethodInfo = bindings::mojom::MethodInfo {\n        validate_request: validate_request_',
                str(t_2(environment.getattr(l_2_method, 'name'))),
                ',',
            ))
            if environment.getattr(l_2_method, 'response_parameters'):
                pass
                t_4.extend((
                    '\n        validate_response: Some(validate_response_',
                    str(t_2(environment.getattr(l_2_method, 'name'))),
                    '),',
                ))
            else:
                pass
                t_4.append(
                    '\n        validate_response: None,',
                )
            t_4.append(
                '\n    };',
            )
        l_2_method = missing
        t_4.append(
            '\n}',
        )
        return concat(t_4)
    context.exported_vars.add('declare_interface')
    context.vars['declare_interface'] = l_0_declare_interface = Macro(environment, macro, 'declare_interface', ('interface',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=30&2=36&4=42&6=48&8=51&13=53&15=55&18=58&19=63&20=65&27=74&28=79&29=81&30=85&34=88&35=93&38=98&39=101&40=106&44=108&48=111&49=115&53=117&58=122&60=124&61=127&62=131'