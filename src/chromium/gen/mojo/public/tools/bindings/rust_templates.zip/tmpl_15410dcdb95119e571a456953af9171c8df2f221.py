from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_declare_enum = l_0_declare_struct = missing
    try:
        t_1 = environment.filters['get_packed_bool_location']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_packed_bool_location' found.")
    try:
        t_2 = environment.filters['get_rust_data_fields']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'get_rust_data_fields' found.")
    try:
        t_3 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_4 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_5 = environment.filters['is_pointer_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_pointer_kind' found.")
    try:
        t_6 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_7 = environment.filters['rust_field_type']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'rust_field_type' found.")
    try:
        t_8 = environment.filters['rust_referent_data_type']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'rust_referent_data_type' found.")
    pass
    included_template = environment.get_template('enum.tmpl', 'struct.tmpl')._get_default_module(context)
    l_0_declare_enum = getattr(included_template, 'declare_enum', missing)
    if l_0_declare_enum is missing:
        l_0_declare_enum = undefined(f"the template {included_template.__name__!r} (imported on line 1 in 'struct.tmpl') does not export the requested name 'declare_enum'", name='declare_enum')
    context.vars['declare_enum'] = l_0_declare_enum
    context.exported_vars.discard('declare_enum')
    def macro(l_1_name, l_1_struct):
        t_9 = []
        l_1_packed_fields = l_1_validate_child = missing
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        t_9.extend((
            '#[derive(Debug)]\npub struct ',
            str(l_1_name),
            ' {',
        ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            _loop_vars = {}
            pass
            t_9.extend((
                '\n    pub r#',
                str(environment.getattr(l_2_field, 'name')),
                ': ',
                str(t_7(environment.getattr(l_2_field, 'kind'))),
                ',',
            ))
        l_2_field = missing
        t_9.append(
            '\n}',
        )
        l_1_packed_fields = environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields')
        t_9.extend((
            '\n\n#[derive(Clone, Copy, Debug, bytemuck::Pod, bytemuck::Zeroable)]\n#[repr(C)]\npub struct ',
            str(l_1_name),
            '_Data {\n    pub _header: bindings::data::StructHeader,',
        ))
        for l_2_field in t_2(environment.getattr(l_1_struct, 'packed')):
            _loop_vars = {}
            pass
            t_9.extend((
                '\n    pub r#',
                str(environment.getattr(l_2_field, 'name')),
                ': ',
                str(environment.getattr(l_2_field, 'type')),
                ',',
            ))
        l_2_field = missing
        t_9.extend((
            "\n}\n\n// Ensure that the Rust type's size is the same as mojo's.\nstatic_assertions::assert_eq_size!(\n    [u8; ",
            str(environment.getattr(environment.getitem(environment.getattr(l_1_struct, 'versions'), -1), 'num_bytes')),
            '],\n    ',
            str(l_1_name),
            '_Data,\n);\n\nimpl ',
            str(l_1_name),
            "_Data {\n    const KNOWN_VERSION_SIZES: &'static [(u32, u32)] =\n        &[",
        ))
        for l_2_version in environment.getattr(l_1_struct, 'versions'):
            _loop_vars = {}
            pass
            t_9.extend((
                '(',
                str(environment.getattr(l_2_version, 'version')),
                ', ',
                str(environment.getattr(l_2_version, 'num_bytes')),
                '),',
            ))
        l_2_version = missing
        t_9.append(
            "];\n\n    pub fn validate(\n        #[allow(unused_variables)]\n        ctx: &'_ mut bindings::ValidationContext<'_, '_>,\n        chunk: &'_ bindings::MessageViewChunk<'_, '_, Self>,\n    ) -> bindings::Result<()> {\n        let data: Self = chunk.read();\n        assert_eq!(chunk.len(), data._header.size as usize);\n\n        // Ensure that the size and version match, or:\n        // * if the version is newer than any known version, the size is not\n        //   less than the last known version, or\n        // * if the version is between known versions, the size is between their\n        //   sizes (inclusive)\n        for (version, size) in Self::KNOWN_VERSION_SIZES.iter().copied() {\n            if data._header.version == version  {\n                if data._header.size != size {\n                    return Err(bindings::ValidationError::new(\n                        bindings::ValidationErrorKind::UnexpectedStructHeader));\n                }\n                break;\n            }\n\n            if data._header.version > version && data._header.size < size {\n                return Err(bindings::ValidationError::new(\n                    bindings::ValidationErrorKind::UnexpectedStructHeader));\n            }\n\n            if data._header.version < version && data._header.size > size {\n                return Err(bindings::ValidationError::new(\n                    bindings::ValidationErrorKind::UnexpectedStructHeader));\n            } else if data._header.version < version {\n                break;\n            }\n        }",
        )
        def macro(l_2_field_name, l_2_kind):
            t_10 = []
            if l_2_field_name is missing:
                l_2_field_name = undefined("parameter 'field_name' was not provided", name='field_name')
            if l_2_kind is missing:
                l_2_kind = undefined("parameter 'kind' was not provided", name='kind')
            pass
            if t_6(l_2_kind):
                pass
                t_10.extend((
                    '\n        if data.r#',
                    str(l_2_field_name),
                    '.offset != 0 {\n            let abs_ptr = bindings::AbsolutePointer::resolve_from(\n                &data.r#',
                    str(l_2_field_name),
                    ',\n                &data,\n                chunk,\n            )?;\n\n            let child_chunk = ctx.claim_struct(abs_ptr)?;\n            ',
                    str(t_8(l_2_kind)),
                    '\n                ::validate(ctx, &child_chunk)?;\n        }',
                ))
            elif t_3(l_2_kind):
                pass
                t_10.extend((
                    '\n        data.r#',
                    str(l_2_field_name),
                    '.validate()?;',
                ))
            return concat(t_10)
        l_1_validate_child = Macro(environment, macro, 'validate_child', ('field_name', 'kind'), False, False, False, context.eval_ctx.autoescape)
        for l_2_packed_field in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields'):
            l_2_orig_field = resolve('orig_field')
            l_2_value_field = resolve('value_field')
            l_2_flag_location = resolve('flag_location')
            l_2_kind = missing
            _loop_vars = {}
            pass
            l_2_kind = environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')
            _loop_vars['kind'] = l_2_kind
            if environment.getattr(l_2_packed_field, 'linked_value_packed_field'):
                pass
                l_2_orig_field = environment.getattr(l_2_packed_field, 'original_field')
                _loop_vars['orig_field'] = l_2_orig_field
                l_2_value_field = environment.getattr(l_2_packed_field, 'linked_value_packed_field')
                _loop_vars['value_field'] = l_2_value_field
                l_2_flag_location = t_1(l_2_packed_field)
                _loop_vars['flag_location'] = l_2_flag_location
                t_9.extend((
                    '// ',
                    str(environment.getattr((undefined(name='orig_field') if l_2_orig_field is missing else l_2_orig_field), 'name')),
                    ' is nullable and has an associated boolean flag.\n        if (data.r#',
                    str(environment.getattr((undefined(name='flag_location') if l_2_flag_location is missing else l_2_flag_location), 'field_name')),
                    '\n          & 1u8 << ',
                    str(environment.getattr((undefined(name='flag_location') if l_2_flag_location is missing else l_2_flag_location), 'bit_offset')),
                    ') > 0 {\n            ',
                    str(context.call((undefined(name='validate_child') if l_1_validate_child is missing else l_1_validate_child), environment.getattr((undefined(name='orig_field') if l_2_orig_field is missing else l_2_orig_field), 'name'), environment.getattr(environment.getattr((undefined(name='value_field') if l_2_value_field is missing else l_2_value_field), 'field'), 'kind'), _loop_vars=_loop_vars)),
                    '\n        }',
                ))
            elif environment.getattr(l_2_packed_field, 'original_field'):
                pass
            elif (t_5((undefined(name='kind') if l_2_kind is missing else l_2_kind)) and (not t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind)))):
                pass
                t_9.extend((
                    'if data.r#',
                    str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name')),
                    '.offset == 0 {\n            return Err(bindings::ValidationError::new(\n                bindings::ValidationErrorKind::UnexpectedNullPointer));\n        }\n\n        ',
                    str(context.call((undefined(name='validate_child') if l_1_validate_child is missing else l_1_validate_child), environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'), environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind'), _loop_vars=_loop_vars)),
                ))
            else:
                pass
                t_9.append(
                    str(context.call((undefined(name='validate_child') if l_1_validate_child is missing else l_1_validate_child), environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'), environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind'), _loop_vars=_loop_vars)),
                )
        l_2_packed_field = l_2_kind = l_2_orig_field = l_2_value_field = l_2_flag_location = missing
        t_9.append(
            '\n\n        Ok(())\n    }\n}',
        )
        for l_2_enum in environment.getattr(l_1_struct, 'enums'):
            _loop_vars = {}
            pass
            t_9.extend((
                '\n',
                str(context.call((undefined(name='declare_enum') if l_0_declare_enum is missing else l_0_declare_enum), ((l_1_name + '_') + environment.getattr(l_2_enum, 'name')), l_2_enum, _loop_vars=_loop_vars)),
            ))
        l_2_enum = missing
        return concat(t_9)
    context.exported_vars.add('declare_struct')
    context.vars['declare_struct'] = l_0_declare_struct = Macro(environment, macro, 'declare_struct', ('name', 'struct'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=60&3=66&6=76&7=79&8=84&12=93&16=96&18=99&19=104&25=112&26=114&29=116&32=119&33=124&72=133&73=140&74=144&76=146&82=148&85=151&86=155&90=160&91=167&92=169&96=171&97=173&98=175&99=179&100=181&101=183&102=185&104=188&106=190&107=194&112=196&114=201&122=207&123=212'