from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/mojom-lite.js.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_for_bindings_internals = resolve('for_bindings_internals')
    l_0_generate_closure_exports = resolve('generate_closure_exports')
    l_0_interfaces = resolve('interfaces')
    l_0_module = resolve('module')
    try:
        t_1 = environment.filters['lite_js_import_name']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'lite_js_import_name' found.")
    try:
        t_2 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    pass
    if (not (undefined(name='for_bindings_internals') if l_0_for_bindings_internals is missing else l_0_for_bindings_internals)):
        pass
        yield "// Copyright 2018 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n/**\n * @fileoverview\n * @suppress {missingRequire}\n */\n'use strict';"
    yield '\n\n'
    if (undefined(name='generate_closure_exports') if l_0_generate_closure_exports is missing else l_0_generate_closure_exports):
        pass
        yield "goog.require('mojo.internal');"
        if (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
            pass
            yield "\ngoog.require('mojo.internal.interfaceSupport');"
        yield '\n'
        for l_1_kind in t_2(environment, context.call(environment.getattr(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'imported_kinds'), 'values'))):
            _loop_vars = {}
            pass
            yield "\ngoog.require('"
            yield str(t_1(l_1_kind))
            yield "');"
        l_1_kind = missing
        yield '\n'
    elif (not (undefined(name='for_bindings_internals') if l_0_for_bindings_internals is missing else l_0_for_bindings_internals)):
        pass
        yield "\nmojo.internal.exportModule('"
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield "');\n"
    yield '\n\n'
    template = environment.get_template('lite/module_definition.tmpl', 'lite/mojom-lite.js.tmpl')
    for event in template.root_render_func(template.new_context(context.get_all(), True, {})):
        yield event

blocks = {}
debug_info = '3=27&14=31&16=34&19=38&20=42&22=46&23=49&26=52'