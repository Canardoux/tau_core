from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'fuzzing.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_get_handle_deps = l_0_set_handles = l_0_build_call = l_0_generate_or_mutate_enum = l_0_generate_or_mutate_array = l_0_generate_or_mutate_map = l_0_generate_or_mutate_primitive = l_0_generate_or_mutate_interface = l_0_generate_or_mutate = missing
    try:
        t_1 = environment.filters['fuzz_handle_name']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'fuzz_handle_name' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_4 = environment.filters['is_any_interface_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_interface_kind' found.")
    try:
        t_5 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_6 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_7 = environment.filters['is_interface_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_interface_kind' found.")
    try:
        t_8 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_9 = environment.filters['is_pending_associated_receiver_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_associated_receiver_kind' found.")
    try:
        t_10 = environment.filters['is_pending_associated_remote_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_associated_remote_kind' found.")
    try:
        t_11 = environment.filters['is_pending_receiver_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_receiver_kind' found.")
    try:
        t_12 = environment.filters['is_pending_remote_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_remote_kind' found.")
    try:
        t_13 = environment.filters['is_primitive_kind']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'is_primitive_kind' found.")
    try:
        t_14 = environment.filters['is_reference_kind']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'is_reference_kind' found.")
    try:
        t_15 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_16 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_17 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_18 = environment.filters['primitive_to_fuzz_type']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'primitive_to_fuzz_type' found.")
    try:
        t_19 = environment.filters['to_js_boolean']
    except KeyError:
        @internalcode
        def t_19(*unused):
            raise TemplateRuntimeError("No filter named 'to_js_boolean' found.")
    try:
        t_20 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_20(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_kind, l_1_name):
        t_21 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_15(l_1_kind) or t_16(l_1_kind)):
            pass
            t_21.extend((
                str(l_1_name),
                '.getHandleDeps()',
            ))
        elif t_5(l_1_kind):
            pass
            t_21.extend((
                '[].concat.apply([], ',
                str(l_1_name),
                '.map(function(val) {\n  if (val) {\n    return ',
                str(t_2(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_kind, 'kind'), 'val'), 4)),
                ';\n  }\n  return [];\n}))',
            ))
        elif t_8(l_1_kind):
            pass
            t_21.extend((
                '[].concat.apply([], Array.from(',
                str(l_1_name),
                '.values()).map(function(val) {\n  if (val) {\n    return ',
                str(t_2(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_kind, 'value_kind'), 'val'), 4)),
                ';\n  }\n  return [];\n}))',
            ))
        elif t_3(l_1_kind):
            pass
            t_21.extend((
                '["',
                str(t_1(l_1_kind)),
                '"]',
            ))
        else:
            pass
            t_21.append(
                '[]',
            )
        return concat(t_21)
    context.exported_vars.add('get_handle_deps')
    context.vars['get_handle_deps'] = l_0_get_handle_deps = Macro(environment, macro, 'get_handle_deps', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_kind, l_1_name):
        t_22 = []
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (t_15(l_1_kind) or t_16(l_1_kind)):
            pass
            t_22.extend((
                'idx = ',
                str(l_1_name),
                '.setHandlesInternal_(handles, idx)',
            ))
        elif t_5(l_1_kind):
            pass
            t_22.extend((
                str(l_1_name),
                '.forEach(function(val) {\n  ',
                str(t_2(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_kind, 'kind'), 'val'), 2)),
                ';\n})',
            ))
        elif t_8(l_1_kind):
            pass
            t_22.extend((
                str(l_1_name),
                '.forEach(function(val) {\n  ',
                str(t_2(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_kind, 'value_kind'), 'val'), 2)),
                ';\n})',
            ))
        elif t_3(l_1_kind):
            pass
            t_22.extend((
                str(l_1_name),
                ' = handles[idx++];',
            ))
        return concat(t_22)
    context.exported_vars.add('set_handles')
    context.vars['set_handles'] = l_0_set_handles = Macro(environment, macro, 'set_handles', ('kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_type, l_1_name, l_1_varargs):
        t_23 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if l_1_name:
            pass
            t_23.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                str(l_1_type),
                '(',
                str(t_17(context.eval_ctx, ((l_1_name,) + l_1_varargs), ', ')),
                ')',
            ))
        else:
            pass
            t_23.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                str(l_1_type),
                '(',
                str(t_17(context.eval_ctx, l_1_varargs, ', ')),
                ')',
            ))
        return concat(t_23)
    context.exported_vars.add('build_call')
    context.vars['build_call'] = l_0_build_call = Macro(environment, macro, 'build_call', ('obj', 'operation', 'type', 'name'), False, True, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_24 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (not t_20(environment.getattr(l_1_kind, 'max_value'))):
            pass
            t_24.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Enum', l_1_name, '0', environment.getattr(l_1_kind, 'max_value'))),
            )
        else:
            pass
            t_24.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Enum', l_1_name)),
            )
        return concat(t_24)
    context.exported_vars.add('generate_or_mutate_enum')
    context.vars['generate_or_mutate_enum'] = l_0_generate_or_mutate_enum = Macro(environment, macro, 'generate_or_mutate_enum', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_25 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (l_1_operation == 'mutate'):
            pass
            t_25.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                'Array(',
                str(l_1_name),
                ', function(val) {\n  return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'kind'), 'val'), 2)),
                ';\n})',
            ))
        else:
            pass
            t_25.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                'Array(function() {\n  return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'kind')), 2)),
                ';\n})',
            ))
        return concat(t_25)
    context.exported_vars.add('generate_or_mutate_array')
    context.vars['generate_or_mutate_array'] = l_0_generate_or_mutate_array = Macro(environment, macro, 'generate_or_mutate_array', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_26 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (l_1_operation == 'mutate'):
            pass
            t_26.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                'Map(',
                str(l_1_name),
                ',\n  function(val) {\n    return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'key_kind'), 'val'), 4)),
                ';\n  },\n  function(val) {\n    return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'value_kind'), 'val'), 4)),
                ';\n  })',
            ))
        else:
            pass
            t_26.extend((
                str(l_1_obj),
                '.',
                str(l_1_operation),
                'Map(\n  function() {\n    return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'key_kind')), 4)),
                ';\n  },\n  function() {\n    return ',
                str(t_2(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), l_1_obj, l_1_operation, environment.getattr(l_1_kind, 'value_kind')), 4)),
                ';\n  })',
            ))
        return concat(t_26)
    context.exported_vars.add('generate_or_mutate_map')
    context.vars['generate_or_mutate_map'] = l_0_generate_or_mutate_map = Macro(environment, macro, 'generate_or_mutate_map', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_27 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_14(l_1_kind):
            pass
            t_27.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, t_18(l_1_kind), l_1_name, t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        else:
            pass
            t_27.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, t_18(l_1_kind), l_1_name)),
            )
        return concat(t_27)
    context.exported_vars.add('generate_or_mutate_primitive')
    context.vars['generate_or_mutate_primitive'] = l_0_generate_or_mutate_primitive = Macro(environment, macro, 'generate_or_mutate_primitive', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_28 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_11(l_1_kind):
            pass
            t_28.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'InterfaceRequest', l_1_name, str_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_7(l_1_kind):
            pass
            t_28.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Interface', l_1_name, str_join(('"', environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), '"', )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_12(l_1_kind):
            pass
            t_28.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Interface', l_1_name, str_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_9(l_1_kind):
            pass
            t_28.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'AssociatedInterfaceRequest', l_1_name, str_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_10(l_1_kind):
            pass
            t_28.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'AssociatedInterface', l_1_name, str_join(('"', environment.getattr(environment.getattr(environment.getattr(l_1_kind, 'kind'), 'module'), 'namespace'), '.', environment.getattr(environment.getattr(l_1_kind, 'kind'), 'name'), '"', )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        return concat(t_28)
    context.exported_vars.add('generate_or_mutate_interface')
    context.vars['generate_or_mutate_interface'] = l_0_generate_or_mutate_interface = Macro(environment, macro, 'generate_or_mutate_interface', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_obj, l_1_operation, l_1_kind, l_1_name):
        t_29 = []
        if l_1_obj is missing:
            l_1_obj = undefined("parameter 'obj' was not provided", name='obj')
        if l_1_operation is missing:
            l_1_operation = undefined("parameter 'operation' was not provided", name='operation')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = ''
        pass
        if t_13(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='generate_or_mutate_primitive') if l_0_generate_or_mutate_primitive is missing else l_0_generate_or_mutate_primitive), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_4(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='generate_or_mutate_interface') if l_0_generate_or_mutate_interface is missing else l_0_generate_or_mutate_interface), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_6(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='generate_or_mutate_enum') if l_0_generate_or_mutate_enum is missing else l_0_generate_or_mutate_enum), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_15(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Struct', l_1_name, str_join((environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_16(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='build_call') if l_0_build_call is missing else l_0_build_call), l_1_obj, l_1_operation, 'Union', l_1_name, str_join((environment.getattr(environment.getattr(l_1_kind, 'module'), 'namespace'), '.', environment.getattr(l_1_kind, 'name'), )), t_19(environment.getattr(l_1_kind, 'is_nullable')))),
            )
        elif t_5(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='generate_or_mutate_array') if l_0_generate_or_mutate_array is missing else l_0_generate_or_mutate_array), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        elif t_8(l_1_kind):
            pass
            t_29.append(
                str(context.call((undefined(name='generate_or_mutate_map') if l_0_generate_or_mutate_map is missing else l_0_generate_or_mutate_map), l_1_obj, l_1_operation, l_1_kind, l_1_name)),
            )
        return concat(t_29)
    context.exported_vars.add('generate_or_mutate')
    context.vars['generate_or_mutate'] = l_0_generate_or_mutate = Macro(environment, macro, 'generate_or_mutate', ('obj', 'operation', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=132&2=139&3=142&4=145&5=149&7=151&11=154&12=158&14=160&18=163&19=167&25=178&26=185&27=189&28=192&29=195&30=197&32=200&33=203&34=205&36=208&37=211&41=217&42=228&43=231&45=242&49=253&50=264&51=267&53=272&57=277&58=288&59=291&60=297&63=303&64=307&69=313&70=324&71=327&73=333&76=335&79=341&81=345&84=347&89=353&90=364&91=367&93=372&97=377&98=388&99=391&100=393&101=396&102=398&103=401&104=403&105=406&106=408&107=411&111=416&112=427&113=430&114=432&115=435&116=437&117=440&118=442&119=445&120=447&121=450&122=452&123=455&124=457&125=460'