from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_module = resolve('module')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['expression_to_text']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'expression_to_text' found.")
    try:
        t_2 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_3 = environment.filters['has_callbacks']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'has_callbacks' found.")
    try:
        t_4 = environment.filters['join']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'join' found.")
    try:
        t_5 = environment.filters['map']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'map' found.")
    try:
        t_6 = environment.filters['method_passes_associated_kinds']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'method_passes_associated_kinds' found.")
    try:
        t_7 = environment.filters['sanitize_identifier']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'sanitize_identifier' found.")
    pass
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_method_id = missing
        _loop_vars = {}
        pass
        l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_method_id'] = l_1_interface_method_id
        yield '\n  var k'
        yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
        yield '_Name = '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ';'
    l_1_method = l_1_interface_method_id = missing
    yield '\n\n  function '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr(handleOrPtrInfo) {\n    this.ptr = new bindings.InterfacePtrController('
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ',\n                                                   handleOrPtrInfo);\n  }\n\n  function '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr(associatedInterfacePtrInfo) {\n    this.ptr = new associatedBindings.AssociatedInterfacePtrController(\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ', associatedInterfacePtrInfo);\n  }\n\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr.prototype =\n      Object.create('
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr.prototype);\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr.prototype.constructor =\n      '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'AssociatedPtr;\n\n  function '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy(receiver) {\n    this.receiver_ = receiver;\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        _loop_vars = {}
        pass
        l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_method_id'] = l_1_interface_method_id
        yield '\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Ptr.prototype.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' = function() {\n    return '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '\n        .apply(this.ptr.getProxy(), arguments);\n  };\n\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' = function('
        l_2_loop = missing
        for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield str(t_7(environment.getattr(l_2_parameter, 'name')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_parameter = missing
        yield ') {\n    var params_ = new '
        yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
        yield '_Params();'
        for l_2_parameter in environment.getattr(l_1_method, 'parameters'):
            _loop_vars = {}
            pass
            yield '\n    params_.'
            yield str(environment.getattr(l_2_parameter, 'name'))
            yield ' = '
            yield str(t_7(environment.getattr(l_2_parameter, 'name')))
            yield ';'
        l_2_parameter = missing
        if (environment.getattr(l_1_method, 'response_parameters') == None):
            pass
            if t_6(l_1_method):
                pass
                yield '\n    var builder = new codec.MessageV2Builder(\n        k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n        codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize));\n    builder.setPayload('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            else:
                pass
                yield '\n    var builder = new codec.MessageV0Builder(\n        k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n        codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize));\n    builder.encodeStruct('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            yield '\n    var message = builder.finish();\n    this.receiver_.accept(message);'
        else:
            pass
            yield '\n    return new Promise(function(resolve, reject) {'
            if t_6(l_1_method):
                pass
                yield '\n      var builder = new codec.MessageV2Builder(\n          k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n          codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize),\n          codec.kMessageExpectsResponse, 0);\n      builder.setPayload('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            else:
                pass
                yield '\n      var builder = new codec.MessageV1Builder(\n          k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n          codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params.encodedSize),\n          codec.kMessageExpectsResponse, 0);\n      builder.encodeStruct('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params, params_);'
            yield '\n      var message = builder.finish();\n      this.receiver_.acceptAndExpectResponse(message).then(function(message) {\n        var reader = new codec.MessageReader(message);\n        var responseParams =\n            reader.decodeStruct('
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_ResponseParams);\n        resolve(responseParams);\n      }).catch(function(result) {\n        reject(Error("Connection error: " + result));\n      });\n    }.bind(this));'
        yield '\n  };'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n\n  function '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub(delegate) {\n    this.delegate_ = delegate;\n  }'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Stub.prototype.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' = function('
        yield str(t_4(context.eval_ctx, t_5(context, t_5(context, environment.getattr(l_1_method, 'parameters'), attribute='name'), 'sanitize_identifier'), ', '))
        yield ') {\n    return this.delegate_ && this.delegate_.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' && this.delegate_.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        yield str(t_4(context.eval_ctx, t_5(context, t_5(context, environment.getattr(l_1_method, 'parameters'), attribute='name'), 'sanitize_identifier'), ', '))
        yield ');\n  }'
    l_1_method = missing
    yield '\n\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.accept = function(message) {\n    var reader = new codec.MessageReader(message);\n    switch (reader.messageName) {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        _loop_vars = {}
        pass
        l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_method_id'] = l_1_interface_method_id
        if (environment.getattr(l_1_method, 'response_parameters') == None):
            pass
            yield '\n    case k'
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:\n      var params = reader.decodeStruct('
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params);\n      this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                _loop_vars = {}
                pass
                yield 'params.'
                yield str(environment.getattr(l_2_parameter, 'name'))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_parameter = missing
            yield ');\n      return true;'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n    default:\n      return false;\n    }\n  };\n\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.acceptWithResponder =\n      function(message, responder) {\n    var reader = new codec.MessageReader(message);\n    switch (reader.messageName) {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_method_id = missing
        _loop_vars = {}
        pass
        l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_method_id'] = l_1_interface_method_id
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n    case k'
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:\n      var params = reader.decodeStruct('
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params);\n      this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '('
            l_2_loop = missing
            for l_2_parameter, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
                _loop_vars = {}
                pass
                yield 'params.'
                yield str(environment.getattr(l_2_parameter, 'name'))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    yield ', '
            l_2_loop = l_2_parameter = missing
            yield ').then(function(response) {\n        var responseParams =\n            new '
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_ResponseParams();'
            for l_2_parameter in environment.getattr(l_1_method, 'response_parameters'):
                _loop_vars = {}
                pass
                yield '\n        responseParams.'
                yield str(environment.getattr(l_2_parameter, 'name'))
                yield ' = response.'
                yield str(environment.getattr(l_2_parameter, 'name'))
                yield ';'
            l_2_parameter = missing
            if t_6(l_1_method):
                pass
                yield '\n        var builder = new codec.MessageV2Builder(\n            k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n            codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams\n                .encodedSize),\n            codec.kMessageIsResponse, reader.requestID);\n        builder.setPayload('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams,\n                             responseParams);'
            else:
                pass
                yield '\n        var builder = new codec.MessageV1Builder(\n            k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name,\n            codec.align('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams.encodedSize),\n            codec.kMessageIsResponse, reader.requestID);\n        builder.encodeStruct('
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams,\n                             responseParams);'
            yield '\n        var message = builder.finish();\n        responder.accept(message);\n      });\n      return true;'
    l_1_loop = l_1_method = l_1_interface_method_id = missing
    yield '\n    default:\n      return false;\n    }\n  };\n\n  function validate'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request(messageValidator) {'
    if (not environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n    return validator.validationError.NONE;'
    else:
        pass
        yield '\n    var message = messageValidator.message;\n    var paramsClass = null;\n    switch (message.getName()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            _loop_vars = {}
            pass
            l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            _loop_vars['interface_method_id'] = l_1_interface_method_id
            yield '\n      case k'
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Name:'
            if (environment.getattr(l_1_method, 'response_parameters') == None):
                pass
                yield '\n        if (!message.expectsResponse() && !message.isResponse())\n          paramsClass = '
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params;'
            else:
                pass
                yield '\n        if (message.expectsResponse())\n          paramsClass = '
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Params;'
            yield '\n      break;'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    }\n    if (paramsClass === null)\n      return validator.validationError.NONE;\n    return paramsClass.validate(messageValidator, messageValidator.message.getHeaderNumBytes());'
    yield '\n  }\n\n  function validate'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Response(messageValidator) {'
    if (not t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface))):
        pass
        yield '\n    return validator.validationError.NONE;'
    else:
        pass
        yield '\n   var message = messageValidator.message;\n   var paramsClass = null;\n   switch (message.getName()) {'
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            _loop_vars = {}
            pass
            l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            _loop_vars['interface_method_id'] = l_1_interface_method_id
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                yield '\n      case k'
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_Name:\n        if (message.isResponse())\n          paramsClass = '
                yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
                yield '_ResponseParams;\n        break;'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    }\n    if (paramsClass === null)\n      return validator.validationError.NONE;\n    return paramsClass.validate(messageValidator, messageValidator.message.getHeaderNumBytes());'
    yield '\n  }\n\n  var '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield " = {\n    name: '"
    yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'mojom_namespace'))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'))
    yield "',\n    kVersion: "
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'version'))
    yield ',\n    ptrClass: '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Ptr,\n    proxyClass: '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Proxy,\n    stubClass: '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub,\n    validateRequest: validate'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request,'
    if t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n    validateResponse: validate'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Response,'
    else:
        pass
        yield '\n    validateResponse: null,'
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        yield "\n    mojomId: '"
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
        yield "',\n    fuzzMethods: {"
        for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
            l_1_interface_method_id = missing
            _loop_vars = {}
            pass
            l_1_interface_method_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
            _loop_vars['interface_method_id'] = l_1_interface_method_id
            yield '\n      '
            yield str(environment.getattr(l_1_method, 'name'))
            yield ': {\n        params: '
            yield str((undefined(name='interface_method_id') if l_1_interface_method_id is missing else l_1_interface_method_id))
            yield '_Params,\n      },'
        l_1_method = l_1_interface_method_id = missing
        yield '\n    },'
    yield '\n  };'
    for l_1_constant in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'constants'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield '.'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(t_1(environment.getattr(l_1_constant, 'value')))
        yield ','
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'interface_definition.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 247 in 'interface_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_2('%s.%s', environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'), environment.getattr(l_1_enum, 'name')), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n  '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Stub.prototype.validator = validate'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Request;'
    if t_3((undefined(name='interface') if l_0_interface is missing else l_0_interface)):
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.validator = validate'
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Response;'
    else:
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Proxy.prototype.validator = null;'

blocks = {}
debug_info = '1=57&2=61&4=64&7=70&8=72&12=74&14=76&17=78&18=80&19=82&20=84&22=86&26=89&27=93&29=96&30=100&34=104&35=109&36=112&39=118&40=120&41=124&44=129&45=131&47=134&48=136&49=138&52=143&53=145&54=147&60=153&62=156&63=158&65=160&68=165&69=167&71=169&77=172&87=177&91=179&92=183&93=189&97=197&100=200&101=204&103=206&104=209&105=211&106=213&107=216&108=220&118=228&122=231&123=235&125=237&126=240&127=242&128=244&129=247&130=251&133=257&134=259&135=263&137=268&139=271&140=273&143=275&147=280&148=282&150=284&166=289&167=291&173=297&174=301&176=304&177=306&179=309&182=314&193=320&194=322&200=328&201=332&203=334&204=337&206=339&217=344&218=346&219=350&220=352&221=354&222=356&223=358&224=360&225=363&229=368&230=371&232=373&233=377&235=380&236=382&243=387&244=391&247=398&248=404&249=408&251=411&252=415&253=418&255=425'