from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'validation_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0__check_err = l_0__validate_field = l_0_validate_struct_field = l_0_validate_union_field = missing
    try:
        t_1 = environment.filters['is_any_handle_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_kind' found.")
    try:
        t_2 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_3 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_4 = environment.filters['is_interface_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_interface_kind' found.")
    try:
        t_5 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_6 = environment.filters['is_pending_associated_receiver_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_associated_receiver_kind' found.")
    try:
        t_7 = environment.filters['is_pending_associated_remote_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_associated_remote_kind' found.")
    try:
        t_8 = environment.filters['is_pending_receiver_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_receiver_kind' found.")
    try:
        t_9 = environment.filters['is_pending_remote_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_pending_remote_kind' found.")
    try:
        t_10 = environment.filters['is_string_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_string_kind' found.")
    try:
        t_11 = environment.filters['is_struct_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_struct_kind' found.")
    try:
        t_12 = environment.filters['is_union_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_union_kind' found.")
    try:
        t_13 = environment.filters['validate_array_params']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'validate_array_params' found.")
    try:
        t_14 = environment.filters['validate_enum_params']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'validate_enum_params' found.")
    try:
        t_15 = environment.filters['validate_map_params']
    except KeyError:
        @internalcode
        def t_15(*unused):
            raise TemplateRuntimeError("No filter named 'validate_map_params' found.")
    try:
        t_16 = environment.filters['validate_nullable_params']
    except KeyError:
        @internalcode
        def t_16(*unused):
            raise TemplateRuntimeError("No filter named 'validate_nullable_params' found.")
    try:
        t_17 = environment.filters['validate_struct_params']
    except KeyError:
        @internalcode
        def t_17(*unused):
            raise TemplateRuntimeError("No filter named 'validate_struct_params' found.")
    try:
        t_18 = environment.filters['validate_union_params']
    except KeyError:
        @internalcode
        def t_18(*unused):
            raise TemplateRuntimeError("No filter named 'validate_union_params' found.")
    pass
    def macro():
        t_19 = []
        pass
        t_19.append(
            'if (err !== validator.validationError.NONE)\n    return err;',
        )
        return concat(t_19)
    context.vars['_check_err'] = l_0__check_err = Macro(environment, macro, '_check_err', (), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_20 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_10(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateStringPointer(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ')\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_2(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateArrayPointer(',
                str(l_1_offset),
                ', ',
                str(t_13(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_11(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateStructPointer(',
                str(l_1_offset),
                ', ',
                str(t_17(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_5(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateMapPointer(',
                str(l_1_offset),
                ', ',
                str(t_15(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif (t_4(environment.getattr(l_1_field, 'kind')) or t_9(environment.getattr(l_1_field, 'kind'))):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateInterface(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_8(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateInterfaceRequest(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ')\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_7(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateAssociatedInterface(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_6(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateAssociatedInterfaceRequest(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ')\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_1(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateHandle(',
                str(l_1_offset),
                ', ',
                str(t_16(l_1_field)),
                ')\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        elif t_3(environment.getattr(l_1_field, 'kind')):
            pass
            t_20.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateEnum(',
                str(l_1_offset),
                ', ',
                str(t_14(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        return concat(t_20)
    context.vars['_validate_field'] = l_0__validate_field = Macro(environment, macro, '_validate_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_21 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_12(environment.getattr(l_1_field, 'kind')):
            pass
            t_21.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateUnion(',
                str(l_1_offset),
                ', ',
                str(t_18(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        else:
            pass
            t_21.append(
                str(context.call((undefined(name='_validate_field') if l_0__validate_field is missing else l_0__validate_field), l_1_field, l_1_offset, l_1_name)),
            )
        return concat(t_21)
    context.exported_vars.add('validate_struct_field')
    context.vars['validate_struct_field'] = l_0_validate_struct_field = Macro(environment, macro, 'validate_struct_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_field, l_1_offset, l_1_name):
        t_22 = []
        if l_1_field is missing:
            l_1_field = undefined("parameter 'field' was not provided", name='field')
        if l_1_offset is missing:
            l_1_offset = undefined("parameter 'offset' was not provided", name='offset')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_12(environment.getattr(l_1_field, 'kind')):
            pass
            t_22.extend((
                '\n// validate ',
                str(l_1_name),
                '\nerr = messageValidator.validateNestedUnion(',
                str(l_1_offset),
                ', ',
                str(t_18(l_1_field)),
                ');\n',
                str(context.call((undefined(name='_check_err') if l_0__check_err is missing else l_0__check_err))),
            ))
        else:
            pass
            t_22.extend((
                '\n',
                str(context.call((undefined(name='_validate_field') if l_0__validate_field is missing else l_0__validate_field), l_1_field, l_1_offset, l_1_name)),
            ))
        return concat(t_22)
    context.exported_vars.add('validate_union_field')
    context.vars['validate_union_field'] = l_0_validate_union_field = Macro(environment, macro, 'validate_union_field', ('field', 'offset', 'name'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=120&6=128&7=137&8=141&9=143&10=147&11=149&12=153&13=155&14=159&15=161&16=165&17=167&18=171&19=173&20=177&21=179&22=183&23=185&24=189&25=191&26=195&27=197&28=201&29=203&30=207&31=209&32=213&33=215&34=219&35=221&36=225&37=227&38=231&39=233&40=237&41=239&42=243&43=245&44=249&45=251&46=255&50=259&51=268&52=272&53=274&54=278&56=283&60=288&61=297&62=301&63=303&64=307&66=313'