from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/module_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['lite_closure_type_with_nullability']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'lite_closure_type_with_nullability' found.")
    pass
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        _loop_vars = {}
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield str(environment.getattr(l_1_constant, 'name'))
            yield "');"
        yield '\n/**\n * @const { '
        yield str(t_2(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n * @export\n */\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(t_1(l_1_constant))
        yield ';'
    l_1_constant = l_1_generate_closure_exports = missing
    yield '\n'
    included_template = environment.get_template('lite/enum_definition.tmpl', 'lite/module_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 15 in 'lite/module_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('lite/interface_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'enum_def': l_0_enum_def})):
            yield event
    l_1_interface = missing
    yield '\n\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        _loop_vars = {}
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield str(environment.getattr(l_1_struct, 'name'))
            yield "Spec');"
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType}}\n * @export\n */\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_struct = l_1_generate_closure_exports = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_generate_closure_exports = resolve('generate_closure_exports')
        _loop_vars = {}
        pass
        yield '\n'
        if (undefined(name='generate_closure_exports') if l_1_generate_closure_exports is missing else l_1_generate_closure_exports):
            pass
            yield "goog.provide('"
            yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
            yield '.'
            yield str(environment.getattr(l_1_union, 'name'))
            yield "Spec');"
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType} }\n * @export\n */\n'
        yield str(environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'namespace'))
        yield '.'
        yield str(environment.getattr(l_1_union, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_union = l_1_generate_closure_exports = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        template = environment.get_template('lite/struct_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        template = environment.get_template('lite/union_definition.tmpl', 'lite/module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_union = missing

blocks = {}
debug_info = '2=29&3=34&4=37&8=42&11=44&15=52&16=58&17=62&21=65&22=69&29=74&30=79&31=82&37=87&40=92&41=97&42=100&48=105&53=111&54=114&58=120&59=123'