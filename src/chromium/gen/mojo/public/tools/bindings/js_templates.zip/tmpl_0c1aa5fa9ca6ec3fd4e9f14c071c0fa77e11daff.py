from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union_def = l_0_tags = l_0_encode = l_0_decode = l_0_validate_union_field = l_0_validate = missing
    try:
        t_1 = environment.filters['contains_handles_or_interfaces']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'contains_handles_or_interfaces' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_4 = environment.filters['union_decode_snippet']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'union_decode_snippet' found.")
    try:
        t_5 = environment.filters['union_encode_snippet']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'union_encode_snippet' found.")
    pass
    def macro(l_1_union, l_1_generate_fuzzing):
        t_6 = []
        l_1_generate_or_mutate = resolve('generate_or_mutate')
        l_1_get_handle_deps = resolve('get_handle_deps')
        l_1_set_handles = resolve('set_handles')
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        if l_1_generate_fuzzing is missing:
            l_1_generate_fuzzing = False
        pass
        t_6.extend((
            '\nfunction ',
            str(environment.getattr(l_1_union, 'name')),
            '(value) {\n  this.initDefault_();\n  this.initValue_(value);\n}\n\n',
            str(context.call((undefined(name='tags') if l_0_tags is missing else l_0_tags), l_1_union)),
            '\n\n',
            str(environment.getattr(l_1_union, 'name')),
            '.prototype.initDefault_ = function() {\n  this.$data = null;\n  this.$tag = undefined;\n}\n\n',
            str(environment.getattr(l_1_union, 'name')),
            '.prototype.initValue_ = function(value) {\n  if (value == undefined) {\n    return;\n  }\n\n  var keys = Object.keys(value);\n  if (keys.length == 0) {\n    return;\n  }\n\n  if (keys.length > 1) {\n    throw new TypeError("You may set only one member on a union.");\n  }\n\n  var fields = [',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_6.extend((
                '\n      "',
                str(environment.getattr(l_2_field, 'name')),
                '",',
            ))
        l_2_field = missing
        t_6.extend((
            '\n  ];\n\n  if (fields.indexOf(keys[0]) < 0) {\n    throw new ReferenceError(keys[0] + " is not a ',
            str(environment.getattr(l_1_union, 'name')),
            ' member.");\n\n  }\n\n  this[keys[0]] = value[keys[0]];\n}',
        ))
        if l_1_generate_fuzzing:
            pass
            included_template = environment.get_template('fuzzing.tmpl', 'union_definition.tmpl')._get_default_module(context)
            l_1_generate_or_mutate = getattr(included_template, 'generate_or_mutate', missing)
            if l_1_generate_or_mutate is missing:
                l_1_generate_or_mutate = undefined(f"the template {included_template.__name__!r} (imported on line 43 in 'union_definition.tmpl') does not export the requested name 'generate_or_mutate'", name='generate_or_mutate')
            t_6.extend((
                '\n',
                str(environment.getattr(l_1_union, 'name')),
                '.generate = function(generator_) {\n  var generated = new ',
                str(environment.getattr(l_1_union, 'name')),
                ';\n  var generators = [',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                _loop_vars = {}
                pass
                t_6.extend((
                    '\n    {\n      field: "',
                    str(environment.getattr(l_2_field, 'name')),
                    '",\n\n      generator: function() { return ',
                    str(t_2(context.call((undefined(name='generate_or_mutate') if l_1_generate_or_mutate is missing else l_1_generate_or_mutate), 'generator_', 'generate', environment.getattr(l_2_field, 'kind'), _loop_vars=_loop_vars), 6)),
                    '; },\n    },',
                ))
            l_2_field = missing
            t_6.extend((
                '\n  ];\n\n  var result = generator_.generateUnionField(generators);\n  generated[result.field] = result.value;\n  return generated;\n}\n\n',
                str(environment.getattr(l_1_union, 'name')),
                '.prototype.mutate = function(mutator_) {\n  var mutators = [',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                _loop_vars = {}
                pass
                t_6.extend((
                    '\n    {\n      field: "',
                    str(environment.getattr(l_2_field, 'name')),
                    '",\n\n      mutator: function(val) { return ',
                    str(t_2(context.call((undefined(name='generate_or_mutate') if l_1_generate_or_mutate is missing else l_1_generate_or_mutate), 'mutator_', 'mutate', environment.getattr(l_2_field, 'kind'), str_join(('val.', environment.getattr(l_2_field, 'name'), )), _loop_vars=_loop_vars), 6)),
                    '; },\n    },',
                ))
            l_2_field = missing
            t_6.append(
                '\n  ];\n\n  var result = mutator_.mutateUnionField(this, mutators);\n  this[result.field] = result.value;\n  return this;\n}',
            )
            included_template = environment.get_template('fuzzing.tmpl', 'union_definition.tmpl')._get_default_module(context)
            l_1_get_handle_deps = getattr(included_template, 'get_handle_deps', missing)
            if l_1_get_handle_deps is missing:
                l_1_get_handle_deps = undefined(f"the template {included_template.__name__!r} (imported on line 77 in 'union_definition.tmpl') does not export the requested name 'get_handle_deps'", name='get_handle_deps')
            t_6.extend((
                '\n',
                str(environment.getattr(l_1_union, 'name')),
                '.prototype.getHandleDeps = function() {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                _loop_vars = {}
                pass
                if t_1(environment.getattr(l_2_field, 'kind')):
                    pass
                    t_6.extend((
                        '\n  if (this.$tag == ',
                        str(environment.getattr(l_1_union, 'name')),
                        '.Tags.',
                        str(environment.getattr(l_2_field, 'name')),
                        ') {\n    return ',
                        str(context.call((undefined(name='get_handle_deps') if l_1_get_handle_deps is missing else l_1_get_handle_deps), environment.getattr(l_2_field, 'kind'), str_join(('this.', environment.getattr(l_2_field, 'name'), )), _loop_vars=_loop_vars)),
                        ';\n  }',
                    ))
            l_2_field = missing
            t_6.append(
                '\n  return [];\n}',
            )
            included_template = environment.get_template('fuzzing.tmpl', 'union_definition.tmpl')._get_default_module(context)
            l_1_set_handles = getattr(included_template, 'set_handles', missing)
            if l_1_set_handles is missing:
                l_1_set_handles = undefined(f"the template {included_template.__name__!r} (imported on line 89 in 'union_definition.tmpl') does not export the requested name 'set_handles'", name='set_handles')
            t_6.extend((
                '\n',
                str(environment.getattr(l_1_union, 'name')),
                '.prototype.setHandles = function() {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                _loop_vars = {}
                pass
                if t_1(environment.getattr(l_2_field, 'kind')):
                    pass
                    t_6.extend((
                        '\n  if (this.$tag == ',
                        str(environment.getattr(l_1_union, 'name')),
                        '.Tags.',
                        str(environment.getattr(l_2_field, 'name')),
                        ') {\n    return ',
                        str(context.call((undefined(name='set_handles') if l_1_set_handles is missing else l_1_set_handles), environment.getattr(l_2_field, 'kind'), str_join(('this.', environment.getattr(l_2_field, 'name'), )), _loop_vars=_loop_vars)),
                        ';\n  }',
                    ))
            l_2_field = missing
            t_6.append(
                '\n  return [];\n}',
            )
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_6.extend((
                '\nObject.defineProperty(',
                str(environment.getattr(l_1_union, 'name')),
                '.prototype, "',
                str(environment.getattr(l_2_field, 'name')),
                '", {\n  get: function() {\n    if (this.$tag != ',
                str(environment.getattr(l_1_union, 'name')),
                '.Tags.',
                str(environment.getattr(l_2_field, 'name')),
                ') {\n      throw new ReferenceError(\n          "',
                str(environment.getattr(l_1_union, 'name')),
                '.',
                str(environment.getattr(l_2_field, 'name')),
                ' is not currently set.");\n    }\n    return this.$data;\n  },\n\n  set: function(value) {\n    this.$tag = ',
                str(environment.getattr(l_1_union, 'name')),
                '.Tags.',
                str(environment.getattr(l_2_field, 'name')),
                ';\n    this.$data = value;\n  }\n});',
            ))
        l_2_field = missing
        t_6.extend((
            '\n\n',
            str(t_2(context.call((undefined(name='encode') if l_0_encode is missing else l_0_encode), l_1_union), 2)),
            '\n\n',
            str(t_2(context.call((undefined(name='decode') if l_0_decode is missing else l_0_decode), l_1_union), 2)),
            '\n\n',
            str(t_2(context.call((undefined(name='validate') if l_0_validate is missing else l_0_validate), l_1_union), 2)),
            '\n\n',
            str(environment.getattr(l_1_union, 'name')),
            '.encodedSize = 16;',
        ))
        return concat(t_6)
    context.exported_vars.add('union_def')
    context.vars['union_def'] = l_0_union_def = Macro(environment, macro, 'union_def', ('union', 'generate_fuzzing'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_7 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_7.extend((
            '\n',
            str(environment.getattr(l_1_union, 'name')),
            '.Tags = {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_7.extend((
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                ': ',
                str(environment.getattr(l_2_field, 'ordinal')),
                ',',
            ))
        l_2_field = missing
        t_7.append(
            '\n};',
        )
        return concat(t_7)
    context.exported_vars.add('tags')
    context.vars['tags'] = l_0_tags = Macro(environment, macro, 'tags', ('union',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_8 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_8.extend((
            '\n',
            str(environment.getattr(l_1_union, 'name')),
            '.encode = function(encoder, val) {\n  if (val == null) {\n    encoder.writeUint64(0);\n    encoder.writeUint64(0);\n    return;\n  }\n  if (val.$tag == undefined) {\n    throw new TypeError("Cannot encode unions with an unknown member set.");\n  }\n\n  encoder.writeUint32(16);\n  encoder.writeUint32(val.$tag);\n  switch (val.$tag) {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_8.extend((
                '\n    case ',
                str(environment.getattr(l_1_union, 'name')),
                '.Tags.',
                str(environment.getattr(l_2_field, 'name')),
                ':',
            ))
            if t_3(environment.getattr(l_2_field, 'kind')):
                pass
                t_8.extend((
                    '\n      encoder.writeUint8(val.',
                    str(environment.getattr(l_2_field, 'name')),
                    ' ? 1 : 0);',
                ))
            else:
                pass
                t_8.extend((
                    '\n      encoder.',
                    str(t_5(environment.getattr(l_2_field, 'kind'))),
                    'val.',
                    str(environment.getattr(l_2_field, 'name')),
                    ');',
                ))
            t_8.append(
                '\n      break;',
            )
        l_2_field = missing
        t_8.append(
            '\n  }\n  encoder.align();\n};',
        )
        return concat(t_8)
    context.exported_vars.add('encode')
    context.vars['encode'] = l_0_encode = Macro(environment, macro, 'encode', ('union',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_9 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_9.extend((
            '\n',
            str(environment.getattr(l_1_union, 'name')),
            '.decode = function(decoder) {\n  var size = decoder.readUint32();\n  if (size == 0) {\n    decoder.readUint32();\n    decoder.readUint64();\n    return null;\n  }\n\n  var result = new ',
            str(environment.getattr(l_1_union, 'name')),
            '();\n  var tag = decoder.readUint32();\n  switch (tag) {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            _loop_vars = {}
            pass
            t_9.extend((
                '\n    case ',
                str(environment.getattr(l_1_union, 'name')),
                '.Tags.',
                str(environment.getattr(l_2_field, 'name')),
                ':',
            ))
            if t_3(environment.getattr(l_2_field, 'kind')):
                pass
                t_9.extend((
                    '\n      result.',
                    str(environment.getattr(l_2_field, 'name')),
                    ' = decoder.readUint8() ? true : false;',
                ))
            else:
                pass
                t_9.extend((
                    '\n      result.',
                    str(environment.getattr(l_2_field, 'name')),
                    ' = decoder.',
                    str(t_4(environment.getattr(l_2_field, 'kind'))),
                    ';',
                ))
            t_9.append(
                '\n      break;',
            )
        l_2_field = missing
        t_9.append(
            '\n  }\n  decoder.align();\n\n  return result;\n};',
        )
        return concat(t_9)
    context.exported_vars.add('decode')
    context.vars['decode'] = l_0_decode = Macro(environment, macro, 'decode', ('union',), False, False, False, context.eval_ctx.autoescape)
    included_template = environment.get_template('validation_macros.tmpl', 'union_definition.tmpl')._get_default_module(context)
    l_0_validate_union_field = getattr(included_template, 'validate_union_field', missing)
    if l_0_validate_union_field is missing:
        l_0_validate_union_field = undefined(f"the template {included_template.__name__!r} (imported on line 192 in 'union_definition.tmpl') does not export the requested name 'validate_union_field'", name='validate_union_field')
    context.vars['validate_union_field'] = l_0_validate_union_field
    context.exported_vars.discard('validate_union_field')
    def macro(l_1_union):
        t_10 = []
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        t_10.extend((
            '\n',
            str(environment.getattr(l_1_union, 'name')),
            '.validate = function(messageValidator, offset) {\n  var size = messageValidator.decodeUnionSize(offset);\n  if (size != 16) {\n    return validator.validationError.INVALID_UNION_SIZE;\n  }\n\n  var tag = messageValidator.decodeUnionTag(offset);\n  var data_offset = offset + 8;\n  var err;\n  switch (tag) {',
        ))
        for l_2_field in environment.getattr(l_1_union, 'fields'):
            l_2_name = missing
            _loop_vars = {}
            pass
            l_2_name = str_join((environment.getattr(l_1_union, 'name'), '.', environment.getattr(l_2_field, 'name'), ))
            _loop_vars['name'] = l_2_name
            t_10.extend((
                '\n    case ',
                str(environment.getattr(l_1_union, 'name')),
                '.Tags.',
                str(environment.getattr(l_2_field, 'name')),
                ':\n      ',
                str(context.call((undefined(name='validate_union_field') if l_0_validate_union_field is missing else l_0_validate_union_field), l_2_field, 'data_offset', (undefined(name='name') if l_2_name is missing else l_2_name), _loop_vars=_loop_vars)),
                '\n      break;',
            ))
        l_2_field = l_2_name = missing
        t_10.append(
            '\n  }\n\n  return validator.validationError.NONE;\n};',
        )
        return concat(t_10)
    context.exported_vars.add('validate')
    context.vars['validate'] = l_0_validate = Macro(environment, macro, 'validate', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=42&2=54&7=56&9=58&14=60&29=63&30=68&35=74&42=77&43=79&44=85&45=87&47=90&49=95&51=97&61=103&63=106&65=111&67=113&77=120&78=126&79=129&80=132&81=136&82=140&89=147&90=153&91=156&92=159&93=163&94=167&102=174&103=179&105=183&107=187&113=191&119=199&121=201&123=203&125=205&128=211&129=218&130=221&131=226&136=238&137=245&150=248&151=253&152=258&153=262&155=269&164=284&165=291&173=293&176=296&177=301&178=306&179=310&181=317&192=332&193=338&194=345&204=348&205=352&206=356&207=360'