from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_generate_fuzzing = resolve('generate_fuzzing')
    l_0_generate_or_mutate = resolve('generate_or_mutate')
    l_0_get_handle_deps = resolve('get_handle_deps')
    l_0_set_handles = resolve('set_handles')
    l_0_enum_def = l_0_validate_struct_field = l_0_last_checked_version = missing
    try:
        t_1 = environment.filters['contains_handles_or_interfaces']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'contains_handles_or_interfaces' found.")
    try:
        t_2 = environment.filters['decode_snippet']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'decode_snippet' found.")
    try:
        t_3 = environment.filters['default_value']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'default_value' found.")
    try:
        t_4 = environment.filters['encode_snippet']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'encode_snippet' found.")
    try:
        t_5 = environment.filters['expression_to_text']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'expression_to_text' found.")
    try:
        t_6 = environment.filters['field_offset']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'field_offset' found.")
    try:
        t_7 = environment.filters['format']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'format' found.")
    try:
        t_8 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_9 = environment.filters['is_any_handle_or_interface_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_any_handle_or_interface_kind' found.")
    try:
        t_10 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_11 = environment.filters['is_enum_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'is_enum_kind' found.")
    try:
        t_12 = environment.filters['is_object_kind']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'is_object_kind' found.")
    try:
        t_13 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_13(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_14 = environment.filters['payload_size']
    except KeyError:
        @internalcode
        def t_14(*unused):
            raise TemplateRuntimeError("No filter named 'payload_size' found.")
    pass
    yield '\n  function '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '(values) {\n    this.initDefaults_();\n    this.initFields_(values);\n  }'
    included_template = environment.get_template('enum_definition.tmpl', 'struct_definition.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 8 in 'struct_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), t_7('%s.%s', environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), environment.getattr(l_1_enum, 'name')), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n'
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(t_5(environment.getattr(l_1_constant, 'value')))
        yield ';'
    l_1_constant = missing
    yield '\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.prototype.initDefaults_ = function() {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        _loop_vars = {}
        pass
        yield '\n    this.'
        yield str(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield ' = '
        yield str(t_3(environment.getattr(l_1_packed_field, 'field')))
        yield ';'
    l_1_packed_field = missing
    yield '\n  };\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.prototype.initFields_ = function(fields) {\n    for(var field in fields) {\n        if (this.hasOwnProperty(field))\n          this[field] = fields[field];\n    }\n  };'
    if (undefined(name='generate_fuzzing') if l_0_generate_fuzzing is missing else l_0_generate_fuzzing):
        pass
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module(context)
        l_0_generate_or_mutate = getattr(included_template, 'generate_or_mutate', missing)
        if l_0_generate_or_mutate is missing:
            l_0_generate_or_mutate = undefined(f"the template {included_template.__name__!r} (imported on line 35 in 'struct_definition.tmpl') does not export the requested name 'generate_or_mutate'", name='generate_or_mutate')
        context.vars['generate_or_mutate'] = l_0_generate_or_mutate
        context.exported_vars.discard('generate_or_mutate')
        yield '\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.generate = function(generator_) {\n    var generated = new '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield ';'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            _loop_vars = {}
            pass
            yield '\n    generated.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield str(t_8(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), 'generator_', 'generate', environment.getattr(l_1_field, 'kind'), _loop_vars=_loop_vars), 4))
            yield ';'
        l_1_field = missing
        yield '\n    return generated;\n  };\n\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.mutate = function(mutator_) {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            _loop_vars = {}
            pass
            yield '\n    if (mutator_.chooseMutateField()) {\n      this.'
            yield str(environment.getattr(l_1_field, 'name'))
            yield ' = '
            yield str(t_8(context.call((undefined(name='generate_or_mutate') if l_0_generate_or_mutate is missing else l_0_generate_or_mutate), 'mutator_', 'mutate', environment.getattr(l_1_field, 'kind'), str_join(('this.', environment.getattr(l_1_field, 'name'), )), _loop_vars=_loop_vars), 6))
            yield ';\n    }'
        l_1_field = missing
        yield '\n    return this;\n  };'
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module(context)
        l_0_get_handle_deps = getattr(included_template, 'get_handle_deps', missing)
        if l_0_get_handle_deps is missing:
            l_0_get_handle_deps = undefined(f"the template {included_template.__name__!r} (imported on line 53 in 'struct_definition.tmpl') does not export the requested name 'get_handle_deps'", name='get_handle_deps')
        context.vars['get_handle_deps'] = l_0_get_handle_deps
        context.exported_vars.discard('get_handle_deps')
        yield '\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.getHandleDeps = function() {\n    var handles = [];'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            _loop_vars = {}
            pass
            if t_1(environment.getattr(l_1_field, 'kind')):
                pass
                yield '\n    if (this.'
                yield str(environment.getattr(l_1_field, 'name'))
                yield ' !== null) {\n      Array.prototype.push.apply(handles, '
                yield str(t_8(context.call((undefined(name='get_handle_deps') if l_0_get_handle_deps is missing else l_0_get_handle_deps), environment.getattr(l_1_field, 'kind'), str_join(('this.', environment.getattr(l_1_field, 'name'), )), _loop_vars=_loop_vars), 6))
                yield ');\n    }'
        l_1_field = missing
        yield '\n    return handles;\n  };\n\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.setHandles = function() {\n    this.setHandlesInternal_(arguments, 0);\n  };'
        included_template = environment.get_template('fuzzing.tmpl', 'struct_definition.tmpl')._get_default_module(context)
        l_0_set_handles = getattr(included_template, 'set_handles', missing)
        if l_0_set_handles is missing:
            l_0_set_handles = undefined(f"the template {included_template.__name__!r} (imported on line 70 in 'struct_definition.tmpl') does not export the requested name 'set_handles'", name='set_handles')
        context.vars['set_handles'] = l_0_set_handles
        context.exported_vars.discard('set_handles')
        yield '\n  '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '.prototype.setHandlesInternal_ = function(handles, idx) {'
        for l_1_field in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'fields'):
            _loop_vars = {}
            pass
            if t_1(environment.getattr(l_1_field, 'kind')):
                pass
                yield '\n    '
                yield str(t_8(context.call((undefined(name='set_handles') if l_0_set_handles is missing else l_0_set_handles), environment.getattr(l_1_field, 'kind'), str_join(('this.', environment.getattr(l_1_field, 'name'), )), _loop_vars=_loop_vars), 4))
                yield ';'
        l_1_field = missing
        yield '\n    return idx;\n  };'
    yield '\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.validate = function(messageValidator, offset) {\n    var err;\n    err = messageValidator.validateStructHeader(offset, codec.kStructHeaderSize);\n    if (err !== validator.validationError.NONE)\n        return err;\n\n    var kVersionSizes = ['
    l_1_loop = missing
    for l_1_version, l_1_loop in LoopContext(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), undefined):
        _loop_vars = {}
        pass
        yield '\n      {version: '
        yield str(environment.getattr(l_1_version, 'version'))
        yield ', numBytes: '
        yield str(environment.getattr(l_1_version, 'num_bytes'))
        yield '}'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            yield ','
    l_1_loop = l_1_version = missing
    yield '\n    ];\n    err = messageValidator.validateStructVersion(offset, kVersionSizes);\n    if (err !== validator.validationError.NONE)\n        return err;'
    included_template = environment.get_template('validation_macros.tmpl', 'struct_definition.tmpl')._get_default_module(context)
    l_0_validate_struct_field = getattr(included_template, 'validate_struct_field', missing)
    if l_0_validate_struct_field is missing:
        l_0_validate_struct_field = undefined(f"the template {included_template.__name__!r} (imported on line 103 in 'struct_definition.tmpl') does not export the requested name 'validate_struct_field'", name='validate_struct_field')
    context.vars['validate_struct_field'] = l_0_validate_struct_field
    context.exported_vars.discard('validate_struct_field')
    l_0_last_checked_version = 0
    context.vars['last_checked_version'] = l_0_last_checked_version
    context.exported_vars.add('last_checked_version')
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_last_checked_version = l_0_last_checked_version
        l_1_offset = l_1_field = l_1_name = missing
        _loop_vars = {}
        pass
        l_1_offset = t_6(l_1_packed_field)
        _loop_vars['offset'] = l_1_offset
        l_1_field = environment.getattr(l_1_packed_field, 'field')
        _loop_vars['field'] = l_1_field
        l_1_name = str_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), '.', environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'name'), ))
        _loop_vars['name'] = l_1_name
        yield '\n'
        if ((t_12(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind')) or t_9(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind'))) or t_11(environment.getattr((undefined(name='field') if l_1_field is missing else l_1_field), 'kind'))):
            pass
            yield '\n'
            if (environment.getattr(l_1_packed_field, 'min_version') > (undefined(name='last_checked_version') if l_1_last_checked_version is missing else l_1_last_checked_version)):
                pass
                yield '\n'
                l_1_last_checked_version = environment.getattr(l_1_packed_field, 'min_version')
                _loop_vars['last_checked_version'] = l_1_last_checked_version
                yield '\n    // version check '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield '\n    if (!messageValidator.isFieldInStructVersion(offset, '
                yield str(environment.getattr(l_1_packed_field, 'min_version'))
                yield '))\n      return validator.validationError.NONE;'
            yield str(t_8(context.call((undefined(name='validate_struct_field') if l_0_validate_struct_field is missing else l_0_validate_struct_field), (undefined(name='field') if l_1_field is missing else l_1_field), (undefined(name='offset') if l_1_offset is missing else l_1_offset), (undefined(name='name') if l_1_name is missing else l_1_name), _loop_vars=_loop_vars), 4))
    l_1_packed_field = l_1_offset = l_1_field = l_1_name = l_1_last_checked_version = missing
    yield '\n\n    return validator.validationError.NONE;\n  };\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encodedSize = codec.kStructHeaderSize + '
    yield str(t_14(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed')))
    yield ';\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.decode = function(decoder) {\n    var packed;\n    var val = new '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '();\n    var numberOfBytes = decoder.readUint32();\n    var version = decoder.readUint32();'
    for l_1_byte in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'bytes'):
        _loop_vars = {}
        pass
        if ((t_13(environment.getattr(l_1_byte, 'packed_fields')) >= 1) and t_10(environment.getattr(environment.getattr(environment.getitem(environment.getattr(l_1_byte, 'packed_fields'), 0), 'field'), 'kind'))):
            pass
            yield '\n    packed = decoder.readUint8();'
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                _loop_vars = {}
                pass
                yield '\n    val.'
                yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ' = (packed >> '
                yield str(environment.getattr(l_2_packed_field, 'bit'))
                yield ') & 1 ? true : false;'
            l_2_packed_field = missing
        else:
            pass
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                _loop_vars = {}
                pass
                if (environment.getattr(l_2_packed_field, 'min_version') > 0):
                    pass
                    yield '\n    if (version >= '
                    yield str(environment.getattr(l_2_packed_field, 'min_version'))
                    yield ') {\n      val.'
                    yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' =\n          decoder.'
                    yield str(t_2(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                    yield ';\n    } else {\n      val.'
                    yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' = null;\n    }'
                else:
                    pass
                    yield '\n    val.'
                    yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                    yield ' =\n        decoder.'
                    yield str(t_2(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                    yield ';'
            l_2_packed_field = missing
        if environment.getattr(l_1_byte, 'is_padding'):
            pass
            yield '\n    decoder.skip(1);'
    l_1_byte = missing
    yield '\n    return val;\n  };\n\n  '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encode = function(encoder, val) {\n    var packed;\n    encoder.writeUint32('
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield '.encodedSize);\n    encoder.writeUint32('
    yield str(environment.getattr(environment.getitem(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'), -1), 'version'))
    yield ');'
    for l_1_byte in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'bytes'):
        _loop_vars = {}
        pass
        if ((t_13(environment.getattr(l_1_byte, 'packed_fields')) >= 1) and t_10(environment.getattr(environment.getattr(environment.getitem(environment.getattr(l_1_byte, 'packed_fields'), 0), 'field'), 'kind'))):
            pass
            yield '\n    packed = 0;'
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                _loop_vars = {}
                pass
                yield '\n    packed |= (val.'
                yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ' & 1) << '
                yield str(environment.getattr(l_2_packed_field, 'bit'))
            l_2_packed_field = missing
            yield '\n    encoder.writeUint8(packed);'
        else:
            pass
            for l_2_packed_field in environment.getattr(l_1_byte, 'packed_fields'):
                _loop_vars = {}
                pass
                yield '\n    encoder.'
                yield str(t_4(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'kind')))
                yield 'val.'
                yield str(environment.getattr(environment.getattr(l_2_packed_field, 'field'), 'name'))
                yield ');'
            l_2_packed_field = missing
        if environment.getattr(l_1_byte, 'is_padding'):
            pass
            yield '\n    encoder.skip(1);'
    l_1_byte = missing
    yield '\n  };'

blocks = {}
debug_info = '2=102&8=104&9=111&10=115&14=118&15=122&19=130&20=132&21=136&26=142&34=144&35=146&36=153&37=155&38=157&39=161&44=167&45=169&47=173&53=179&54=186&56=188&57=191&58=194&59=196&66=200&70=202&71=209&72=211&73=214&74=217&83=222&90=225&91=229&103=238&104=244&105=247&106=252&107=254&108=256&109=259&112=262&113=265&114=268&115=270&118=272&127=275&129=279&131=281&134=283&135=286&138=289&139=293&142=300&143=303&144=306&145=308&146=310&148=312&151=317&152=319&156=322&163=327&165=329&166=331&168=333&169=336&172=339&173=343&177=350&178=354&181=359'