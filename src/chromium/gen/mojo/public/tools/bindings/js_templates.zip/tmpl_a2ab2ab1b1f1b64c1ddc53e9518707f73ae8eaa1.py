from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/mojom.m.js.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_for_bindings_internals = resolve('for_bindings_internals')
    l_0_bindings_library_path = resolve('bindings_library_path')
    l_0_js_module_imports = resolve('js_module_imports')
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_interfaces = resolve('interfaces')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['constant_value_in_js_module']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value_in_js_module' found.")
    try:
        t_2 = environment.filters['imports_for_kind']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'imports_for_kind' found.")
    try:
        t_3 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    try:
        t_4 = environment.filters['type_in_js_module_with_nullability']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'type_in_js_module_with_nullability' found.")
    pass
    yield '// Copyright 2020 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n'
    if (not (undefined(name='for_bindings_internals') if l_0_for_bindings_internals is missing else l_0_for_bindings_internals)):
        pass
        yield "import {mojo} from '"
        yield str((undefined(name='bindings_library_path') if l_0_bindings_library_path is missing else l_0_bindings_library_path))
        yield "';"
    yield '\n\n'
    l_1_loop = missing
    for (l_1_path, l_1_kinds), l_1_loop in LoopContext(t_3(environment, context.call(environment.getattr((undefined(name='js_module_imports') if l_0_js_module_imports is missing else l_0_js_module_imports), 'items'))), undefined):
        _loop_vars = {}
        pass
        yield 'import {'
        l_2_loop = missing
        for l_2_kind, l_2_loop in LoopContext(t_3(environment, l_1_kinds), undefined):
            _loop_vars = {}
            pass
            l_3_loop = missing
            for l_3_item, l_3_loop in LoopContext(t_2(l_2_kind), undefined):
                _loop_vars = {}
                pass
                yield '\n  '
                yield str(environment.getattr(l_3_item, 'name'))
                yield ' as '
                yield str(environment.getattr(l_3_item, 'alias'))
                if (not environment.getattr(l_3_loop, 'last')):
                    pass
                    yield ','
            l_3_loop = l_3_item = missing
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_kind = missing
        yield "\n} from '"
        yield str(l_1_path)
        yield "';\n\n"
    l_1_loop = l_1_path = l_1_kinds = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        yield '\n/**\n * @const { '
        yield str(t_4(environment.getattr(l_1_constant, 'kind')))
        yield ' }\n */\nexport const '
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(t_1(l_1_constant))
        yield ';\n\n'
    l_1_constant = missing
    included_template = environment.get_template('lite/enum_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 32 in 'lite/mojom.m.js.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('lite/interface_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'enum_def': l_0_enum_def})):
            yield event
    l_1_interface = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType}}\n */\nexport const '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n/**\n * @const { {$:!mojo.internal.MojomType} }\n */\nexport const '
        yield str(environment.getattr(l_1_union, 'name'))
        yield 'Spec =\n    { $: /** @type {!mojo.internal.MojomType} */ ({}) };\n'
    l_1_union = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        template = environment.get_template('lite/struct_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_struct = missing
    yield '\n'
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        template = environment.get_template('lite/union_definition_for_module.tmpl', 'lite/mojom.m.js.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'union': l_1_union, 'enum_def': l_0_enum_def})):
            yield event
        yield '\n'
    l_1_union = missing

blocks = {}
debug_info = '5=45&6=48&9=52&11=57&12=61&13=65&14=68&16=72&18=77&23=80&25=84&27=86&32=91&33=97&34=101&38=104&39=108&43=113&47=117&50=120&54=124&59=128&60=131&64=137&65=140'