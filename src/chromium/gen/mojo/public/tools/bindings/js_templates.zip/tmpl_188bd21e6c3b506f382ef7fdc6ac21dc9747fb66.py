from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'lite/union_definition_for_module.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    try:
        t_1 = environment.filters['spec_type_in_js_module']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'spec_type_in_js_module' found.")
    try:
        t_2 = environment.filters['type_in_js_module_with_nullability']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'type_in_js_module_with_nullability' found.")
    pass
    yield 'mojo.internal.Union(\n    '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "Spec.$, '"
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield "',\n    {"
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield "\n      '"
        yield str(environment.getattr(l_1_field, 'name'))
        yield "': {\n        'ordinal': "
        yield str(environment.getattr(l_1_field, 'ordinal'))
        yield ",\n        'type': "
        yield str(t_1(environment.getattr(l_1_field, 'kind')))
        yield ','
        if environment.getattr(environment.getattr(l_1_field, 'kind'), 'is_nullable'):
            pass
            yield "\n        'nullable': true,"
        yield '\n      },'
    l_1_field = missing
    yield '\n    });\n\n/**\n * @typedef { {'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        _loop_vars = {}
        pass
        yield '\n *   '
        yield str(environment.getattr(l_1_field, 'name'))
        yield ': ('
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield '|undefined),'
    l_1_field = missing
    yield '\n * } }\n */\nexport const '
    yield str(environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'name'))
    yield ' = {};'

blocks = {}
debug_info = '2=25&4=29&5=33&6=35&7=37&8=39&17=45&18=49&22=55'