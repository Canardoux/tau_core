from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_enums = resolve('enums')
    l_0_structs = resolve('structs')
    l_0_unions = resolve('unions')
    l_0_interfaces = resolve('interfaces')
    l_0_enum_def = l_0_union_def = missing
    try:
        t_1 = environment.filters['expression_to_text']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'expression_to_text' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    pass
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        yield '\n  var '
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(t_1(environment.getattr(l_1_constant, 'value')))
        yield ';'
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'module_definition.tmpl')._get_default_module(context)
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 7 in 'module_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n  var '
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), environment.getattr(l_1_enum, 'name'), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n'
    for l_1_struct in (undefined(name='structs') if l_0_structs is missing else l_0_structs):
        _loop_vars = {}
        pass
        template = environment.get_template('struct_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'struct': l_1_struct, 'enum_def': l_0_enum_def, 'union_def': l_0_union_def})):
            yield event
    l_1_struct = missing
    included_template = environment.get_template('union_definition.tmpl', 'module_definition.tmpl')._get_default_module(context)
    l_0_union_def = getattr(included_template, 'union_def', missing)
    if l_0_union_def is missing:
        l_0_union_def = undefined(f"the template {included_template.__name__!r} (imported on line 18 in 'module_definition.tmpl') does not export the requested name 'union_def'", name='union_def')
    context.vars['union_def'] = l_0_union_def
    context.exported_vars.discard('union_def')
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        l_1_generate_fuzzing = resolve('generate_fuzzing')
        _loop_vars = {}
        pass
        yield '\n'
        yield str(t_2(context.call((undefined(name='union_def') if l_0_union_def is missing else l_0_union_def), l_1_union, (undefined(name='generate_fuzzing') if l_1_generate_fuzzing is missing else l_1_generate_fuzzing), _loop_vars=_loop_vars), 2))
    l_1_union = l_1_generate_fuzzing = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        template = environment.get_template('interface_definition.tmpl', 'module_definition.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'interface': l_1_interface, 'enum_def': l_0_enum_def, 'union_def': l_0_union_def})):
            yield event
    l_1_interface = missing
    for l_1_constant in environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'constants'):
        _loop_vars = {}
        pass
        yield '\n  exports.'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ' = '
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ';'
    l_1_constant = missing
    for l_1_enum in (undefined(name='enums') if l_0_enums is missing else l_0_enums):
        _loop_vars = {}
        pass
        yield '\n  exports.'
        yield str(environment.getattr(l_1_enum, 'name'))
        yield ' = '
        yield str(environment.getattr(l_1_enum, 'name'))
        yield ';'
    l_1_enum = missing
    def t_3(fiter):
        for l_1_struct in fiter:
            if environment.getattr(l_1_struct, 'exported'):
                yield l_1_struct
    for l_1_struct in t_3((undefined(name='structs') if l_0_structs is missing else l_0_structs)):
        _loop_vars = {}
        pass
        yield '\n  exports.'
        yield str(environment.getattr(l_1_struct, 'name'))
        yield ' = '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield ';'
    l_1_struct = missing
    for l_1_union in (undefined(name='unions') if l_0_unions is missing else l_0_unions):
        _loop_vars = {}
        pass
        yield '\n  exports.'
        yield str(environment.getattr(l_1_union, 'name'))
        yield ' = '
        yield str(environment.getattr(l_1_union, 'name'))
        yield ';'
    l_1_union = missing
    for l_1_interface in (undefined(name='interfaces') if l_0_interfaces is missing else l_0_interfaces):
        _loop_vars = {}
        pass
        yield '\n  exports.'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ' = '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield ';\n  exports.'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'Ptr = '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'Ptr;\n  exports.'
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedPtr = '
        yield str(environment.getattr(l_1_interface, 'name'))
        yield 'AssociatedPtr;'
    l_1_interface = missing

blocks = {}
debug_info = '2=29&3=33&7=38&8=44&9=48&13=51&14=54&18=58&19=64&20=69&24=71&25=74&28=78&29=82&31=87&32=91&34=96&35=104&37=109&38=113&40=118&41=122&42=126&43=130'