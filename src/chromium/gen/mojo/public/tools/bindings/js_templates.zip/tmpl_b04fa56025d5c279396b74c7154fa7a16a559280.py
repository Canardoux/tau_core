from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['groupby']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'groupby' found.")
    try:
        t_2 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_enum_name, l_1_enum):
        t_3 = []
        l_1_prev_enum = missing
        if l_1_enum_name is missing:
            l_1_enum_name = undefined("parameter 'enum_name' was not provided", name='enum_name')
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_3.extend((
            str(l_1_enum_name),
            ' = {};',
        ))
        l_1_prev_enum = 0
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n  ',
                str(l_1_enum_name),
                '.',
                str(environment.getattr(l_2_field, 'name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ';',
            ))
        l_2_field = missing
        if (not t_2(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_3.extend((
                '\n  ',
                str(l_1_enum_name),
                '.MIN_VALUE = ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ';',
            ))
        if (not t_2(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_3.extend((
                '\n  ',
                str(l_1_enum_name),
                '.MAX_VALUE = ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ';',
            ))
        if environment.getattr(l_1_enum, 'default_field'):
            pass
            t_3.extend((
                '\n  ',
                str(l_1_enum_name),
                '.DEFAULT_VALUE = ',
                str(environment.getattr(environment.getattr(l_1_enum, 'default_field'), 'numeric_value')),
                ';',
            ))
        t_3.extend((
            '\n\n  ',
            str(l_1_enum_name),
            '.isKnownEnumValue = function(value) {',
        ))
        if environment.getattr(l_1_enum, 'fields'):
            pass
            t_3.append(
                '\n    switch (value) {',
            )
            for l_2_enum_field in t_1(environment, environment.getattr(l_1_enum, 'fields'), 'numeric_value'):
                _loop_vars = {}
                pass
                t_3.extend((
                    '\n    case ',
                    str(environment.getitem(l_2_enum_field, 0)),
                    ':',
                ))
            l_2_enum_field = missing
            t_3.append(
                '\n      return true;\n    }',
            )
        t_3.extend((
            '\n    return false;\n  };\n\n  ',
            str(l_1_enum_name),
            '.toKnownEnumValue = function(value) {',
        ))
        if (environment.getattr(l_1_enum, 'extensible') and environment.getattr(l_1_enum, 'default_field')):
            pass
            t_3.append(
                '\n    if (this.isKnownEnumValue(value))\n      return value;\n    return this.DEFAULT_VALUE;',
            )
        else:
            pass
            t_3.append(
                '\n    return value;',
            )
        t_3.extend((
            '\n  };\n\n  ',
            str(l_1_enum_name),
            '.validate = function(enumValue) {\n    const isExtensible = ',
        ))
        if environment.getattr(l_1_enum, 'extensible'):
            pass
            t_3.append(
                'true',
            )
        else:
            pass
            t_3.append(
                'false',
            )
        t_3.append(
            ';\n    if (isExtensible || this.isKnownEnumValue(enumValue))\n      return validator.validationError.NONE;\n\n    return validator.validationError.UNKNOWN_ENUM_VALUE;\n  };',
        )
        return concat(t_3)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum_name', 'enum'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=24&2=33&3=36&4=37&5=42&7=50&8=54&10=59&11=63&13=68&14=72&17=79&18=82&20=87&21=92&29=101&30=104&39=116&40=119'