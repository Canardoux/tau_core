from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'enum_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['ts_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type' found.")
    try:
        t_2 = environment.tests['none']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No test named 'none' found.")
    pass
    def macro(l_1_enum):
        t_3 = []
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        t_3.extend((
            'export const ',
            str(t_1(l_1_enum)),
            'Spec: { $: mojo.internal.MojomType } = { $: mojo.internal.Enum() };\n\nexport enum ',
            str(t_1(l_1_enum)),
            ' {\n',
        ))
        if (not t_2(environment.getattr(l_1_enum, 'min_value'))):
            pass
            t_3.extend((
                '\n  MIN_VALUE = ',
                str(environment.getattr(l_1_enum, 'min_value')),
                ',',
            ))
        if (not t_2(environment.getattr(l_1_enum, 'max_value'))):
            pass
            t_3.extend((
                '\n  MAX_VALUE = ',
                str(environment.getattr(l_1_enum, 'max_value')),
                ',',
            ))
        for l_2_field in environment.getattr(l_1_enum, 'fields'):
            _loop_vars = {}
            pass
            t_3.extend((
                '\n  ',
                str(environment.getattr(l_2_field, 'name')),
                ' = ',
                str(environment.getattr(l_2_field, 'numeric_value')),
                ',',
            ))
        l_2_field = missing
        t_3.append(
            '\n}',
        )
        return concat(t_3)
    context.exported_vars.add('enum_def')
    context.vars['enum_def'] = l_0_enum_def = Macro(environment, macro, 'enum_def', ('enum',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=24&2=31&4=33&6=36&7=40&9=43&10=47&12=50&13=55'