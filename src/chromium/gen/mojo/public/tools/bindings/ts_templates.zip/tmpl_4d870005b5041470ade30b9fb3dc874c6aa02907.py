from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'converter_interface_declarations.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_typemapped_structs = resolve('typemapped_structs')
    l_0_converter_imports = resolve('converter_imports')
    try:
        t_1 = environment.filters['sort']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'sort' found.")
    try:
        t_2 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    yield '// Copyright 2024 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    l_1_loop = missing
    for l_1_struct, l_1_loop in LoopContext((undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs), undefined):
        l_1_module_filename = resolve('module_filename')
        _loop_vars = {}
        pass
        yield '\nimport type {\n  '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'MojoType'
        if (not environment.getattr(l_1_loop, 'last')):
            pass
            yield ','
        yield "\n} from './"
        yield str((undefined(name='module_filename') if l_1_module_filename is missing else l_1_module_filename))
        yield "';"
    l_1_loop = l_1_struct = l_1_module_filename = missing
    yield '\n\n'
    l_1_loop = missing
    for (l_1_path, l_1_types), l_1_loop in LoopContext(t_1(environment, context.call(environment.getattr((undefined(name='converter_imports') if l_0_converter_imports is missing else l_0_converter_imports), 'items'))), undefined):
        _loop_vars = {}
        pass
        yield 'import type {'
        l_2_loop = missing
        for l_2_type, l_2_loop in LoopContext(t_1(environment, l_1_types), undefined):
            _loop_vars = {}
            pass
            yield '\n  '
            yield str(l_2_type)
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_type = missing
        yield "\n} from '"
        yield str(l_1_path)
        yield "';\n"
    l_1_loop = l_1_path = l_1_types = missing
    for l_1_struct in (undefined(name='typemapped_structs') if l_0_typemapped_structs is missing else l_0_typemapped_structs):
        _loop_vars = {}
        pass
        yield '\n\nexport class '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'DataView {\n  private readonly mojoType: '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'MojoType;\n\n  constructor(mojoType: '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'MojoType) {\n    this.mojoType = mojoType;\n  }'
        for l_2_packed_field in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields'):
            l_2_f = missing
            _loop_vars = {}
            pass
            l_2_f = environment.getattr(l_2_packed_field, 'field')
            _loop_vars['f'] = l_2_f
            yield '\n\n  '
            yield str(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'name'))
            yield '(): '
            yield str(t_2(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'kind')))
            yield ' {\n    return this.mojoType.'
            yield str(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'name'))
            yield ';\n  }'
        l_2_packed_field = l_2_f = missing
        yield '\n}\n\nexport interface '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'TypeMapper<T> {\n  // Encoding:'
        for l_2_packed_field in environment.getattr(environment.getattr(l_1_struct, 'packed'), 'packed_fields_in_ordinal_order'):
            l_2_f = missing
            _loop_vars = {}
            pass
            l_2_f = environment.getattr(l_2_packed_field, 'field')
            _loop_vars['f'] = l_2_f
            yield '\n  '
            yield str(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'name'))
            yield '(mappedTyped: T): '
            yield str(t_2(environment.getattr((undefined(name='f') if l_2_f is missing else l_2_f), 'kind')))
            yield ';'
        l_2_packed_field = l_2_f = missing
        yield '\n\n  // Decoding:\n  convert(dataView: '
        yield str(environment.getattr(l_1_struct, 'name'))
        yield 'DataView): T;\n}\n\n'
    l_1_struct = missing

blocks = {}
debug_info = '4=27&6=32&7=34&8=38&11=43&13=48&14=52&15=53&17=58&20=61&22=65&23=67&25=69&28=71&29=75&31=78&32=82&37=86&39=88&40=92&41=95&45=101'