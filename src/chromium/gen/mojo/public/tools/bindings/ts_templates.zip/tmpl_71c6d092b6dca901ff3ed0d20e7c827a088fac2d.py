from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_interface = resolve('interface')
    l_0_mojom_namespace = resolve('mojom_namespace')
    l_0_generate_return_type = l_0_enum_def = missing
    try:
        t_1 = environment.filters['length']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'length' found.")
    try:
        t_2 = environment.filters['sanitize_identifier']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'sanitize_identifier' found.")
    try:
        t_3 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    def macro(l_1_method):
        t_4 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if (t_1(environment.getattr(l_1_method, 'response_parameters')) == 0):
                pass
                t_4.append(
                    'Promise<void>',
                )
            else:
                pass
                t_4.append(
                    'Promise<{',
                )
                for l_2_response_parameter in environment.getattr(l_1_method, 'response_parameters'):
                    _loop_vars = {}
                    pass
                    t_4.extend((
                        '\n        ',
                        str(environment.getattr(l_2_response_parameter, 'name')),
                        ': ',
                        str(t_3(environment.getattr(l_2_response_parameter, 'kind'))),
                        ',',
                    ))
                l_2_response_parameter = missing
                t_4.append(
                    ' }>',
                )
        else:
            pass
            t_4.append(
                'void',
            )
        return concat(t_4)
    context.exported_vars.add('generate_return_type')
    context.vars['generate_return_type'] = l_0_generate_return_type = Macro(environment, macro, 'generate_return_type', ('method',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "PendingReceiver implements\n    mojo.internal.interfaceSupport.PendingReceiver {\n\n  handle: mojo.internal.interfaceSupport.Endpoint;\n  constructor(handle: MojoHandle|mojo.internal.interfaceSupport.Endpoint) {\n    this.handle = mojo.internal.interfaceSupport.getEndpointForReceiver(handle);\n  }\n\n  bindInBrowser(scope: string = 'context') {\n    mojo.internal.interfaceSupport.bind(\n        this.handle,\n        '"
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield "',\n        scope);\n  }\n}\n\nexport interface "
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface {'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        _loop_vars = {}
        pass
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield str(t_2(environment.getattr(l_2_param, 'name')))
            yield ': '
            yield str(t_3(environment.getattr(l_2_param, 'kind')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ', '
        l_2_loop = l_2_param = missing
        yield '): '
        yield str(context.call((undefined(name='generate_return_type') if l_0_generate_return_type is missing else l_0_generate_return_type), l_1_method, _loop_vars=_loop_vars))
        yield ';'
    l_1_loop = l_1_method = missing
    yield '\n}\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote implements '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Interface {\n  private proxy: mojo.internal.interfaceSupport.InterfaceRemoteBase<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  $: mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver>;\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n  constructor(\n      handle?: MojoHandle|mojo.internal.interfaceSupport.Endpoint) {\n    this.proxy =\n        new mojo.internal.interfaceSupport.InterfaceRemoteBase(\n          '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'PendingReceiver, handle);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceRemoteBaseWrapper(this.proxy);\n\n    this.onConnectionError = this.proxy.getConnectionErrorEventRouter();\n  }'
    l_1_loop = missing
    for l_1_method, l_1_loop in LoopContext(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'), undefined):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield '('
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n      '
            yield str(environment.getattr(l_2_param, 'name'))
            yield ': '
            yield str(t_3(environment.getattr(l_2_param, 'kind')))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '): '
        yield str(context.call((undefined(name='generate_return_type') if l_0_generate_return_type is missing else l_0_generate_return_type), l_1_method, _loop_vars=_loop_vars))
        yield ' {'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n    return this.proxy.sendMessage('
        else:
            pass
            yield '\n    this.proxy.sendMessage('
        yield '\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        ['
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'parameters'), undefined):
            _loop_vars = {}
            pass
            yield '\n          '
            yield str(environment.getattr(l_2_param, 'name'))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                yield ','
        l_2_loop = l_2_param = missing
        yield '\n        ]);\n  }'
    l_1_loop = l_1_method = l_1_interface_message_id = missing
    yield '\n};\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface. Must be constructed over an object which implements that\n * interface.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Receiver {\n  private helper_internal_: mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>;\n\n  $: mojo.internal.interfaceSupport.InterfaceReceiverHelper<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>;\n\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n'
    if t_1(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods')):
        pass
        yield '\n  constructor(impl: '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Interface) {\n'
    else:
        pass
        yield '\n  constructor(_impl: '
        yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
        yield 'Interface) {'
    yield '\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n        '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,'
        else:
            pass
            yield '\n        null,'
        yield '\n        impl.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield '.bind(impl));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n}\n\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield ' {\n  static get $interfaceName(): string {\n    return "'
    yield str((undefined(name='mojom_namespace') if l_0_mojom_namespace is missing else l_0_mojom_namespace))
    yield '.'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '";\n  }\n\n  /**\n   * Returns a remote for this interface which sends messages to the browser.\n   * The browser must have an interface request binder registered for this\n   * interface and accessible to the calling document\'s frame.\n   */\n  static getRemote(): '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote {\n    let remote = new '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote;\n    remote.$.bindNewPipeAndPassReceiver().bindInBrowser();\n    return remote;\n  }\n}'
    included_template = environment.get_template('enum_definition.tmpl', 'interface_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def, 'generate_return_type': l_0_generate_return_type})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 140 in 'interface_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    for l_1_enum in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
    l_1_enum = missing
    yield '\n\n/**\n * An object which receives request messages for the '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield '\n * mojom interface and dispatches them as callbacks. One callback receiver exists\n * on this object for each message defined in the mojom interface, and each\n * receiver can have any number of listeners added to it.\n */\nexport class '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'CallbackRouter {\n  private helper_internal_: mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>;\n  $: mojo.internal.interfaceSupport.InterfaceReceiverHelper<'
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote>;\n  router_: mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n  '
        yield str(environment.getattr(l_1_method, 'name'))
        yield ': mojo.internal.interfaceSupport.InterfaceCallbackReceiver;'
    l_1_method = l_1_interface_message_id = missing
    yield '\n  onConnectionError: mojo.internal.interfaceSupport.ConnectionErrorEventRouter;\n\n  constructor() {\n    this.helper_internal_ = new mojo.internal.interfaceSupport.InterfaceReceiverHelperInternal(\n      '
    yield str(environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'name'))
    yield 'Remote);\n\n    this.$ = new mojo.internal.interfaceSupport.InterfaceReceiverHelper(this.helper_internal_);\n\n    this.router_ = new mojo.internal.interfaceSupport.CallbackRouter;\n'
    for l_1_method in environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'methods'):
        l_1_interface_message_id = missing
        _loop_vars = {}
        pass
        l_1_interface_message_id = str_join((environment.getattr((undefined(name='interface') if l_0_interface is missing else l_0_interface), 'mojom_name'), '_', environment.getattr(l_1_method, 'mojom_name'), ))
        _loop_vars['interface_message_id'] = l_1_interface_message_id
        yield '\n    this.'
        yield str(environment.getattr(l_1_method, 'name'))
        yield ' =\n        new mojo.internal.interfaceSupport.InterfaceCallbackReceiver(\n            this.router_);\n\n    this.helper_internal_.registerHandler(\n        '
        yield str(environment.getattr(l_1_method, 'ordinal'))
        yield ',\n        '
        yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
        yield '_ParamsSpec.$,'
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            yield '\n        '
            yield str((undefined(name='interface_message_id') if l_1_interface_message_id is missing else l_1_interface_message_id))
            yield '_ResponseParamsSpec.$,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(true /* expectsResponse */));'
        else:
            pass
            yield '\n        null,\n        this.'
            yield str(environment.getattr(l_1_method, 'name'))
            yield '.createReceiverHandler(false /* expectsResponse */));'
    l_1_method = l_1_interface_message_id = missing
    yield '\n    this.onConnectionError = this.helper_internal_.getConnectionErrorEventRouter();\n  }\n\n  /**\n   * @param id An ID returned by a prior call to addListener.\n   * @return True iff the identified listener was found and removed.\n   */\n  removeListener(id: number): boolean {\n    return this.router_.removeListener(id);\n  }\n}'

blocks = {}
debug_info = '1=32&2=37&3=39&5=49&6=54&13=72&24=74&29=78&30=81&31=85&32=88&33=91&34=99&38=103&39=107&40=109&47=111&54=114&55=118&58=121&59=124&60=128&61=136&62=138&67=145&68=147&69=149&70=152&75=159&76=163&84=171&88=173&89=175&91=177&95=179&96=182&98=187&101=190&105=192&106=196&109=199&110=201&111=203&112=206&116=212&122=216&124=218&132=222&133=224&140=226&141=232&142=236&146=239&151=241&152=243&153=245&155=247&156=251&158=254&164=258&169=260&170=264&172=267&177=269&178=271&179=273&180=276&181=278&184=283'